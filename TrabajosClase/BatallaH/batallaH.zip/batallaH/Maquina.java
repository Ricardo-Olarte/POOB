 

public class Maquina{
    private Ubicacion ubicacion;
    
    /**
     * Constructor de la clase Maquina,
     */
    public Maquina(){
        
    }
    
    /**
     * Mueve la maquina al norte
     */
    public void alNorte(){}
}
