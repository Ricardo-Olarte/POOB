 

public class Ubicacion {
	private int longitud;
	private int latitud;

}
