 /**
 * Persona que tiene un rango y nombre
 */
public class Marino {
    private String nombre;
    private int rango;
}
