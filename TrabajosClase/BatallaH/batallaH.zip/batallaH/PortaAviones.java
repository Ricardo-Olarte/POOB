import java.util.ArrayList;
public class PortaAviones extends Barco{
    private int capacidad;
    private ArrayList<Avion> aviones;
}
