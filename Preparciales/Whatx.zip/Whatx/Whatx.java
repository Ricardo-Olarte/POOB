
/**
 * Whatx client class
 * @Acosta-Olarte 
 * @2021-2
 */
public class Whatx
{
    
        public Whatx()
    {
        
    }

    /**
     * Deletes a specific message
     * @param chatName, it's the name of the chat that is about to be deleted
     * @param msgId, it's the id of the chat that is about to be deleted
     * @return Boolean 
     */
}
