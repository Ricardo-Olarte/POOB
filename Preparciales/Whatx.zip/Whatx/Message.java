import java.time.*;
import java.util.*;
/**
 * Message class
 * @Acosta-Olarte 
 * @2021-2
 */
public class Message
{
    private int id;
    private String text;
    private LocalDateTime date;
}
