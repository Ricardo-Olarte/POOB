
/**
 * User class
 * @Acosta-Olarte 
 * @2021-2
 */
public class User
{
    private String nickName;
    private String phone;
    private String about;

    /**
     * Returns user's phone
     */
    
    public User(String userName)
    {  
        nickName =  userName;
    }
    
    public String getPhone()
    {
        return phone;
    }

    
    
}
