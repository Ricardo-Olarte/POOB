import java.util.*;
/**
 * Chat class
 * @Acosta-Olarte 
 * @2021-2
 */
public class Chat
{
    // instance variables - replace the example below with your own
    private String name;
    private ArrayList<Chat> chats;
    private ArrayList<User> users;
    private ArrayList<Message> messages;


    /**
     * Constructor for objects of class Chat
     */
    public Chat(String chatName)
    {  
        name =  chatName;
    }

    
    
    
}

