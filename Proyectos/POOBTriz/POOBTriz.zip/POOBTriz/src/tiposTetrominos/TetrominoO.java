package tiposTetrominos;

import java.awt.Color;
import poobtriz.Tetromino;

public class TetrominoO extends Tetromino{
    public TetrominoO(){
        super(new int[][]{  {1,1},
                            {1,1}
                            
        });
        color = Color.yellow;
    }
}
