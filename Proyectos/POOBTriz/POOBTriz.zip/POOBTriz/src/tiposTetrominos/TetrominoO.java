package tiposTetrominos;

import java.awt.Color;
import poobtriz.Tetromino;
import poobtriz.Tipo;

public class TetrominoO extends Tetromino{
    public TetrominoO(Tipo tipo){
        super(new int[][]{  {1,1},
                            {1,1}
                            
        }, tipo);
        color = Color.yellow;
    }
}
