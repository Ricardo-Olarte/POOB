package tiposTetrominos;

import java.awt.Color;
import poobtriz.Tetromino;
import poobtriz.Tipo;

public class TetrominoI extends Tetromino {
    
    public TetrominoI(Tipo tipo){
        super(new int[][]{{1,1,1,1}}, tipo);
        color = Color.cyan;
    }
}
