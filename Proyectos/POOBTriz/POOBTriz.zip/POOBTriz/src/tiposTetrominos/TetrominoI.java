package tiposTetrominos;

import java.awt.Color;
import poobtriz.Tetromino;

public class TetrominoI extends Tetromino {
    
    public TetrominoI(){
        super(new int[][]{{1,1,1,1}});
        color = Color.cyan;
    }
}
