package tiposTetrominos;

import java.awt.Color;
import poobtriz.Tetromino;
import poobtriz.Tipo;

/**
 * Subclase de Tetromino
 * @Author Acosta
 * @Author Olarte
 * @Version 2021-2
 */
public class TetrominoI extends Tetromino {

    /**
     * Constructor de TetrominoI
     * @param tipo
     */
    public TetrominoI(Tipo tipo){
        super(new int[][]{{1,1,1,1}}, tipo);
        color = Color.cyan;
    }
}
