package tiposTetrominos;

import java.awt.Color;
import poobtriz.Tetromino;
import poobtriz.Tipo;

public class TetrominoL extends Tetromino{
    public TetrominoL(Tipo tipo){
        super(new int[][]{  {1,0},
                            {1,0},
                            {1,1}
        }, tipo);
        color = Color.orange;
    }
}
