package tiposTetrominos;

import java.awt.Color;
import poobtriz.Tetromino;
import poobtriz.Tipo;

public class TetrominoJ extends Tetromino{
    public TetrominoJ(Tipo tipo){
        super(new int[][]{  {0,1},
                            {0,1},
                            {1,1}
            
        }, tipo);
        color = Color.blue;
    }
}
