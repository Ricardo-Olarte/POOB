package tiposTetrominos;

import java.awt.Color;
import poobtriz.Tetromino;
import poobtriz.Tipo;

/**
 * Subclase de Tetromino
 * @Author Acosta
 * @Author Olarte
 * @Version 2021-2
 */
public class TetrominoJ extends Tetromino{

    /**
     * Constructor de TetrominoJ
     * @param tipo
     */
    public TetrominoJ(Tipo tipo){
        super(new int[][]{  {0,1},
                            {0,1},
                            {1,1}
            
        }, tipo);
        color = Color.blue;
    }
}
