package tiposTetrominos;

import java.awt.Color;
import poobtriz.Tetromino;
import poobtriz.Tipo;

/**
 * Subclase de Tetromino
 * @Author Acosta
 * @Author Olarte
 * @Version 2021-2
 */
public class TetrominoS extends Tetromino{

    /**
     * Constructor TetrominoS
     * @param tipo
     */
    public TetrominoS(Tipo tipo){
        super(new int[][]{  {0,1,1},
                            {1,1,0}
        }, tipo);
    color = Color.green;
    }
}
