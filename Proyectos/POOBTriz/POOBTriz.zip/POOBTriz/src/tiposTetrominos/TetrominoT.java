package tiposTetrominos;

import java.awt.Color;
import poobtriz.Tetromino;
import poobtriz.Tipo;

public class TetrominoT extends Tetromino{
    public TetrominoT(Tipo tipo){
        super(new int[][]{  {1,1,1},
                            {0,1,0}
        }, tipo);
        color = Color.magenta;
    }
}
