package poobtriz.buffos;

import java.awt.*;
import java.io.Serializable;
import java.util.Random;

/**
 * Clase Buffo, indica el poder que realizara el jugador al tomar este punto
 * @Author Acosta
 * @Author Olarte
 * @Version 2021-2
 */
public abstract class Buffo implements Serializable {
    private Color color;
    protected int x, y;

    /**
     * Constructor de la clase Buffo
     * @param color, adecuado para diferenciar los diferentes buffos
     */
    public Buffo(Color color) {
        this.color = color;
        Random r = new Random();
        x = r.nextInt(10);
        y = r.nextInt(2) + 2;
    }

    /**
     * @return entero
     */
    public abstract int accion();

    /**
     * @return y
     */
    public int getY() {
        return y;
    }

    /**
     * @return x
     */
    public int getX() {
        return x;
    }

    /**
     * @return color
     */
    public Color getColor() {
        return color;
    }
}