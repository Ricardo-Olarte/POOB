package poobtriz.buffos;

import java.awt.*;

/**
 * Subclase de buffo
 * @Author Acosta
 * @Author Olarte
 * @Version 2021-2
 */
public class Slow extends Buffo{

    /**
     * Constructor de la clase Slow
     */
    public Slow(){
        super(new Color(60, 229, 4));
    }

    /**
     * Accion que realiza este buffo
     * @return entero
     */
    @Override
    public int accion() {
        return 3;
    }
}