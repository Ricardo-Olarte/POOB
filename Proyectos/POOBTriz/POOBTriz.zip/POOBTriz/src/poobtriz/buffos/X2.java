package poobtriz.buffos;

import java.awt.*;

/**
 * Subclase de buffo
 * @Author Acosta
 * @Author Olarte
 * @Version 2021-2
 */
public class X2 extends Buffo{

    /**
     * Constructor de la clase X2
     */
    public X2(){
        super(new Color(229, 150, 4));
    }

    /**
     * Accion que realizara este buffo
     * @return
     */
    @Override
    public int accion() {
           return 4;
    }
}