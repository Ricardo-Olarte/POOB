package poobtriz.buffos;

import java.awt.*;

public class X2 extends Buffo{

    public X2(){
        super(new Color(229, 150, 4));
    }

    @Override
    public int accion() {
           return 4;
    }
}