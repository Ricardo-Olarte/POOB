package poobtriz.buffos;

import java.awt.*;

public class StopD extends Buffo{

    public StopD(){
        super(new Color(113, 4, 229));
    }

    @Override
    public int accion() {
        return 2;
    }
}