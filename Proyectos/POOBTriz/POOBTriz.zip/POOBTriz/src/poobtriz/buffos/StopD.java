package poobtriz.buffos;

import java.awt.*;

/**
 * Subclase de buffo
 * @Author Acosta
 * @Author Olarte
 * @Version 2021-2
 */
public class StopD extends Buffo{

    /**
     * Constructor de la clase StopD
     */
    public StopD(){
        super(new Color(113, 4, 229));
    }

    /**
     * Accion que realiza este buffo
     * @return entero
     */
    @Override
    public int accion() {
        return 2;
    }
}