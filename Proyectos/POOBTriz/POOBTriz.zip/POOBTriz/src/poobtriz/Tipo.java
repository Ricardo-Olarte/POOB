package poobtriz;

import java.awt.*;

public abstract class Tipo {

    private Color color;

    public Tipo(Color color){
        this.color = color;
    }

    public abstract Color[][] moveToBackground(Color[][] fondo, Tetromino tetromino);

    public Color getColor(){
        return color;
    }

}