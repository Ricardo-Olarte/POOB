package poobtriz;

import java.awt.*;

/**
 * Tipo, estilo de tetromino
 * @Author Acosta
 * @Author Olarte
 * @Version 2021-2
 */
public abstract class Tipo {

    private Color color;

    /**
     * Constructor de Tipo
     * @param color
     */
    public Tipo(Color color){
        this.color = color;
    }

    /**
     * @param fondo
     * @param tetromino
     * @return
     */
    public abstract Color[][] moveToBackground(Color[][] fondo, Tetromino tetromino);

    /**
     * @return color
     */
    public Color getColor(){
        return color;
    }

}