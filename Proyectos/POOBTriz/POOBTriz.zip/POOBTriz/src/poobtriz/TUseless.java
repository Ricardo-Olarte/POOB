package poobtriz;

import java.awt.*;

public class TUseless extends Tipo{

    public TUseless(){
        super(new Color(208, 208, 208));
    }

    public Color[][] moveToBackground(Color[][] fondo, Tetromino tetromino){
        return fondo;
    }
}
