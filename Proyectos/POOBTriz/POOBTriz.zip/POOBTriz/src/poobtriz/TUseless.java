package poobtriz;

import java.awt.*;

/**
 * Subclase de  Tipo
 * @Author Acosta
 * @Author Olarte
 * @Version 2021-2
 */
public class TUseless extends Tipo{

    /**
     * Constructor de TUseless
     */
    public TUseless(){
        super(new Color(208, 208, 208));
    }

    /**
     *
     * @param fondo
     * @param tetromino
     * @return fondo
     */
    public Color[][] moveToBackground(Color[][] fondo, Tetromino tetromino){
        return fondo;
    }
}
