package poobtriz;

import java.util.logging.Level;
import java.util.logging.Logger;

public class HiloDosJugadores extends Thread {

    private Tablero tab;
    private int puntaje;
    private ModoDosJugadores pf;
    private int buffos = 0;

    public HiloDosJugadores(Tablero tab, ModoDosJugadores pf){
        this.tab = tab;
        this.pf = pf;
        pf.actualizarPuntaje(puntaje);
        
    }
    
    @Override
    public void run(){  
        while(true){
            tab.nuevoTetromino();
            if(tab.getBuffo() == null && puntaje % 1 == 0 && puntaje > 0 && pf.getBuffos() > buffos){
                tab.seleccionarBuffo();
                buffos++;
            }
            pf.actualizarSiguiente();
            while (tab.caidaTetromino()){
                try {
                    Thread.sleep(500);
                } 
                catch (InterruptedException ex) {
                    return;
                }
            }
            if(tab.bloquePorFuera()){
                POOBTriz.juegoTerminado(puntaje);
                break;
            }
            tab.tetrominoAFondo();
            puntaje += tab.quitarLinea();
            pf.actualizarPuntaje(puntaje);
        }
    }
    
    public void buffo(int buffo){
        if(buffo == 1){
            long tiempo1 = System.currentTimeMillis();
            int tiempo = (int)(System.currentTimeMillis() - tiempo1)/1000;
            while(tiempo != 3){
                tiempo = (int)(System.currentTimeMillis() - tiempo1)/1000;
            }
        }else if(buffo == 2){
            pf.accionPausa();
        }
        
    }
}