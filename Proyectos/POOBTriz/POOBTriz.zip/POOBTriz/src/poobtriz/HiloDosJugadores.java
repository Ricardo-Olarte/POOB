package poobtriz;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Clase Thread, da continuidad al juego en el modo dos jugadores
 * @Author Acosta
 * @Author Olarte
 * @Version 2021-2
 */
public class HiloDosJugadores extends Thread {

    private Tablero tab;
    private int puntaje;
    private int puntaje2;
    private ModoDosJugadores pf;
    private int buffos = 0;
    private int velocidad = 500;

    /**
     * Constructor de HiloDosJugadores
     * @param tab es el tablero del juego
     * @param pf modo de juego
     */
    public HiloDosJugadores(Tablero tab, ModoDosJugadores pf){
        this.tab = tab;
        this.pf = pf;
    }

    /**
     * Corre el juego hasta que el jugador pierda
     */
    @Override
    public void run(){  
        while(true){
            tab.nuevoTetromino();
            if(tab.getBuffo() == null && puntaje % 1 == 0 && puntaje > 0 && pf.getBuffos() > buffos){
                tab.seleccionarBuffo();
                buffos++;
            }
            pf.actualizarSiguiente();
            while (tab.caidaTetromino()){
                try {
                    Thread.sleep(velocidad);
                    if(velocidad > 100){
                        velocidad -= 2;
                    }
                } 
                catch (InterruptedException ex) {
                    return;
                }
            }
            if(tab.bloquePorFuera()){
                POOBTriz.juegoTerminado(puntaje);
                break;
            }
            tab.tetrominoAFondo();
            puntaje += tab.quitarLinea();
            pf.actualizarPuntaje();
        }
    }

    /**
     * @return puntaje
     */
    public int getPuntaje(){
        return puntaje;
    }

    /**
     * Determina el tiempo de duracion de cada buffo
     * @param buffo
     */
    public void buffo(int buffo){
        if(buffo == 1){
            long tiempo1 = System.currentTimeMillis();
            int tiempo = (int)(System.currentTimeMillis() - tiempo1)/1000;
            while(tiempo != 3){
                tiempo = (int)(System.currentTimeMillis() - tiempo1)/1000;
            }
        }else if(buffo == 2){
            pf.accionPausa();
        }
        
    }
}