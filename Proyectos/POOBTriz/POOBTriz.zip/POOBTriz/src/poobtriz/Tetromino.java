package poobtriz;

import java.awt.Color;
import java.util.Random;

/**
 * Clase Tetromino, figura de POOBTriz
 * @Author Acosta
 * @Author Olarte
 * @Version 2021-2
 */
public class Tetromino {
    private int[][] tipo;
    public Color color;
    private int x;
    private int y;
    private int[][][] tipos;
    private int posicionActual;
    private Color[] colores = {Color.ORANGE, Color.CYAN, Color.BLUE, Color.PINK, 
    Color.RED, Color.YELLOW, Color.GREEN};
    private Tipo borde;

    /**
     * Constructor de Tetromino
     * @param tipo
     * @param borde
     */
    public Tetromino(int[][] tipo, Tipo borde){
        this.tipo = tipo;
        this.borde = borde;
        tiposIniciales();
    }

    /**
     * Tipos de tetrominos
     */
    public void tiposIniciales(){
        tipos = new int[4][][];
        for(int i = 0; i < 4; i++){
            int r = tipo[0].length;
            int c = tipo.length;
            tipos[i] = new int[r][c];
            for(int y = 0; y < r; y++){
                for(int x = 0; x < c; x++){
                    tipos[i][y][x] = tipo [c-x-1][y];
                }
         
            }
            tipo = tipos[i];
            
        }
    }

    /**
     * Genera nuevos tetromino
     * @param anchoCelda
     */
    public void generarTetromino(int anchoCelda){
        Random r = new Random();
        posicionActual = r.nextInt(tipos.length);
        tipo = tipos[posicionActual];
        y = - getAltura();
        x = (anchoCelda - getAncho())/ 2;
    }

    /**
     *
     * @return tipo
     */
    public int[][] getTipo(){
        return tipo;
    }

    /**
     *
     * @return color
     */
    public Color getColor(){
        return color;
    }

    /**
     *
     * @return tipo.length
     */
    public int getAltura(){
        return tipo.length;
    }

    /**
     *
     * @return
     */
    public int getAncho(){
        return tipo[0].length;
    }

    /**
     *
     * @return x
     */
    public int getX(){
        return x;
    }

    /**
     *
     * @return y
     */
    public int getY(){
        return y;
    }

    /**
     * mueve en vertical el tetromino Y
     */
    public void moverAbajo(){
        y++;
    }

    /**
     * mueve en horizontal el tetromino X
     */
    public void moverDerecha(){
        x++;
    }

    /**
     * mueve en horizontal el tetromino X
     */
    public void moverIzquierda(){
        x--;
    }

    /**
     *
     * @return total de altura
     */
    public int getFondo(){
        return y + getAltura();
    }

    /**
     * rota el tetromino
     */
    public void rotar(){
        posicionActual++;
        if(posicionActual > 3) posicionActual = 0;
        tipo = tipos[posicionActual];
    }

    /**
     *
     * @return x
     */
    public int getIzq(){
        return x;
    }

    /**
     *
     * @return total de anchura
     */
    public int getDer(){
        return x + getAncho();
    }

    /**
     * Asigna el x
     * @param nuevoX
     */
    public void setX(int nuevoX){
        x = nuevoX;
    }

    /**
     * Asigna nueva Y
     * @param nuevoY
     */
    public void setY(int nuevoY){
        y = nuevoY;
    }

    /**
     * asigna borde
     * @param borde
     */
    public void setBorde(Tipo borde){
        this.borde = borde;
    }

    /**
     *
     * @return borde
     */
    public Tipo getBorde(){
        return borde;
    }
    
}
