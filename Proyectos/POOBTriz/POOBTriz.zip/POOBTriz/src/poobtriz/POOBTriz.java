
package poobtriz;

import javax.swing.JOptionPane;

/**
 * Clase POOBTRiz, juego principal
 * @Author Acosta
 * @Author Olarte
 * @Version 2021-2
 */
public class POOBTriz {
    private static POOBTrizForm pf;
    private static InicioForm iff;
    private static PuntuacionesForm puf;
    private static ModoDosJugadores pfdos;

    /**
     * Incicia la partida
     */
    public static void inicio(){
        pf.setVisible(true);
        pf.iniciarPartida();

    }

    /**
     * Inicia partida modo dos jugadores
     */
    public static void inicioDos(){
        pfdos.setVisible(true);
        pfdos.iniciarPartida();
        
    }

    /**
     * Muestra las puntuaciones
     */
    public static void mostrarPuntuaciones(){
        puf.setVisible(true);
    }

    /**
     * Menu del juego
     */
    public static void menu(){
        iff.setVisible(true);
    }

    /**
     * Termina juego
     * @param puntaje
     */
    public static void juegoTerminado(int puntaje){
        String nombre = JOptionPane.showInputDialog("Inserte su nombre.");
        pf.setVisible(false);
        puf.addJugador(nombre, puntaje);
    }

    /**
     * Main del juego
     * @param args
     */
    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                pf = new POOBTrizForm();
                iff = new InicioForm();
                puf = new PuntuacionesForm();
                pfdos = new ModoDosJugadores();
                iff.setVisible(true);
            }
        });
    }
    
}
