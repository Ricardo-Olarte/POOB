package poobtriz;

import java.awt.Color;
import java.awt.Graphics;
import static java.awt.PageAttributes.ColorType.COLOR;
import java.util.Random;
import javax.swing.JPanel;
import poobtriz.buffos.*;
import tiposTetrominos.*;

/**
 * Clase Tablero, guarda la informacion del juego
 * @Author Acosta
 * @Author Olarte
 * @Version 2021-2
 */
public class Tablero extends JPanel {
    private int filasCelda;
    private int columnasCelda;
    private int tamanoCelda;
    private Tetromino tetromino;
    private Color[][] fondo;
    private Tetromino[] tetrominos;
    private Tetromino siguienteTetromino;
    private Buffo buffo;
    private Buffo buffoActivo; 
    private char tipoAct = ' ';

    /**
     * Constructor Tablero
     * @param areaJuego, lugar de juego
     * @param columnas, columnas que se asignan
     */
    public Tablero(JPanel areaJuego, int columnas){
        //areaJuego.setVisible(false);
        this.setBounds(areaJuego.getBounds());
        this.setBackground(areaJuego.getBackground());
        this.setBorder(areaJuego.getBorder());
        columnasCelda = columnas;
        tamanoCelda = this.getBounds().width / columnasCelda;
        filasCelda = this.getBounds().height / tamanoCelda;
        tetrominos = new Tetromino[]{new TetrominoI(new TClasico()), new TetrominoJ(new TClasico()),
                                     new TetrominoL(new TClasico()), new TetrominoO(new TClasico()),
                                     new TetrominoS(new TClasico()), new TetrominoT(new TClasico()),
                                     new TetrominoZ(new TClasico())};
        fondo = new Color[filasCelda][columnasCelda];

    }

    /**
     * Limpia el fondo del tablero
     */
    public void limpiarFondo(){
        fondo = new Color[filasCelda][columnasCelda];
    }

    /**
     * Nuevo tetromino
     */
    public void nuevoTetromino(){
        Random r = new Random();
        if(siguienteTetromino == null){
            tetromino = tetrominos[r.nextInt(tetrominos.length)];
        }else{
            tetromino = siguienteTetromino;
        }
        setTipo();
        siguienteTetromino = tetrominos[r.nextInt(tetrominos.length)];
        tetromino.generarTetromino(columnasCelda);
    }

    /**
     * Asigna tipo
     */
    public void setTipo() {
        char tipo = "BUC".charAt((int) (Math.random() * 3));
        Tipo nuevoTipo = null;
        while (tipo == tipoAct) {
            tipo = "BUC".charAt((int) (Math.random() * 3));
        }
        if(tipo == 'B'){
            tetromino.setBorde(new TBomba());
        }else if(tipo == 'U'){
            tetromino.setBorde(new TUseless());
        }else if(tipo == 'C'){
            tetromino.setBorde(new TClasico());
        }
    }

    /**
     * @return boolean
     */
    public boolean bloquePorFuera(){
        if(tetromino.getY() < 0){
            tetromino = null;
            return true;
        }
        return false;
        
    }

    /**
     * @return siguienteTetromino
     */
    public Tetromino getSiguienteTetromino(){
        return siguienteTetromino;
    }

    /**
     * @return boolean
     */
    public boolean caidaTetromino(){
        if(puedeBajar() == false){
            
            return false;
        }
        tetromino.moverAbajo();
        if(cogerBuffo()){
            buffo = null;
        }
        repaint();
        return true;
    }

    /**
     * mueve a la derecha el tetromino
     */
    public void moverDerecha(){
        if(tetromino == null) return;
        if(puedeDer() == false) return;
        tetromino.moverDerecha();
        if(cogerBuffo()){
            buffo = null;
        }
        repaint();
    }

    /**
     * mueve a la izquierda el tetromino
     */
    public void moverIzquierda(){
        if(tetromino == null) return;
        if(puedeIzq() == false) return;
        tetromino.moverIzquierda();
        if(cogerBuffo()){
            buffo = null;
        }
        repaint();
    }

    /**
     * cae el tetromina
     */
    public void soltarTetromino(){
        if(tetromino == null) return;
        while(puedeBajar()){
            tetromino.moverAbajo();
        }
        if(cogerBuffo()){
            buffo = null;
        }
        repaint();
    }

    /**
     * rota el tetromino
     */
    public void rotarTetromino(){
        if(tetromino == null) return;
        tetromino.rotar();
        if(tetromino.getIzq() < 0 ) tetromino.setX(0);
        if(tetromino.getDer() >= columnasCelda) tetromino.setX(columnasCelda - tetromino.getAncho());
        if(tetromino.getFondo() >= filasCelda) tetromino.setY(filasCelda - tetromino.getAltura());
        
        repaint();
    }

    /**
     * puede caer el tetromino
     * @return
     */
    private boolean puedeBajar(){
        if(tetromino.getFondo() == filasCelda ){
            return false;
        }
        
        int[][]tipo = tetromino.getTipo();
        int altura = tetromino.getAltura();
        int ancho = tetromino.getAncho();
        
        for(int col = 0; col < ancho; col++){
            for(int fila = altura - 1; fila >= 0; fila--){
                if(tipo[fila][col] != 0){
                    int x = col + tetromino.getX();
                    int y = fila + tetromino.getY() + 1;
                    if(y < 0) break;
                    if(fondo[y][x] != null) return false;
                    break;
                }
            }
        }
        
        return true;
    }

    /**
     * revisa si puede mover a la izquierda
     * @return boolean
     */
    private boolean puedeIzq(){
        if(tetromino.getIzq() == 0) return false;
        
        int[][]tipo = tetromino.getTipo();
        int altura = tetromino.getAltura();
        int ancho = tetromino.getAncho();
        
        for(int fila = 0; fila < altura; fila++){
            for(int col = 0; col < ancho; col++){
                if(tipo[fila][col] != 0){
                    int x = col + tetromino.getX() - 1;
                    int y = fila + tetromino.getY();
                    if(y < 0) break;
                    if(fondo[y][x] != null) return false;
                    break;
                }
            }
        }
        
        return true;
    }

    /**
     * revisa si puede mover a la derecha
     * @return boolean
     */
    private boolean puedeDer(){
        if(tetromino.getDer() == columnasCelda) return false;
        
        int[][]tipo = tetromino.getTipo();
        int altura = tetromino.getAltura();
        int ancho = tetromino.getAncho();
        
        for(int fila = 0; fila < altura; fila++){
            for(int col = ancho - 1; col >= 0; col--){
                if(tipo[fila][col] != 0){
                    int x = col + tetromino.getX() + 1;
                    int y = fila + tetromino.getY();
                    if(y < 0) break;
                    if(fondo[y][x] != null) return false;
                    break;
                }
            }
        }
        
        return true;
    }

    /**
     * Quita linea si se completa
     * @return lineasBorradas
     */
    public int quitarLinea(){
        boolean lineaCompleta;
        int lineasBorradas = 0;
        for(int f = filasCelda - 1; f >= 0; f--){
            lineaCompleta = true;
            for(int c = 0; c < columnasCelda; c++){
                if(fondo[f][c] == null){
                    lineaCompleta = false;
                    break;
                }
            }
            if(lineaCompleta){
                lineasBorradas++;
                borrarLinea(f);
                moverTodoAbajo(f);
                borrarLinea(0);
                f++;
                repaint();
            }
        }
        return lineasBorradas;
    }

    /**
     * Borra linea
     * @param f
     */
    private void borrarLinea(int f){
        for(int i = 0; i < columnasCelda; i++){
            fondo[f][i] = null;
        }
    }

    /**
     * mueve todo abajo el tetromino
     * @param f
     */
    private void moverTodoAbajo(int f){
        for(int fila = f; fila > 0; fila--){
           for(int col = 0; col < columnasCelda; col++){
               fondo[fila][col] = fondo[fila - 1][col];
           } 
        }
    }

    /**
     * Tetromino a fondo
     */
    public void tetrominoAFondo(){
        int[][] tipo = tetromino.getTipo();
        int altura = tetromino.getAltura();
        int ancho = tetromino.getAncho();
        int x = tetromino.getX();
        int y = tetromino.getY();
        Color color = tetromino.getColor();
        for(int r = 0; r < altura; r++){
            for(int c = 0; c < ancho; c++){
                if(tipo[r][c] == 1){
                    fondo[r + y][c + x] = color;
                }
            }
        }
        fondo = tetromino.getBorde().moveToBackground(fondo, tetromino);
    }

    /**
     * dibuja el tetromino
     * @param g
     */
    private void dibujarTetromino(Graphics g){
        int altura = tetromino.getAltura();
        int ancho = tetromino.getAncho();
        Color color = tetromino.getColor();
        int[][] tipo = tetromino.getTipo();
        
        for (int fila = 0; fila < altura; fila++){
            for(int columna = 0; columna < ancho; columna++){
                if(tipo[fila][columna] == 1){
                    int x = (tetromino.getX() + columna) * tamanoCelda;
                    int y = (tetromino.getY() + fila) * tamanoCelda;
                    dibujarCuadrado(g, color, x, y);
                }
            }
        }
    }

    /**
     * dibuja fondo
     * @param g
     */
    private void dibujarFondo(Graphics g){
        Color color;
        for(int r = 0; r < filasCelda; r++){
            for(int c = 0; c < columnasCelda; c++){
                color = fondo[r][c];
                if(color != null){
                    int x = c * tamanoCelda;
                    int y = r * tamanoCelda;
                    dibujarCuadradoFondo(g, color, x, y);
                }
            }
        }
    }

    /**
     * dibuja cuadrados
     * @param g
     * @param color
     * @param x
     * @param y
     */
    private void dibujarCuadrado(Graphics g, Color color, int x, int y){
        g.setColor(color);
                    g.fillRect(x, y, tamanoCelda, tamanoCelda);
                    g.setColor(tetromino.getBorde().getColor());
                    g.drawRect(x, y, tamanoCelda, tamanoCelda);
    }

    /**
     * Dibuja los cuadrado fondo
     * @param g
     * @param color
     * @param x
     * @param y
     */
    private void dibujarCuadradoFondo(Graphics g, Color color, int x, int y){
        g.setColor(color);
                    g.fillRect(x, y, tamanoCelda, tamanoCelda);
                    g.setColor(Color.BLACK);
                    g.drawRect(x, y, tamanoCelda, tamanoCelda);
    }

    /**
     * Paint Component
     * @param g
     */
    @Override
    protected void paintComponent(Graphics g){
        super.paintComponent(g);
        dibujarFondo(g);
        dibujarTetromino(g);
        dibujarBuffo(g);
    }

    /**
     * dibuja el buffo
     * @param g
     */
    public void dibujarBuffo(Graphics g){
        if(buffo != null){
            int x = buffo.getX()*tamanoCelda;
            int y = buffo.getY()*tamanoCelda;
            Color c = buffo.getColor();
            g.setColor(c);
            g.fillOval(x, y, tamanoCelda, tamanoCelda);
        }
    }

    /**
     * Choque de tetromino con buffo
     * @return
     */
    public boolean cogerBuffo(){
        if(buffo != null){
            int[][] forma = tetromino.getTipo();
            int width = tetromino.getAncho();
            int height = tetromino.getAltura();

            for(int columna = 0; columna < width; columna++){
                for(int fila = 0; fila < height; fila++){
                    if (tetromino.getX() + columna == buffo.getX() && tetromino.getY() + fila == buffo.getY()){
                        if(forma[fila][columna] != 0){
                            buffoActivo = buffo;
                            return true;
                        }

                    }
                }
            }
        }
        return false;
    }

    /**
     * Usa el buffo
     */
    public void usarBuffo(){
        if(buffoActivo != null){
            buffoActivo = null;
        }
    }

    /**
     *
     * @return buffoActivo
     */
    public Buffo getBuffo() {
        return buffoActivo;
    }

    /**
     * selecciona el buffo
     */
    public void seleccionarBuffo(){
        char tipo = "TDSX".charAt((int)(Math.random()*4));

        if (tipo == 'T'){
            buffo = new StopT();
        }else if(tipo == 'D'){
            buffo = new StopD();
        }else if(tipo == 'S'){
            buffo = new Slow();
        }else if(tipo == 'X'){
            buffo = new X2();
        }
    }
}
