package poobtriz;

import java.awt.*;

public class TBomba extends Tipo{

    public TBomba(){
        super(new Color(255, 0, 0));
    }

    public Color[][] moveToBackground(Color[][] fondo, Tetromino tetromino){
        int[][] forma = tetromino.getTipo();
        int width = tetromino.getAncho();
        int height = tetromino.getAltura();
        
        //Izquierda
        if(tetromino.getX() != 0){
            for(int fila = 0; fila < height; fila++) {
                for (int columna = 0; columna < width; columna++) {
                    if (forma[fila][columna] != 0) {
                        int x = columna + tetromino.getX() - 1;
                        int y = fila + tetromino.getY();
                        if (fondo[y][x] != null) fondo[y][x] = null;
                    }
                }
            }
        }
        
        //Derecha
        if(tetromino.getDer()!= 10){
            for(int fila = 0; fila < height; fila++) {
                for (int columna = width - 1; columna >= 0; columna--) {
                    if (forma[fila][columna] != 0) {
                        int x = columna + tetromino.getX() + 1;
                        int y = fila + tetromino.getY();
                        if (fondo[y][x] != null) fondo[y][x] = null;
                    }
                }
            }
        }
        
        //Abajo
        if(tetromino.getFondo() != 16){
                for(int columna = 0; columna < width; columna++){
                for(int fila = height - 1; fila >= 0; fila--){
                    if (forma[fila][columna] != 0){
                        int x = columna + tetromino.getX();
                        int y = fila + tetromino.getY() + 1;
                        if(fondo[y][x] != null) fondo[y][x] = null;
                    }
                }
            }
        }
        
        //Bloque
        for(int i = 0; i < height; i++) {
            for (int j = 0; j < width; j++) {
                int x = tetromino.getX();
                int y = tetromino.getY();
                if (forma[i][j] == 1) {
                    fondo[i + y][j + x] = null;
                }
            }
        }
        return fondo;
    }
}