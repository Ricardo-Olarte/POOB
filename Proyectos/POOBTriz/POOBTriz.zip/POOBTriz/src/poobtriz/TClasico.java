package poobtriz;
import java.awt.*;

public class TClasico extends Tipo{

    public TClasico(){
        super(new Color(0, 0, 0));
    }

    public Color[][] moveToBackground(Color[][] fondo, Tetromino tetromino){
        return fondo;
    }
}