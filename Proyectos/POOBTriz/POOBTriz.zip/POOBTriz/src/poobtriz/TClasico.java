package poobtriz;
import java.awt.*;

/**
 * Subclase de tipo
 * @Author Acosta
 * @Author Olarte
 * @Version 2021-2
 */
public class TClasico extends Tipo{

    /**
     * Constructor de TClasico
     */
    public TClasico(){
        super(new Color(0, 0, 0));
    }

    /**
     * @param fondo
     * @param tetromino
     * @return
     */
    public Color[][] moveToBackground(Color[][] fondo, Tetromino tetromino){
        return fondo;
    }
}