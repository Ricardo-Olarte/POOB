package poobtriz;

import poobtriz.buffos.Buffo;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import poobtriz.buffos.Buffo;

/**
 * Panel de Buffo
 * @Author Acosta
 * @Author Olarte
 * @Version 2021-2
 */
public class PanelBuffo extends JPanel {

    private Buffo buffo;
    private int tipo;

    /**
     * Constructor de PanelBuffo
     * @param tipo
     */
    public PanelBuffo(int tipo){
        this.tipo = tipo;
        setBackground(new Color(45,45,45));
        setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createEtchedBorder(), "Buffo", TitledBorder.CENTER, TitledBorder.TOP, new Font("Century Gothic", Font.BOLD, 20),  Color.white));
    }

    /**
     * dibuja el buffo
     * @param g
     */
    public void dibujar(Graphics g){
        if(buffo != null){
            Color c = buffo.getColor();
            int[] puntosX = null;
            if(tipo == 1){
                puntosX = new int[]{115, 90, 140};
            }else{
                puntosX = new int[]{122, 97, 147};
            }
            int[] puntosY = new int[]{45, 95, 95};

            g.setColor(c);
            g.fillPolygon(puntosX, puntosY, 3);
            g.setColor(Color.black);
            g.drawPolygon(puntosX, puntosY, 3);
        }
    }

    /**
     * Asigna el buffo
     * @param b
     */
    public void setBuffo(Buffo b){
        buffo = b;
        repaint();
    }

    /**
     * Paint Component
     * @param g
     */
    @Override
    protected void paintComponent(Graphics g){
        super.paintComponent(g);
        dibujar(g);
    }
}