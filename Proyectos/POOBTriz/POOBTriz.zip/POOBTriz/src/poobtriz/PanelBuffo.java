package poobtriz;

import poobtriz.buffos.Buffo;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import poobtriz.buffos.Buffo;

public class PanelBuffo extends JPanel {

    private Buffo buffo;
    private int tipo;

    public PanelBuffo(int tipo){
        this.tipo = tipo;
        setBackground(new Color(45,45,45));
        setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createEtchedBorder(), "Buffo", TitledBorder.CENTER, TitledBorder.TOP, new Font("Century Gothic", Font.BOLD, 20),  Color.white));
    }

    public void dibujar(Graphics g){
        if(buffo != null){
            Color c = buffo.getColor();
            int[] puntosX = null;
            if(tipo == 1){
                puntosX = new int[]{115, 90, 140};
            }else{
                puntosX = new int[]{122, 97, 147};
            }
            int[] puntosY = new int[]{45, 95, 95};

            g.setColor(c);
            g.fillPolygon(puntosX, puntosY, 3);
            g.setColor(Color.black);
            g.drawPolygon(puntosX, puntosY, 3);
        }
    }

    public void setBuffo(Buffo b){
        buffo = b;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g){
        super.paintComponent(g);
        dibujar(g);
    }
}