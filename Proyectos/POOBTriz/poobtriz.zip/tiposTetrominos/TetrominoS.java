package tiposTetrominos;

import poobtriz.Tetromino;

public class TetrominoS extends Tetromino{
    public TetrominoS(){
        super(new int[][]{  {0,1,1},
                            {1,1,0}
        });
    }
}
