package tiposTetrominos;

import poobtriz.Tetromino;

public class TetrominoI extends Tetromino {
    
    public TetrominoI(){
        super(new int[][]{{1,1,1,1}});
    }
   
}
