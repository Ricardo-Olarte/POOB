package tiposTetrominos;

import poobtriz.Tetromino;

public class TetrominoJ extends Tetromino{
    public TetrominoJ(){
        super(new int[][]{  {0,1},
                            {0,1},
                            {1,1}
            
        });
    }
}
