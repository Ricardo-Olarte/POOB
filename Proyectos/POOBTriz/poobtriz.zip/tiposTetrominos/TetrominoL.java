package tiposTetrominos;

import poobtriz.Tetromino;

public class TetrominoL extends Tetromino{
    public TetrominoL(){
        super(new int[][]{  {1,0},
                            {1,0},
                            {1,1}
        });
    }
}
