package poobtriz;

import java.util.logging.Level;
import java.util.logging.Logger;

public class HiloPOOBTriz extends Thread {

    private Tablero tab;
    private int puntaje;
    private POOBTrizForm pf;

    HiloPOOBTriz(Tablero tab, POOBTrizForm pf){
        this.tab = tab;
        this.pf = pf; 
    }
    
    @Override
    public void run(){  
        while(true){
            
            tab.nuevoTetromino();
            
            while (tab.caidaTetromino()){
                try {

                    Thread.sleep(500);
                } 
                catch (InterruptedException ex) {
                    Logger.getLogger(HiloPOOBTriz.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            if(tab.bloquePorFuera()){
                System.out.println("Juego terminado");
                break;
            }
            tab.tetrominoAFondo();
            puntaje += tab.quitarLinea();
            pf.actualizarPuntaje(puntaje);
        }
    }
}