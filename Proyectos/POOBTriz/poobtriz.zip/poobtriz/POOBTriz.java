
package poobtriz;

public class POOBTriz {

    public static void main(String[] args) {
    }
    
}
