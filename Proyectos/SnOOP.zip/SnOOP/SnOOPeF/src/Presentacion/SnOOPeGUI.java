package Presentacion;

import java.awt.*;
import java.awt.event.*;
import java.io.File;
import javax.imageio.ImageIO;
import javax.swing.*;

/**
 * Clase donde la presentacion y el dominio se unen
 * Autor
 * @NathaliaGarcia
 * @Ricardo Olarte
 * Version
 * @2021-1
 */

public class SnOOPeGUI extends JFrame{

    private static final Dimension DIMENSION = Toolkit.getDefaultToolkit().getScreenSize();
    private static final int  ALTO = DIMENSION.height;
    private static final int ANCHO  = DIMENSION.width;
    private static final String INICIO = "inicio";
    private static final String CONFIG = "configuracion";
    private JFrame frame;
    private JPanel inicio,ventana,panelBoton;
    private VentanaPrincipal principal;
    private VentanaJuego juego;
    private VentanaConfiguracion configuracion;
    private JFileChooser file;
    private JMenu archivo;
    private JMenuBar menuBar;
    private JMenuItem salir;
    private JButton botonEmpezar;
    private Hilo hilo;
    /**
     * Constructor del GUI
     */
    public SnOOPeGUI(){
        super("SnOOPe");
        prepareElementos();
        prepareElementosMenu();
        prepareAccionesMenu();
    }

    /**
     *Permite que se organicen los elementos que van a formar
     * parte de la ventana
     */
    public void prepareElementos(){

        file = new JFileChooser();
        ventana = new  JPanel();
        panelBoton = new JPanel();
        botonEmpezar = new JButton("Jugar");
        inicio = new Fondo("Imagenes/FondoInicio.png");

        this.setSize(ANCHO/2,ALTO/2);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
        this.setLocationRelativeTo(null);

        ventana.setLayout(new CardLayout(0,0));
        inicio.setLayout(null);
        panelBoton.setLayout(new GridLayout(1,1));

        graficos(botonEmpezar, "Imagenes/BotonJugar.png");

        panelBoton.add(botonEmpezar);
        panelBoton.setSize(ANCHO/12,ALTO/12);
        panelBoton.setLocation((ANCHO/4)-(ANCHO/20),22*(ALTO/64));

        inicio.add(panelBoton);
        ventana.add(inicio, INICIO);

        this.add(ventana);
    }

    /**
     *
     */
    private void prepareAcciones(){
        /**
         *
         */
        this.addWindowListener(new WindowAdapter() {
        });
    }

    /**
     *Permite que se cierre la ventana
     */
    public void accionCerrar(){
        int r = JOptionPane.showConfirmDialog(null,"¿Desea Salir?");
        if(r==JOptionPane.YES_OPTION){
            this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            System.exit(0);
        }
    }

    /**
     *Permite organizar los elementos que van a hacer parte del menu
     */
    public void prepareAccionesMenu(){
        principal = new VentanaPrincipal(this);
        salir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                accionCerrar();
            }
        });

        botonEmpezar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    ventPrincipal();

                }
                catch (Exception exception){
                    exception.printStackTrace();
                }
            }
        });
    }

    /**
     *Permite la visualizacion de la ventana pricipal
     */
    public void ventPrincipal() {
        ventana.setVisible(false);
        add(principal);
        principal.setVisible(true);
        validate();

    }

    public void prepareElementosMenu(){

        menuBar = new JMenuBar();
        archivo = new JMenu("Archivo");
        salir = new JMenuItem("Salir");

        archivo.add(salir);
        menuBar.add(archivo);
        setJMenuBar(menuBar);
    }

    /**
     *Permite que se configure la ventana para el modo dos jugadores
     */
    public void configuracionDuos(){
        principal.setVisible(false);
        configuracion = new VentanaConfiguracion(this, "duos");
        add(configuracion);
        configuracion.setFocusable(true);
        configuracion.setVisible(true);
        validate();
    }

    /**
     * La funcionalidad es colocar las imagenes
     * @param componente, es un componente grafico en la cual se pone la imagen
     * @param direccion, es un string que indica el lugar que se encuentra la imagen
     */
    public void graficos(JComponent componente, String direccion){
        try{
            Icono fondo = new Icono(ImageIO.read(new File(direccion)));
            componente.setBorder(fondo);
        }
        catch (Exception exception){
            JOptionPane.showMessageDialog(this,exception.getMessage(),"Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     *Metodo principal para iniciar el funcionamiento del juego
     */
    public static void main(String[] args) {
        SnOOPeGUI game = new SnOOPeGUI();
        game.setVisible(true);
    }

    /**
     *Configuracion de la pantalla
     */
    public void configuracion() {
        principal.setVisible(false);
        configuracion = new VentanaConfiguracion(this);
        add(configuracion);
        configuracion.setFocusable(true);
        configuracion.setVisible(true);

        validate();

    }
    /**
     *Configuracion para el modo de juego un solo jugador
     * @param coloresJugadores arreglo que contiene el color de la cabeza de la serpiente y el del cuerpo
     * @param nombreJugador nombre dado a la serpiente
     */
    public void jugadorIndividual(String[][] coloresJugadores, String nombreJugador) {
        juego= new VentanaJuego("solo",coloresJugadores, ANCHO/2-50,ALTO/2-100, nombreJugador);
        add(juego);

        EventoTeclado eventoTeclado=new EventoTeclado(juego);
        addKeyListener(eventoTeclado);

        requestFocusInWindow();
        hilo= new Hilo(juego);
        hilo.start();
        juego.setVisible(true);
        validate();

    }

    /**
     *Configuracion para el modo de juego dos jugadores
     * @param coloresJugadores arreglo que contiene el color de la cabeza de la serpiente y el del cuerpo
     * @param nombreJugador1 nombre dado a la serpiente por el jugador uno
     * @param nombreJugador2 nombre dado a la serpiente por el jugador dos
     */
    public void jugadorGrupal(String [][] coloresJugadores, String nombreJugador1, String nombreJugador2){
        juego= new VentanaJuego("duo",coloresJugadores, ANCHO/2-50,ALTO/2-100, nombreJugador1, nombreJugador2);
        add(juego);

        EventoTeclado eventoTeclado=new EventoTeclado(juego);
        addKeyListener(eventoTeclado);

        requestFocusInWindow();
        hilo= new Hilo(juego);
        hilo.start();
        juego.setVisible(true);
        validate();
    }
}