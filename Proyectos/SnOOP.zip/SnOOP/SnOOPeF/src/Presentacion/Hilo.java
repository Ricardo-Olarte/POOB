package Presentacion;

import javax.swing.*;
import java.awt.*;

/**
 * clase que realiza el movimiento del juego

 *

 * */
public class Hilo extends Thread {
    boolean ejecute;
    VentanaJuego p;
    long rapidez;


    /**
     * Constructor de la clase Hilo
     * @param p, ingresa el panel en el cual se dibujara el juego
     *
     * @param p*/
    public Hilo(VentanaJuego p){
        ejecute = true;
        this.p = p;

    }

    @Override
    public void run(){
        while( true) {

            p.actualizar();
            rapidez = p.getRapidez();
            p.repaint();
            try {
                Thread.sleep(rapidez);

                if(p.finalice()){
                    pareEjecucion();
                }
            } catch (Exception e) {
            }
        }
    }


    public void pareEjecucion(){
        ejecute = false;
    }


}
