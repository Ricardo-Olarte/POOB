package Presentacion;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.image.BufferedImage;
import javax.swing.border.Border;

/**
 * @autor Nathalia Garcia
 * @autor Ricardo Olarte
 * version 2021-1
 */

public class Icono implements Border {
    private BufferedImage imagen = null;

    /***
     * Constructor de Icono
     * @param Imagen
     */
    public Icono(BufferedImage Imagen){
        imagen = Imagen;
    }

    /**
     *
     * @param c
     * @param g
     * @param x
     * @param y
     * @param width
     * @param height
     */
    @Override
    public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
        if(imagen!=null){
            g.drawImage(imagen,0,0,width,height,null);
        }
    }

    /**
     *
     * @param c
     * @return
     */
    @Override
    public Insets getBorderInsets(Component c) {
        return new Insets(0,0,0,0);
    }

    /**
     *
     * @return
     */
    @Override
    public boolean isBorderOpaque() {
        return true;
    }
}
