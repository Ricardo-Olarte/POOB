package Presentacion;

import java.awt.*;
import java.awt.event.*;
import java.io.File;
import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.Toolkit;

/**
 * Clase que contiene los modos de juego que son solo, duo y maquina, cada uno de los botones
 * de esta ventana los llevara a una siguiente ventana que contiene la informacion correpondiente
 * al modo de juego elegido
 * Autor
 * @NathaliaGarcia
 * @Ricardo Olarte
 * Version 6
 * @2021-1
 */

public class VentanaPrincipal extends JPanel{

    private static final Dimension DIMENSION = Toolkit.getDefaultToolkit().getScreenSize();
    private static final int  ALTO = DIMENSION.height;
    private static final int ANCHO  = DIMENSION.width;
    private static final String INICIO = "inicio";
    private static final String CONFIG = "configuracion";
    private JFrame frame;
    private JPanel principal,ventana,panelBotonSolo,panelBotonDuos,panelBotonMaquina;
    private JFileChooser file;
    private JMenu archivo;
    private JMenuBar menuBar;
    private JMenuItem salir;
    private JButton solo,duos,maquina;
    private SnOOPeGUI snOOPeGUI;
    /**
     * Constructor del GUI
     * @param snOOPeGUI
     */
    public VentanaPrincipal(SnOOPeGUI snOOPeGUI){
        this.snOOPeGUI= snOOPeGUI;
        setLayout(new BorderLayout());
        prepareElementos();
        prepareElementosMenu();
        prepareAccionesMenu();
    }

    /**
     *
     */
    public void prepareElementos(){

        file = new JFileChooser();
        ventana = new  JPanel();
        panelBotonSolo = new JPanel();
        panelBotonDuos = new JPanel();
        panelBotonMaquina = new JPanel();
        solo = new JButton("Solo");
        duos = new JButton("Duos");
        maquina = new JButton("Maquina");
        principal = new Fondo("Imagenes/FondoInicio.png");

        principal.setLayout(null);
        this.setSize(ANCHO/2,ALTO/2);
        this.setVisible(true);

        ventana.setLayout(new CardLayout(0,0));
        panelBotonSolo.setLayout(new GridLayout(1,1));
        panelBotonDuos.setLayout(new GridLayout(1,1));
        panelBotonMaquina.setLayout(new GridLayout(1,1));

        graficos(solo, "Imagenes/Solo.png");
        graficos(duos, "Imagenes/Duos.png");
        graficos(maquina, "Imagenes/Maquina.png");

        panelBotonSolo.add(solo);
        panelBotonDuos.add(duos);
        panelBotonMaquina.add(maquina);

        panelBotonSolo.setSize(ANCHO/12,ALTO/12);
        panelBotonDuos.setSize(ANCHO/12,ALTO/12);
        panelBotonMaquina.setSize(ANCHO/10,ALTO/12);

        panelBotonSolo.setLocation((ANCHO/4 - ANCHO/5),22*(ALTO/64));
        panelBotonDuos.setLocation((ANCHO/4)-(ANCHO/20),22*(ALTO/64));
        panelBotonMaquina.setLocation((ANCHO/2 - ANCHO/8),22*(ALTO/64));

        principal.add(panelBotonSolo);
        principal.add(panelBotonDuos);
        principal.add(panelBotonMaquina);

        ventana.add(principal, INICIO);
        this.add(ventana, BorderLayout.CENTER);
    }

    /**
     *
     */
    public void accionCerrar(){
        int r = JOptionPane.showConfirmDialog(null,"¿Desea Salir?");
        if(r==JOptionPane.YES_OPTION){
            System.exit(0);
        }
    }

    /**
     *
     */
    public void prepareAccionesMenu(){
        salir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                accionCerrar();
            }
        });

        solo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    ventana.setVisible(false);
                    snOOPeGUI.configuracion();

                }
                catch (Exception exception){
                    exception.printStackTrace();
                }
            }
        });

        duos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    ventana.setVisible(false);
                    snOOPeGUI.configuracionDuos();

                }
                catch (Exception exception){
                    exception.printStackTrace();
                }
            }
        });
    }

    /**
     *
     */
    public void prepareElementosMenu(){

        menuBar = new JMenuBar();
        archivo = new JMenu("Archivo");
        salir = new JMenuItem("Salir");

        archivo.add(salir);
        menuBar.add(archivo);
    }

    /**
     * La funcionalidad es colocar las imagenes
     * @param componente, es un componente grafico en la cual se pone la imagen
     * @param direccion, es un string que indica el lugar que se encuentra la imagen
     */
    public void graficos(JComponent componente, String direccion){
        try{
            Icono fondo = new Icono(ImageIO.read(new File(direccion)));
            componente.setBorder(fondo);
        }
        catch (Exception exception){
            JOptionPane.showMessageDialog(this,exception.getMessage(),"Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}