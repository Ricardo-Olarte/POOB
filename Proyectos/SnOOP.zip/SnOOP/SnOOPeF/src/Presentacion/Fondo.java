package Presentacion;

import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

/**
 * @autor Nathalia Garcia
 * @autor Ricardo Olarte
 * version 2021-1
 */

public class Fondo extends JPanel{
    private static Image imagenFondo;

    /**
     * Constructor de Fondo
     * @param direccion
     */
    public Fondo(String direccion){
        setBackground(direccion);
    }

    /**
     *
     * @param direccion
     */
    public void setBackground(String direccion){
        setOpaque(false);
        this.imagenFondo = new ImageIcon(direccion).getImage();
        repaint();
    }

    /**
     *
     * @param g
     */
    public void paintComponent(Graphics g){
        g.drawImage(imagenFondo,0,0,getWidth(),getHeight(),null);
        super.paintComponent(g);
    }
}
