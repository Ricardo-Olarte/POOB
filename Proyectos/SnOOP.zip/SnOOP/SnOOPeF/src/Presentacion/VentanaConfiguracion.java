package Presentacion;

/**
 * Clase que representa la bentana de configuracion del fuego, la primera pantalla que
 * se le ofrece al jugador en ella tendra la opcion de acceder a una siguiente ventana
 * haciendo clic en jugar
 *  *
 * Autor
 * @NathaliaGarcia
 * @Ricardo Olarte
 * Version 6
 * @2021-05-24
 */

import Aplicacion.Jugador;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;

public class VentanaConfiguracion extends JPanel{

    private static final Dimension DIMENSION = Toolkit.getDefaultToolkit().getScreenSize();
    private static final int  ALTO = DIMENSION.height;
    private static final int ANCHO  = DIMENSION.width;
    private static final String INICIO = "inicio";
    private static final String CONFIG = "configuracion";
    private JFrame frame;
    private JPanel configuracion,ventana,panelBoton, panelBoton2,panelJugar;
    private JPanel cabeza,cuerpo;
    private  JPanel nombre;
    private JFileChooser file;
    private JMenu archivo;
    private JMenuBar menuBar;
    private JMenuItem salir;
    private JRadioButton amarillloCabeza,azulCabeza,rojoCabeza,verdeCabeza,amarilloCuerpo,azulCuerpo,rojoCuerpo,verdeCuerpo;
    private JButton botonJugar;
    private ButtonGroup botonesCabeza, botonesCuerpo;
    private String[][] coloresJugadores;
    private SnOOPeGUI snOOPeGUI;
    private JTextField texto;
    private String modoDeJuego;
    private JLabel nombre2;
    private String nombreJugador1;
    private String nombreJugador2;
    private int numeroDeJugador;


    /**
     * Constructor del GUI
     * @param snOOPeGUI
     */
    public VentanaConfiguracion(SnOOPeGUI snOOPeGUI){
        //super("SnOOpe");
        this.snOOPeGUI=snOOPeGUI;
        numeroDeJugador=1;
        setLayout(new BorderLayout());
        prepareElementos();
        prepareElementosMenu();
        prepareAccionesMenu();
    }

    public VentanaConfiguracion(SnOOPeGUI snOOPeGUI, String modoDeJuego){
        //super("SnOOpe");
        this.snOOPeGUI=snOOPeGUI;
        this.modoDeJuego=modoDeJuego;
        numeroDeJugador=1;
        setLayout(new BorderLayout());
        prepareElementos();
        prepareElementosMenu();
        prepareAccionesMenu();
    }

    /**
     *
     */
    public void prepareElementos(){

        file = new JFileChooser();
        nombre= new JPanel();
        nombre.setLayout(new BorderLayout());
        nombre2=new JLabel("Jugador " +numeroDeJugador);
        nombre2.setForeground(Color.red);
        nombre2.setFont(new Font("Arial",3,20));
        ventana = new  JPanel();
        panelBoton = new JPanel();
        panelBoton2 =  new JPanel();
        panelJugar = new JPanel();
        coloresJugadores = new String[2][3];
        texto=new JTextField(20);
        texto.setBackground(Color.white);

        botonJugar = new JButton();
        botonesCabeza = new ButtonGroup();
        botonesCuerpo = new ButtonGroup();
        amarillloCabeza = new JRadioButton("Amarillo");
        amarilloCuerpo = new JRadioButton("Amarillo");
        azulCabeza = new JRadioButton("Azul");
        azulCuerpo = new JRadioButton("Azul");
        rojoCabeza = new JRadioButton("Rojo");
        rojoCuerpo = new JRadioButton("Rojo");
        verdeCabeza = new JRadioButton("Verde");
        verdeCuerpo = new JRadioButton("Verde");

        configuracion = new Fondo("Imagenes/fondo.jpg");
        graficos(botonJugar, "Imagenes/BotonJugar.png");

        configuracion.setLayout(null);
        this.setSize(ANCHO/2,ALTO/2);
        this.setVisible(true);
        //this.setLocationRelativeTo(null);

        ventana.setLayout(new CardLayout(0,0));
        panelBoton.setLayout(new GridLayout(4,1));
        panelBoton2.setLayout(new GridLayout(4,1));
        panelJugar.setLayout(new GridLayout(1,1));

        botonesCabeza.add(amarillloCabeza);
        botonesCabeza.add(azulCabeza);
        botonesCabeza.add(rojoCabeza);
        botonesCabeza.add(verdeCabeza);
        botonesCuerpo.add(amarilloCuerpo);
        botonesCuerpo.add(azulCuerpo);
        botonesCuerpo.add(rojoCuerpo);
        botonesCuerpo.add(verdeCuerpo);

        panelBoton.add(amarillloCabeza);
        panelBoton.add(azulCabeza);
        panelBoton.add(rojoCabeza);
        panelBoton.add(verdeCabeza);
        panelBoton2.add(amarilloCuerpo);
        panelBoton2.add(azulCuerpo);
        panelBoton2.add(rojoCuerpo);
        panelBoton2.add(verdeCuerpo);

        panelJugar.add(botonJugar);


        panelBoton.setSize(ANCHO/10,ALTO/10);
        panelBoton.setLocation((ANCHO/4 - ANCHO/5),17*(ALTO/64));
        panelBoton2.setSize(ANCHO/10,ALTO/10);
        panelBoton2.setLocation((ANCHO/2 - ANCHO/8),17*(ALTO/64));
        panelJugar.setSize(ANCHO/12,ALTO/12);
        panelJugar.setLocation((ANCHO/4)-(ANCHO/20),17*(ALTO/64));

        nombre.add(texto,BorderLayout.CENTER);
        nombre.add(nombre2,BorderLayout.NORTH);
        this.add(nombre,BorderLayout.NORTH);
        configuracion.add(panelBoton);
        configuracion.add(panelBoton2);
        configuracion.add(panelJugar);
        ventana.add(configuracion, INICIO);

        this.add(ventana, BorderLayout.CENTER);
    }

    /**
     *
     */
    public void accionCerrar(){
        int r = JOptionPane.showConfirmDialog(null,"¿Desea Salir?");
        if(r==JOptionPane.YES_OPTION){
            // this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            System.exit(0);
        }
    }

    /**
     *
     */
    public void prepareAccionesMenu(){
        amarillloCabeza.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(e.getSource()==amarillloCabeza){
                    coloresJugadores[numeroDeJugador-1][1] = "Amarillo";

                }
            }
        });
        amarilloCuerpo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(e.getSource()==amarilloCuerpo){
                    coloresJugadores[numeroDeJugador-1][2] = "Amarillo";

                }
            }
        });

        azulCabeza.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(e.getSource()==azulCabeza){
                    coloresJugadores[numeroDeJugador-1][1] = "Azul";
                }
            }
        });
        azulCuerpo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(e.getSource()==azulCuerpo){
                    coloresJugadores[numeroDeJugador-1][2] = "Azul";
                }
            }
        });

        rojoCabeza.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(e.getSource()==rojoCabeza){
                    coloresJugadores[numeroDeJugador-1][1] = "Rojo";
                }
            }
        });
        rojoCuerpo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(e.getSource()==rojoCuerpo){
                    coloresJugadores[numeroDeJugador-1][2] ="Rojo" ;
                }
            }
        });

        verdeCabeza.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(e.getSource()==verdeCabeza){
                    coloresJugadores[numeroDeJugador-1][1] = "Verde";
                }
            }
        });
        verdeCuerpo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(e.getSource()==amarilloCuerpo){
                    coloresJugadores[numeroDeJugador-1][2] = "Verde";
                }
            }
        });

        salir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                accionCerrar();
            }
        });
        botonJugar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    if(modoDeJuego==null) {
                        ventana.setVisible(false);
                        snOOPeGUI.jugadorIndividual(coloresJugadores, texto.getText());
                    }else{
                        if(numeroDeJugador==2){
                            ventana.setVisible(false);
                            nombreJugador2=texto.getText();
                            snOOPeGUI.jugadorGrupal(coloresJugadores, nombreJugador1, nombreJugador2);
                        }else{
                            nombreJugador1=texto.getText();
                            texto.setText("");
                            numeroDeJugador+=1;
                            nombre2.setText("nombre"+ numeroDeJugador);
                            nombre2.setVisible(false);
                            nombre2.setVisible(true);



                        }
                    }

                }
                catch (Exception exception){
                    exception.printStackTrace();
                }
            }
        });
    }

    /**
     *
     */
    public void prepareElementosMenu(){

        menuBar = new JMenuBar();
        archivo = new JMenu("Archivo");
        salir = new JMenuItem("Salir");

        archivo.add(salir);
        menuBar.add(archivo);
    }


    /**
     * La funcionalidad es colocar las imagenes
     * @param componente, es un componente grafico en la cual se pone la imagen
     * @param direccion, es un string que indica el lugar que se encuentra la imagen
     */
    public void graficos(JComponent componente, String direccion){
        try{
            Icono fondo = new Icono(ImageIO.read(new File(direccion)));
            componente.setBorder(fondo);
        }
        catch (Exception exception){
            JOptionPane.showMessageDialog(this,exception.getMessage(),"Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
