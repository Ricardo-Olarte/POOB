package Presentacion;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;


public class EventoTeclado implements KeyListener {
    public static boolean [] booleanKey;
    private VentanaJuego juego;

    public EventoTeclado(VentanaJuego juego){
        booleanKey= new boolean[256];
        this.juego=juego;
    }

    @Override
    public void keyPressed(KeyEvent e) {
        booleanKey[e.getKeyCode()]=true;
        juego.movimiento(booleanKey);
    }

    @Override
    public void keyReleased(KeyEvent e) {
        booleanKey[e.getKeyCode()]=false;
    }





    @Override
    public void keyTyped(KeyEvent arg0) {
        // TODO Auto-generated method stub

    }

}
