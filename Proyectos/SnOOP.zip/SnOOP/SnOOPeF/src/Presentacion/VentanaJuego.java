package Presentacion;

import Aplicacion.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

/**
 * Clase que representa el esenario del juego, aqui se pintan los personajes, al igual que se
 * almacena informacion relacionada con el estado del juego, como el nombre de los jugadores,
 * los puntajes de cada uno, el color de cada serpiente
 *  *
 * Autor
 * @NathaliaGarcia
 * @Ricardo Olarte
 * Version 6
 * @2021-1
 */

public class VentanaJuego extends JPanel  {

    private static final Dimension DIMENSION = Toolkit.getDefaultToolkit().getScreenSize();
    private static final int  ALTO = 600;
    private static final int ANCHO  = 600;
    private static final int TAMANO = 20;
    private int direccion = KeyEvent.VK_W, snakes = 1;
    private boolean continuar;
    private String modoJuego;
    private String[][] coloresJugadores;
    private Juego juego;
    private ImageIcon marco, fondo;
    private int xComida1,yComida1;
    private ImageIcon cabeza1;
    private ImageIcon flecha;
    private Timer timer;

    public VentanaJuego(String modoJuego, String[][] coloresJugadores, int anchoTablero, int altoTablero, String nombreJugador){
        cabeza1= new ImageIcon(getClass().getResource("/Imagenes/CirculoCabeza" +coloresJugadores[0][1]+".png"));
        marco= new ImageIcon(getClass().getResource("/Imagenes/Marco.png"));
        fondo = new ImageIcon(getClass().getResource("/Imagenes/fondo.jpg"));
        this.modoJuego = modoJuego;
        this.coloresJugadores = coloresJugadores;
        prepareElementos(anchoTablero,altoTablero, nombreJugador);

    }

    public VentanaJuego(String modoJuego, String[][] coloresJugadores, int anchoTablero, int altoTablero, String nombreJugador1, String nombreJugador2){
        cabeza1= new ImageIcon(getClass().getResource("/Imagenes/CirculoCabeza" +coloresJugadores[0][1]+".png"));
        marco= new ImageIcon(getClass().getResource("/Imagenes/Marco.png"));
        fondo = new ImageIcon(getClass().getResource("/Imagenes/fondo.jpg"));
        this.modoJuego = modoJuego;
        this.coloresJugadores = coloresJugadores;
        prepareElementos(anchoTablero,altoTablero, nombreJugador1,nombreJugador2);

    }

    public void prepareElementos(int anchoTablero, int altoTablero,String nombreJugador){

        juego = new Juego(modoJuego,coloresJugadores,anchoTablero,altoTablero, nombreJugador);
        empezar();
    }


    public void prepareElementos(int anchoTablero, int altoTablero,String nombreJugador1, String nombreJugador2){

        juego = new Juego(modoJuego,coloresJugadores,anchoTablero,altoTablero, nombreJugador1, nombreJugador2);
        empezar();
    }

    public void empezar(){

        juego.empezar();
        flecha = new ImageIcon(getClass().getResource("/Imagenes/flecha.png"));
        xComida1 = juego.getxPosicionComida1();
        yComida1 = juego.getyPosicionComida2();
        continuar = true;
        //timer = new Timer(ActionListener());
    }

    public void finalizar(Graphics g){
        g.drawImage(fondo.getImage(),0,0,900,900,null);
        g.setColor(Color.red);
        g.setFont(new Font("Game Over",Font.BOLD,20));
        FontMetrics m = getFontMetrics(g.getFont());
        g.drawString("Juego Terminado",(Juego.anchoTablero-m.stringWidth("Juego Terminado"))/2,(Juego.altoTablero/2)-100);
        g.drawString("Nombre: "+juego.obtenerNombreSerpiente1() ,15,(Juego.altoTablero/2));
        g.drawString("Puntaje: "+juego.obtenetLongitudCuerpo1(),15,(Juego.altoTablero/2)+50);
        g.drawString("sorpresas usadas: "+juego.obtenerNumeroSorpresasSerpiente1(),15,(Juego.altoTablero/2)+100);
        if(modoJuego!="solo"){
            g.drawString("Nombre: "+juego.obtenerNombreSerpiente2() ,(Juego.anchoTablero/2),(Juego.altoTablero/2));
            g.drawString("Puntaje: "+juego.obtenetLongitudCuerpo2(),(Juego.anchoTablero/2),(Juego.altoTablero/2)+50);
            g.drawString("sorpresas usadas: "+juego.obtenerNumeroSorpresasSerpiente2(),(Juego.anchoTablero/2),(Juego.altoTablero/2)+100);

        }
    }

    public void actualizar(){

        juego.actualizar();

    }


    public void paint(Graphics g){
        boolean flag1=!juego.muerto1();
        boolean flag2=true;
        if(modoJuego.equals("duo")){
            flag2=!juego.muerto2();
        }
        if(flag1 && flag2) {
            g.clearRect(0, 0, 2000, 2000);
            Graphics2D graphics2D = (Graphics2D) g;
            graphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            dibujar(graphics2D);
            juego.muerto1();
        }else{
            finalizar(g);
        }
    }
    public void dibujar(Graphics2D g){


        g.drawImage(fondo.getImage(),0,0,900,500,null);
        if(modoJuego.equals("duo")){
            ImageIcon serpiente2 = new ImageIcon(getClass().getResource("/Imagenes/CirculoCabeza"+juego.colorCabeza2()+".png"));
            g.drawImage(serpiente2.getImage(),juego.getxPosicionSerpiente2(),juego.getyPosicionSerpiente2(),50,50,null);
            int entero= juego.obtenetLongitudCuerpo2();

            for(int i=0; i<entero;i++){
                ImageIcon bola2 = new ImageIcon(getClass().getResource("/Imagenes/Circulo"+juego.colorCuerpo2()+".png"));
                g.drawImage(bola2.getImage(),juego.getCuerpo2(i)[0],juego.getCuerpo2(i)[1],30,30,null);
            }
        }

        ImageIcon serpiente1 = new ImageIcon(getClass().getResource("/Imagenes/CirculoCabeza"+juego.colorCabeza1()+".png"));
        g.drawImage(serpiente1.getImage(),juego.getxPosicionSerpiente1(),juego.getyPosicionSerpiente1(),50,50,null);
        int entero= juego.obtenetLongitudCuerpo1();

        for(int i=0; i<entero;i++){
            ImageIcon bola1 = new ImageIcon(getClass().getResource("/Imagenes/Circulo"+juego.colorCuerpo1()+".png"));
            g.drawImage(bola1.getImage(),juego.getCuerpo(i)[0],juego.getCuerpo(i)[1],30,30,null);
        }

        ImageIcon fruta1=new ImageIcon(getClass().getResource("/Imagenes/"+juego.tipoComida1()+juego.getColorComida1()+".png"));

        ImageIcon fruta2=new ImageIcon(getClass().getResource("/Imagenes/"+juego.tipoComida2()+juego.getColorComida2()+".png"));

        g.drawImage(fruta1.getImage(),juego.getxPosicionComida1(), juego.getyPosicionComida1(), 50,50, null);
        g.drawImage(fruta2.getImage(),juego.getxPosicionComida2(), juego.getyPosicionComida2(), 50,50, null);


        /**
         * marco inferior
         */
        g.drawImage(marco.getImage(),50,Juego.altoTablero,100,50,null);
        g.drawImage(marco.getImage(),150,Juego.altoTablero,100,50,null);
        g.drawImage(marco.getImage(),250,Juego.altoTablero,100,50,null);
        g.drawImage(marco.getImage(),350,Juego.altoTablero,100,50,null);
        g.drawImage(marco.getImage(),450,Juego.altoTablero,100,50,null);
        g.drawImage(marco.getImage(),550,Juego.altoTablero,100,50,null);
        g.drawImage(marco.getImage(),650,Juego.altoTablero,100,50,null);
        g.drawImage(marco.getImage(),750,Juego.altoTablero,100,50,null);
        g.drawImage(marco.getImage(),850,Juego.altoTablero,100,50,null);

        /**
         * marco top
         */
        g.drawImage(marco.getImage(),50,-25,100,50,null);
        g.drawImage(marco.getImage(),150,-25,100,50,null);
        g.drawImage(marco.getImage(),250,-25,100,50,null);
        g.drawImage(marco.getImage(),350,-25,100,50,null);
        g.drawImage(marco.getImage(),450,-25,100,50,null);
        g.drawImage(marco.getImage(),550,-25,100,50,null);
        g.drawImage(marco.getImage(),650,-25,100,50,null);
        g.drawImage(marco.getImage(),750,-25,100,50,null);
        g.drawImage(marco.getImage(),850,-25,100,50,null);

        /**
         * marco izquierda
         */
        g.drawImage(marco.getImage(),0,0,50,100,null);
        g.drawImage(marco.getImage(),0,100,50,100,null);
        g.drawImage(marco.getImage(),0,200,50,100,null);
        g.drawImage(marco.getImage(),0,300,50,100,null);
        g.drawImage(marco.getImage(),0,400,50,100,null);

        /**
         * marco derecha
         */
        g.drawImage(marco.getImage(),Juego.anchoTablero,0,50,100,null);
        g.drawImage(marco.getImage(),Juego.anchoTablero,100,50,100,null);
        g.drawImage(marco.getImage(),Juego.anchoTablero,200,50,100,null);
        g.drawImage(marco.getImage(),Juego.anchoTablero,300,50,100,null);
        g.drawImage(marco.getImage(),Juego.anchoTablero,400,50,100,null);


        if(modoJuego == "solo"){
            g.setColor(Color.RED);
            g.setFont(new Font("",Font.BOLD,20));
            FontMetrics m = getFontMetrics(g.getFont());
            g.drawString("Puntaje: "+ juego.obtenetLongitudCuerpo1(),20,25);
        }else{}

        if(juego.finalizar(false)){
            finalizar(g);
        }

        for(int i=0; i<juego.cantidadBloques();i++){
            ImageIcon bola1 = new ImageIcon(getClass().getResource("/Imagenes/Bloque.png"));
            g.drawImage(bola1.getImage(),juego.posicionxBloque(i),juego.posicionyBloque(i),30,30,null);
        }
        if(juego.existenciaSorpresa()){
            System.out.println(juego.getTipoSorpresa());
            ImageIcon bola1 = new ImageIcon(getClass().getResource("/Imagenes/"+juego.getTipoSorpresa()+".png"));
            g.drawImage(bola1.getImage(),juego.obtenerPosicionxSorpresa(),juego.obtenerPosicionySorpresa(),30,30,null);
        }
        for(int i=0; i<juego.longitudBolasDeFuego();i++){
            ImageIcon bola1 = new ImageIcon(getClass().getResource("/Imagenes/EstrellaFuego.png"));
            g.drawImage(bola1.getImage(),juego.xPosicionBolaDeFuego(i),juego.yPosicionBolaDeFuego(i),30,30,null);
        }


        //hitBox(g);
    }

    public void movimiento(boolean [] keys){
        String direccion1 = null;
        String direccion2 = null;
        if(keys[KeyEvent.VK_UP]){
            direccion1 = "arriba";
        }
        if(keys[KeyEvent.VK_DOWN]){
            direccion1 = "abajo";
        }
        if(keys[KeyEvent.VK_LEFT]){
            direccion1 = "izquierda";
        }
        if(keys[KeyEvent.VK_RIGHT]){
            direccion1 = "derecha";
        }
        if(keys[KeyEvent.VK_W]){
            direccion2 = "arriba";
        }
        if(keys[KeyEvent.VK_S]){
            direccion2 = "abajo";
        }
        if(keys[KeyEvent.VK_A]){
            direccion2 = "izquierda";
        }
        if(keys[KeyEvent.VK_D]){
            direccion2 = "derecha";
        }if(keys[KeyEvent.VK_M]){
            juego.lanzarSorpresa1();
        }if(keys[KeyEvent.VK_P]){
            juego.pausar();
        }

        juego.cambiarDireccion(direccion1,direccion2);
    }

    public boolean finalice(){
        return juego.muerto1();
    }

    public long getRapidez(){
        return juego.getRapidez();
    }

    public void hitBox(Graphics g){
        g.setColor(Color.RED);
        g.drawRect(juego.getxPosicionComida1(),juego.getyPosicionComida1(),25,25);
        g.drawRect(juego.getxPosicionComida2(),juego.getyPosicionComida2(),25,25);
        g.drawRect(juego.getxPosicionSorpresa(), juego.getyPosicionSorpresa(),25,25);
        g.drawRect(juego.getxPosicionSerpiente1(),juego.getyPosicionSerpiente1(),25,25);
    }
}