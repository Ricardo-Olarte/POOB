package Aplicacion;

/**
 * Clase que representa un tipo de alimento, el veneno se presenta en una fruta morada con verde, que hace que quien la serpiente
 * muera
 * Autor
 * @NathaliaGarcia
 * @Ricardo Olarte
 * Version 1
 * @2021-05-22
 */

public class Veneno extends Comida{

    /**
     * Constructor de la clase veneno
     */
    public Veneno(){
        super("Veneno");
        color="";
    }

    /**
     * Permite que la serpiente muera
     * @param serpiente que consumio el veneno
     */
    public void efectoComida(Serpiente serpiente){
        serpiente.setMuerto(true);
    }
}
