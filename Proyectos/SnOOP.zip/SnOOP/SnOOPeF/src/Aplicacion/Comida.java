package Aplicacion;

import java.awt.*;
import java.util.*;

/**
 * Clase que representa los objetos comestibles del juego, apareceran dos alimentos en cada partida
 * y solamente se podra crear un nuevo alimento cuando la serpiente se haya comido uno de los dos, estps
 * se crearan de forma aleatoria dentro del tablero del juego
 *
 * Autor
 * @NathaliaGarcia
 * @Ricardo Olarte
 * Version 5
 * @2021-05-23
 */

public abstract class Comida {
    private int tiempo;
    private int xPosicion;
    private int yPosicion;
    private int  tamano;
    private boolean esVisible;
    private Random random;
    private Rectangle circulo;
   protected String color;
   private String nombre;
   private boolean existente=true;
   public static final String[] colores={"Rojo","Azul"};


    /**
     *Constructor de la clase comida
     * @nombre tipo de alimento, el cual puede ser fruta,
     * frutaArcoiris, dulce o veneno
     */
    public Comida(String nombre){
        tiempo=20000;
        tamano=25;
        posicionAleatoria();
        colorAleatorio();
        this.nombre=nombre;
        tiempoDeJuego();
    }

    /**
     *Tipo de alimento
     * @return retorna el tipo de alimiento el cual puede
     * ser fruta, frutaArcoiris, dulce o veneno
     */
    public String getNombre() {
        return nombre;
    }

    /**
     *Determina la reaccion de la serpiente al consumir determinado alimento
     * @serpiente que consumio el alimento
     */
    public abstract void efectoComida(Serpiente serpiente);

    /**
     *Permite hacer visible el alimento
     */
    public void hacerVisible(){
        if(!esVisible){
            esVisible = true;
        }
    }

    /**
     *Permite hacer invisible el alimento
     */
    public void hacerInvisible(){
        if(esVisible){
            esVisible =  false;
        }
    }

    /**
     *Permite ubicar en el tablero de juego
     * el alimento de manera aleatoria
     */
    public void posicionAleatoria(){
        random = new Random();
        xPosicion = random.nextInt(350)+60;
        yPosicion = random.nextInt(200)+60;
    }

    /**
     *Da el color a los alimentos de forma
     * aleatoria
     */
    public void colorAleatorio(){
        Random r= new Random();
        int r1= r.nextInt(colores.length);
        color= colores[r1];
    }

    /**
     *Duracion del alimento en el tablero
     */
    public void tiempoDeJuego(){
        TimerTask timerTask= new TimerTask() {
            @Override
            public void run() {
             existente=false;
            }
        };
        Timer tarea= new Timer();
        tarea.schedule(timerTask,tiempo);
    }




    /**
     *Posicion x, y en el tablero
     * @param x posicion en el plano x
     * @param y posicion en el plano y
     */
    public void setxPosicion(int x, int y){
        xPosicion = x;
        yPosicion = y;
    }

    /**
     *Determinar si la comida existe
     * @return true si existe, false si no existe
     */
    public boolean isExistente() {
        return existente;
    }

    public void setExistente(boolean existente){
        this.existente=existente;
    }

    /**
     *Posicion en el eje x
     * @return valor de ubicacion en el eje x
     */
    public int getxPosicion(){
        return xPosicion;
    }

    /**
     *Posicion en el eje y
     * @return valor de ubicacion en el eje y
     */
    public int getyPosicion(){
        return yPosicion;
    }

    public Rectangle getCirculo(){
        return circulo;
    }

    public String getColor(){
        return color;
    }
}
