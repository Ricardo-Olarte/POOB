package Aplicacion;

import java.awt.*;
import java.util.*;

/**
 * Clase principal de SnOOPe, aqui se unen todas las funciones del juego
 * Autor
 * @NathaliaGarcia
 * @Ricardo Olarte
 * Version 6
 * @24-05-2021
 */

public class Juego {

    private String modoJuego;
    private ArrayList<Serpiente> serpientes;
    private String[][] coloresJugadores;
    private Comida comida1, comida2;
    private Sorpresa item;
    private Random random;
    private long rapidez = 500;
    public static int anchoTablero;
    public static int altoTablero;
    public static ArrayList<Bloque> bloques;
    public Sorpresa sorpresaEnElMapa;
    private boolean pausar=false;
    public static ArrayList<BolaDeFuego> bolasFuego;
    // {"FlechaVelocidad", "FlechaDisminuirVelocidad", "Division", "Lupa", "EstrellaFuego", "BloqueTrampa"}
    private final static String[] todasLasSorpresas = {"FlechaVelocidad", "FlechaDisminuirVelocidad", "Division", "Lupa", "EstrellaFuego", "BloqueTrampa"};
    private final static String[] todasLasFrutas = {"fruta", "frutaArcoiris", "veneno", "dulce"};


    /**
     * Constructor de la clase Juego para un solo jugador
     *
     * @param modoJuego    modalidad en la que se esta jugando, que puede ser solo, duo o maquina
     * @param anchoTablero valor del ancho del tablero
     * @param altoTablero  valor del alto del tablero
     */
    public Juego(String modoJuego, String[][] coloresJugadores, int anchoTablero, int altoTablero, String nombreJugador) {
        this.modoJuego = modoJuego;
        bloques = new ArrayList<>();
        bolasFuego = new ArrayList<>();
        random = new Random();
        this.anchoTablero = anchoTablero;
        this.altoTablero = altoTablero;
        serpientes = new ArrayList<Serpiente>();
        Serpiente s = new Serpiente(coloresJugadores[0][1], coloresJugadores[0][2], nombreJugador);
        serpientes.add(s);
        creacionDeComida();
    }

    /**
     * Constructor de la clase Juego para dos jugadores
     *
     * @param modoJuego    modalidad en la que se esta jugando, que puede ser solo, duo o maquina
     * @param anchoTablero valor del ancho del tablero
     * @param altoTablero  valor del alto del tablero
     * @param nombreJugador1 nombre dado por el jugador para la serpiente 1
     * @param  nombreJugador2 nombre dado por el jugador para la serpiente 2
     */
    public Juego(String modoJuego, String[][] coloresJugadores, int anchoTablero, int altoTablero, String nombreJugador1, String nombreJugador2) {
        this.modoJuego = modoJuego;
        bloques = new ArrayList<>();
        bolasFuego = new ArrayList<>();
        random = new Random();
        this.anchoTablero = anchoTablero;
        this.altoTablero = altoTablero;
        serpientes = new ArrayList<Serpiente>();
        int snakes = 0;
        Serpiente s = new Serpiente(coloresJugadores[0][1], coloresJugadores[0][2], nombreJugador1);
        serpientes.add(s);
         s = new Serpiente(coloresJugadores[1][1], coloresJugadores[1][2], nombreJugador2);
        serpientes.add(s);
        creacionDeComida();


    }

    /**
     *
     * @param entero
     */
    public int[] getCuerpo(int entero) {
        return serpientes.get(0).getCuerpo(entero);
    }


    public int[] getCuerpo2(int entero) {
        return serpientes.get(1).getCuerpo(entero);
    }

    /**
     * Inicia el juego dependiendo de la modalidad elegida, solo, duos o maquina
     */
    public void empezar() {
        if (modoJuego == "solo") {
            solo();
        }
        if (modoJuego == "duo") {
            duos();
        }
        if (modoJuego == "maquina") {
            maquina();
        }
        tiempoSorpresa();
    }

    /**
     * Ubica la serpiente en tablero cuando el modo es un solo jugador
     */
    public void solo() {
        serpientes.get(0).setPosicion(150, 150);
    }

    /**
     * Ubica las dos serpiente en tablero cuando el modo es und duo
     */
    public void duos() {
        serpientes.get(0).setPosicion(150, 150);
        serpientes.get(1).setPosicion(320, 150);
        serpientes.get(1).cambiarDireccion("derecha");
    }

    /**
     * Ubica las dos serpiente en tablero cuando el modo es maquina
     */
    public void maquina() {
        serpientes.get(0).setPosicion(25, 15);
        serpientes.get(1).setPosicion(550, 550);

    }

    /**
     * Dependiendo del modo de juego permite que las serpientes tengan movimiento
     * @param direccion1 direccion queda sentido a los movimientos jugador uno
     *@param direccion2 direccion queda sentido a los movimientos jugador dos
     */
    public void cambiarDireccion(String direccion1, String direccion2) {
        serpientes.get(0).cambiarDireccion(direccion1);
        if (direccion2 != null) {
            serpientes.get(1).cambiarDireccion(direccion2);
        }
    }

    /**
     * Tipo de alimento que corresponde a comida1
     * @return el tipo de alimento que corresponde a comida1
     */
    public String tipoComida1() {
        return comida1.getNombre();
    }

    /**
     * Tipo de alimento que corresponde a comida2
     * @return el tipo de alimento que corresponde a comida2
     */
    public String tipoComida2() {
        return comida2.getNombre();
    }

    /**
     * Cuando la serpiente toma una bloque y lo suelta, si esta se estrella
     * con el bloque muere
     */
    public void choqueBloques(){
        for(int i=0; i<serpientes.size();i++) {
            for (int j=0; j<bloques.size();j++) {
                if (bloques.get(j).getxPosicion() - 20 <= serpientes.get(i).getxPosicion() && bloques.get(j).getxPosicion() + 20 >= serpientes.get(i).getxPosicion() &&
                        bloques.get(j).getyPosicion() - 20 <= serpientes.get(i).getyPosicion() &&
                        bloques.get(j).getyPosicion() + 20 >= serpientes.get(i).getyPosicion()) {
                    serpientes.get(i).setMuerto(true);
                }
            }
        }
    }

    /**
     * Finaliza el juego
     * @param flag true si se termino el juego, false si aun no terminado
     */
    public boolean finalizar(boolean flag) {
        int xSerpiente1 = serpientes.get(0).getxPosicion();
        int ySerpiente1 = serpientes.get(0).getyPosicion();
        int xSerpiente2 = 0, ySerpiente2 = 0;
        if (serpientes.size() != 1) {
            xSerpiente2 = serpientes.get(1).getxPosicion();
            ySerpiente2 = serpientes.get(1).getyPosicion();
        }

        if (flag) {
            return flag;
        }
        for (Serpiente s : serpientes) {

            if (serpientes.size() != 1) {
                if (xSerpiente1 == xSerpiente2 && ySerpiente1 == ySerpiente2) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Se encarga de crear dos alimentos en alguna posicion
     * del tablero,teniendo en cuenta que no pueden haber mas
     * de esta cantidad
     */
    private void creacionDeComida() {
        comida1 = creacionDeComidaAleatoria();
        comida2 = creacionDeComidaAleatoria();
    }

    /**
     * Crea de forma aleatoria los alimentos, los cuales pueden
     * ser frutas, frutaArcoiris, veneno y dulce
     * @return retorna un alimento
     */
    private Comida creacionDeComidaAleatoria() {
        Random r = new Random();
        int r1 = r.nextInt(todasLasFrutas.length);
        Comida c = null;
        if (todasLasFrutas[r1].equals("fruta")) {
            c = new Fruta();

        } else if (todasLasFrutas[r1].equals("frutaArcoiris")) {
            c = new FrutaArcoiris();

        } else if (todasLasFrutas[r1].equals("dulce")) {
            c = new Dulce();
        } else if (todasLasFrutas[r1].equals("veneno")) {
            c = new Veneno();
        }
        return c;
    }



    /**
     * Tiempo al azar que determina cuando se creara una nueva
     * sorpresa, la cual tambien se genera de manera aleatoria
     */
    public void tiempoSorpresa() {
        Random r = new Random();
        int r1 = r.nextInt(10000);
        TimerTask timerTask = new TimerTask() {
            @Override
            public void run() {
                elegirSorpresaAlAZar();
            }
        };
        Timer tarea = new Timer();
        tarea.schedule(timerTask, r1);
    }




    /**
     * Permite a la serpiente consumir los alimentos
     * disponibles durante la partida
     */
    public void  comer(){
        comer1(comida1,"comida1");
        comer1(comida2, "comida2");
    }

    /**
     *Creacion de los dos posible comidas
     * @param c de tipo comida
     * @param comida tipo al que pertenece la comida
     */
    public void comer1(Comida c, String comida){
        for(int i=0;i<serpientes.size();i++){
            if (c.getxPosicion()-20<=serpientes.get(i).getxPosicion() && c.getxPosicion()+20>=serpientes.get(i).getxPosicion() &&
                    c.getyPosicion()-20<=serpientes.get(i).getyPosicion() &&
                    c.getyPosicion()+20>=serpientes.get(i).getyPosicion()) {
                c.efectoComida(serpientes.get(i));
                if(comida.equals("comida1")) {
                    comida1 = creacionDeComidaAleatoria();
                }else{
                    comida2 = creacionDeComidaAleatoria();
                }
            }
        }
    }

    /**
     * Determina si existe una sorpresa en la partida
     * @return true si ya se creo una sorpresa, false
     * si aun no se ha creado ninguna sorpresa
     */
    public boolean existenciaSorpresa(){
        if(sorpresaEnElMapa==null){
            return false;
        }else {
            return true;
        }
    }

    public void choqueBolaDeFuegoConSerpiente(){
    }


    /**
     * Posicion en x de la sorpresa
     * @return ubicacion en el planox
     */
    public int obtenerPosicionxSorpresa(){
        return sorpresaEnElMapa.getxPosicion();
    }

    /**
     * Posicion en y de la sorpresa
     * @return ubicacion en el planoy
     */
    public int obtenerPosicionySorpresa(){
        return sorpresaEnElMapa.getyPosicion();
    }

    /**
     * Tipo de sorpresa obtenido por la serpiente
     * @return el tipo de sorpresa que
     */
    public String obtenerTipoSorpresa(){
        return sorpresaEnElMapa.getTipo();
    }

    /**
     *Obtiene la longitud del cuerpo de la serpiente del jugador uno
     * @return el valor de la longitud de la serpiente1
     */
    public int obtenetLongitudCuerpo1(){
        return serpientes.get(0).getLongitudCuerpo();
    }
    /**
     *Obtiene la longitud del cuerpo de la serpiente del jugador dos
     * @return el valor de la longitud de la serpiente2
     */
    public int obtenetLongitudCuerpo2(){
        return serpientes.get(1).getLongitudCuerpo();
    }

    /**
     *Obtiene la cantidad de serpientes
     * @return la cantidad de la longitud de la serpientes
     */
    public int retornarCantidadSerpientes(){
        return serpientes.size();
    }



    /**
     *Permite a la serpiente que atrapo una sorpresa que haga
     * uso de las caracteristicas que le obrece
     */
    public void lanzarSorpresa1(){
        serpientes.get(0).utilizarSorpresa();
    }

    /**
     *Genera de manera aleatoria una sorpresa en el tablero de juego
     */
    public void elegirSorpresaAlAZar(){
        System.out.println("$$$4");
        Random r= new Random();
        Sorpresa s= null;
        int r1= r.nextInt(todasLasSorpresas.length);
        if(todasLasSorpresas[r1].equals("FlechaVelocidad")){
            s= new FlechaVelocidad();
        }else if(todasLasSorpresas[r1].equals("FlechaDisminuirVelocidad")){
            System.out.println("////////7");
            s= new FlechaDiminuirVelocidad();
        } else if(todasLasSorpresas[r1].equals("Lupa")){
            s= new Lupa();
        }else if(todasLasSorpresas[r1].equals("EstrellaFuego")){
            s= new EstrellaFuego();
        }else if(todasLasSorpresas[r1].equals("BloqueTrampa")){
            s= new BloqueTrampa();
        }else if(todasLasSorpresas[r1].equals("Division")){
            s= new Division();
        }
            sorpresaEnElMapa=s;
    }

    /**
     *Permite al jugador tomar la sorpresa cuando este se estrella
     * con esta
     */
    public void choqueConSorpresas(){
        if(sorpresaEnElMapa!=null) {
            try {
                for (int i = 0; i < serpientes.size(); i++) {
                    if (sorpresaEnElMapa.getxPosicion() - 20 <= serpientes.get(i).getxPosicion()
                            && sorpresaEnElMapa.getxPosicion() + 20 >= serpientes.get(i).getxPosicion() &&
                            sorpresaEnElMapa.getyPosicion() - 20 <= serpientes.get(i).getyPosicion() &&
                            sorpresaEnElMapa.getyPosicion() + 20 >= serpientes.get(i).getyPosicion()) {
                        serpientes.get(i).obtenerSorpresa(sorpresaEnElMapa);
                        sorpresaEnElMapa = null;
                        tiempoSorpresa();
                    }
                }

            }catch (Exception e){

            }
        }


    }
    /**
     *Evalua si dos serpientes se estrellaron, lo cual generara que el
     * estado de ambas sea muerto
     */
    public void choqueEntreSerpientes(){
        for (int i = 0; i < serpientes.get(1).getLongitudCuerpo(); i++) {
            if (getCuerpo2(i)[0] - 20 <= serpientes.get(0).getxPosicion()
                    && getCuerpo2(i)[0]+ 20 >= serpientes.get(0).getxPosicion() &&
                    getCuerpo2(i)[1] - 20 <= serpientes.get(0).getyPosicion() &&
                    getCuerpo2(i)[1] + 20 >= serpientes.get(0).getyPosicion()) {
                serpientes.get(0).setMuerto(true);
            }
        }
        for (int i = 0; i < serpientes.get(0).getLongitudCuerpo(); i++) {
            if (getCuerpo(i)[0] - 20 <= serpientes.get(1).getxPosicion()
                    && getCuerpo(i)[0]+ 20 >= serpientes.get(1).getxPosicion() &&
                    getCuerpo(i)[1] - 20 <= serpientes.get(1).getyPosicion() &&
                    getCuerpo(i)[1] + 20 >= serpientes.get(1).getyPosicion()) {
                serpientes.get(1).setMuerto(true);
            }
        }

}

    /**
     *Permite que todas las acciones se generen, cambiando el
     * estado del juego
     */
    public void actualizar(){
        if(!pausar) {
            if(modoJuego.equals("duo")){
                choqueEntreSerpientes();
            }
            for (Serpiente s : serpientes) {
                s.mover();
                s.calculadVelocidadSerpienteSegunLongitud();
            }
            comer();
            choqueConSorpresas();
            choqueBloques();
            choqueBolaDeFuegoComida();
            choqueBolaDeFuegoBloques();
            choqueBolaDeFuegoSorpresa();
            finalizar(false);
            for (Serpiente s : serpientes) {
                if (s.getLongitudCuerpo() % 5 == 0) {
                    rapidez += 0.25;
                }
            }
            for (BolaDeFuego b : bolasFuego) {
                b.mover();
            }
            if (!comida1.isExistente()) {
                comida1 = creacionDeComidaAleatoria();
            }
            if (!comida2.isExistente()) {
                comida2 = creacionDeComidaAleatoria();
            }
        }
    }

    /**
     *Determina que cantidad de sorpresas ha usado la
     * serpiente numero uno
     * @return numero de sorpresas usadas
     */
    public int obtenerNumeroSorpresasSerpiente1(){
        return serpientes.get(0).getNumeroSorpresas();
    }

    /**
     *Determina que cantidad de sorpresas ha usado la
     * serpiente numero dos
     * @return numero de sorpresas usadas
     */
    public int obtenerNumeroSorpresasSerpiente2(){
        return serpientes.get(1).getNumeroSorpresas();
    }

    /**
     *Permite que el juego se ponga en pausa, mediante
     * el uso de la tecla p
     */
    public void pausar(){
         if(pausar){
             pausar=false;
         }else{
             pausar=true;
         }
    }

    /**
     *Posicion en x de la sorpresa BolaDeFuego
     * @return ubicacion en x de la sorpresa
     */
    public int  xPosicionBolaDeFuego(int entero){
        return bolasFuego.get(entero).getxPosicion();
    }

    /**
     *Posicion en y de la sorpresa BolaDeFuego
     * @return ubicacion en y de la sorpresa
     */
    public int  yPosicionBolaDeFuego(int entero){
        return bolasFuego.get(entero).getyPosicion();
    }


    public int longitudBolasDeFuego(){
        return bolasFuego.size();
    }

    /**
     *Cantidad de sorpresas tipo bloque
     * @return numero de bloques
     */
    public int cantidadBloques(){
        return bloques.size();
    }

    /**
     *Posicion en el eje x del bloque
     * @return posicion en x
     */
    public int posicionxBloque(int numero){
        return bloques.get(numero).getxPosicion();
    }

    /**
     *Posicion en el eje y del bloque
     * @return posicion en y
     */
    public int posicionyBloque(int numero){
        return bloques.get(numero).getyPosicion();
    }

    /**
     *Obtiene nombre dado a la primera serpiente
     * @return nombre de la serpiente numero uno
     */
    public String obtenerNombreSerpiente1(){
       return serpientes.get(0).getNombre();
    }

    /**
     *Obtiene nombre dado a la primera serpiente
     * @return nombre de la serpiente numero dos
     */
    public String obtenerNombreSerpiente2(){
        return serpientes.get(1).getNombre();
    }


    /**
     *Permite a la serpiente destruir alimentos al hacer uso de la sorpresa
     * estrella de fuego
     */

    public void choqueBolaDeFuegoComida(){
        for(int i=0;i<bolasFuego.size();i++) {
            if (comida1.getxPosicion() - 20 <= bolasFuego.get(i).getxPosicion() && comida1.getxPosicion() + 20 >= bolasFuego.get(i).getxPosicion() &&
                    comida1.getyPosicion() - 20 <= bolasFuego.get(i).getyPosicion() &&
                    comida1.getyPosicion() + 20 >= bolasFuego.get(i).getyPosicion()) {
                comida1=creacionDeComidaAleatoria();
                bolasFuego.remove(i);
            }
        }
        for(int i=0;i<bolasFuego.size();i++) {
            if (comida2.getxPosicion() - 20 <= bolasFuego.get(i).getxPosicion() && comida2.getxPosicion() + 20 >= bolasFuego.get(i).getxPosicion() &&
                    comida2.getyPosicion() - 20 <= bolasFuego.get(i).getyPosicion() &&
                    comida2.getyPosicion() + 20 >= bolasFuego.get(i).getyPosicion()) {
                comida2=creacionDeComidaAleatoria();
                bolasFuego.remove(i);
            }
        }
    }

    /**
     *Permite a la serpiente destruir sorpresas haciendo uso
     * de la estrella de fuego
     */
    public void choqueBolaDeFuegoSorpresa(){
        if(sorpresaEnElMapa!=null) {
            for (int i=0;i<bolasFuego.size();i++) {
                if (sorpresaEnElMapa.getxPosicion() - 20 <= bolasFuego.get(i).getxPosicion() && sorpresaEnElMapa.getxPosicion() + 20 >= bolasFuego.get(i).getxPosicion() &&
                        sorpresaEnElMapa.getyPosicion() - 20 <= bolasFuego.get(i).getyPosicion() &&
                        sorpresaEnElMapa.getyPosicion() + 20 >= bolasFuego.get(i).getyPosicion()) {
                    sorpresaEnElMapa = null;
                    tiempoSorpresa();
                    bolasFuego.remove(i);
                }
            }
        }
    }

    /**
     *Permite a la serpiente aumentar su longitud en 5 unidades cuando hacer uso
     * de la sorpresa estrella de fuego para destruir el bloque
     */
    public void choqueBolaDeFuegoBloques(){
        for(int i=0;i<bolasFuego.size();i++) {
            for(int j=0;j<bloques.size();j++) {
                if (bloques.get(j).getxPosicion() - 20 <= bolasFuego.get(i).getxPosicion() &&
                        bloques.get(j).getxPosicion() + 20 >= bolasFuego.get(i).getxPosicion() &&
                        bloques.get(j).getyPosicion() - 20 <= bolasFuego.get(i).getyPosicion() &&
                        bloques.get(j).getyPosicion() + 20 >= bolasFuego.get(i).getyPosicion()) {
                    bolasFuego.get(i).choqueBloque();
                   bloques.remove(j);
                   bolasFuego.remove(i);
                }
            }
        }
    }

    /**
     *Determina el estado de vida de la serpiente uno
     * @return true su estado es muerto, false si se
     * encuentra con vida
     */
    public boolean muerto1(){
     return serpientes.get(0).isMuerto();
    }

    /**
     *Determina el estado de vida de la serpiente dos
     * @return true su estado es muerto, false si se
     * encuentra con vida
     */
    public  boolean muerto2(){
        return serpientes.get(1).isMuerto();
    }

    /**
     *Obtener posicion en x de la serpiente 1
     * @return posicion en x
     */
    public int getxPosicionSerpiente1(){
        return serpientes.get(0).getxPosicion();
    }

    /**
     *Obtener posicion en y de la serpiente 1
     * @return posicion en y
     */
    public int getyPosicionSerpiente1(){
        return serpientes.get(0).getyPosicion();
    }

    /**
     *Obtener posicion en x de la serpiente 2
     * @return posicion en x
     */
    public int getxPosicionSerpiente2(){
        return serpientes.get(1).getxPosicion();
    }

    /**
     *Obtener posicion en y de la serpiente 2
     * @return posicion en y
     */
    public int getyPosicionSerpiente2(){
        return serpientes.get(1).getyPosicion();
    }

    /**
     *Obtener posicion en x de la comida 1
     * @return posicion en x
     */
    public int getxPosicionComida1(){
        return comida1.getxPosicion();
    }

    /**
     *Obtener posicion en y de la comida 1
     * @return posicion en y
     */
    public int getyPosicionComida1(){
        return comida1.getyPosicion();
    }

    /**
     *Obtener posicion en x de la comida 2
     * @return posicion en x
     */
    public int getxPosicionComida2(){
        return comida2.getxPosicion();
    }

    /**
     *Obtener posicion en u de la comida 2
     * @return posicion en y
     */
    public int getyPosicionComida2(){
        return comida2.getyPosicion();
    }

    /**
     *Obtener posicion en x de la sorpresa
     * @return posicion en x
     */
    public int getxPosicionSorpresa(){
        return item.getxPosicion();
    }

    /**
     *Obtener posicion en y de la sorpresa
     * @return posicion en y
     */
    public int getyPosicionSorpresa(){
        return item.getyPosicion();
    }

    /**
     *Obtener color de la comida 1
     * @return color de la comida 1
     */
    public String getColorComida1(){
        return comida1.getColor();
    }

    /**
     *Obtener color de la comida 2
     * @return color de la comida 2
     */
    public String getColorComida2(){
        return comida2.getColor();
    }

    /**
     *Obtener tipo de sorpresa
     * @return tipo de sorpresa que puede ser division,
     * flechaVelocidad, flechaDisminuirVelocidad, estrellaFuego,
     * Lupa o bloqueTrampa
     */
    public String getTipoSorpresa(){
        return sorpresaEnElMapa.getTipo();
    }

    /**
     *Obtener a la que se mueve la serpiente
     * @return rapidez de movimiento
     */
    public long getRapidez(){
        return rapidez;
    }

    /**
     *Determinar color de la cabeza de la serpiente 1
     * @String color de la cabeza
     */
    public String colorCabeza1(){
        return serpientes.get(0).getColorCabeza();
    }

    /**
     *Determinar color de la cabeza de la serpiente 2
     * @String color de la cabeza
     */
    public String colorCabeza2(){
        return serpientes.get(1).getColorCabeza();
    }

    /**
     *Determinar color de la cuerpo de la serpiente 1
     * @String color de la cuerpo
     */
    public String colorCuerpo1(){
        return serpientes.get(0).getColorCuerpo();
    }

    /**
     *Determinar color de la cuerpo de la serpiente 2
     * @String color de la cuerpo
     */
    public String colorCuerpo2(){
        return serpientes.get(1).getColorCuerpo();
    }

    /**
     *Serpiente 1
     * @return serpiente 1
     */
    public Serpiente getSerpiente1(){
        return serpientes.get(0);
    }

}
