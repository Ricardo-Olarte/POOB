package Aplicacion;

import java.awt.*;

/**
 * Clase que compone el cuerpo de la serpiente, puede tener los siguientes colores
 * rojo, verde, azul o amarillo, pueden eliminarse o añadirse al final del cuerpo
 * de la serpiente
 * Autor
 * @NathaliaGarcia
 * @Ricardo Olarte
 * Version
 * @2021-1
 */

public class Circulo {

    /**
     * Atributos de la clase circulo
     */
    private int diametro;
    private int xPosicion;
    private int yPosicion;
    private String color;
    private boolean esVisible;
    private Rectangle circulo;
    private int velocidad;

    /**
     * Constructor de Circulo
     */
    public Circulo(){
        diametro = 25;
        xPosicion = 0;
        yPosicion = 0;
        color = "magenta";
        esVisible = false;
        velocidad=20;
    }

    public Circulo(int xPosicion, int yPosicion){
        diametro = 25;
        this.xPosicion = xPosicion;
        this.yPosicion = yPosicion;
        color = "magenta";
        esVisible = false;
        velocidad=15;
    }

    /**
     *Permite visualizarlo en la  pantalla del juego
     */
    public void hacerVisible(){
        if(!esVisible){
            esVisible = true;
        }
    }

    /**
     *Permite hacerlo invisible en la  pantalla del juego
     */
    public void  hacerInvisible(){
        if(esVisible){
            esVisible = false;
        }
    }

    /**
     *Permite que se pueda mover hacia la derecha del tablero
     */
    public void moverDerecha(){
        xPosicion += velocidad;
    }

    /**
     *Permite que se pueda mover hacia la izquierda del tablero
     */
    public void moverIzquierda(){
        xPosicion -= velocidad;
    }

    /**
     *Permite que se pueda mover hacia la parte superior del
     * tablero
     */
    public void moverArriba(){
        yPosicion -= velocidad;
    }

    /**
     *Permite que se pueda mover hacia la parte inferior del
     * tablero
     */
    public void moverAbajo(){
        yPosicion += velocidad;
    }


    public void cambiarPosicion(int xPosition, int yPosition) {
        this.xPosicion=xPosition;
        this.yPosicion=yPosition;
    }
    /**
     *Permite modificar el color del circulo
     * @color color del circulo, verde, rojo, amarillo o azul
     */
    public void cambiarColor(String nuevoColor){
        color = nuevoColor;
    }

    /**
     *Permite modificar el tamaño del circulo
     * @param nuevoTamano valor que se desea dar al diamtro
     */
    public void cambiarTamano(Integer nuevoTamano){
        diametro = nuevoTamano;
    }

    /**
     *
     */
    public void setColor(String nuevoColor){
        color = nuevoColor;
    }

    public int getVelocidad() {
        return velocidad;
    }

    public void setVelocidad(int velocidad) {
        this.velocidad = velocidad;
    }

    /**
     *
     */
    public int getxPosicion(){
        return xPosicion;
    }

    /**
     *
     */
    public int getyPosicion(){
        return yPosicion;
    }

    public Rectangle getCirculo(){
        circulo = new Rectangle(xPosicion,yPosicion,diametro,diametro);
        return circulo;
    }
    public String getColor(){
        return color;
    }
}
