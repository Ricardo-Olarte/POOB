package Aplicacion;

import java.util.Random;
/**
 *
 * Autor
 * @NathaliaGarcia
 * @Ricardo Olarte
 * Version
 * @2021-1
 */
public class Bloque {
    private int xPosicion;
    private int yPosicion;

    public Bloque(){
       posicionAleatoria();
    }

    private void posicionAleatoria() {
        Random r = new Random();
        int r1= r.nextInt(Juego.anchoTablero-150)+60;
        int r2= r.nextInt(Juego.altoTablero-150)+60;
        setxPosicion(r1);
        setyPosicion(r2);
    }

    public int getxPosicion() {
        return xPosicion;
    }

    public int getyPosicion() {
        return yPosicion;
    }

    public void setxPosicion(int xPosicion) {
        this.xPosicion = xPosicion;
    }

    public void setyPosicion(int yPosicion) {
        this.yPosicion = yPosicion;
    }
}
