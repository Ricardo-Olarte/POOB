package Aplicacion;

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;

public class JuegoTess {



    @Test
    public void deberiaLaCabezaDeLaSerpienteSerAzul() {
        String [][] colores= new String[2][3];
        colores[0][1]="Azul";
        colores[0][2]="Rojo";
       Juego j= new Juego("solo",colores,700,700,"Juan");
       j.empezar();
       assertTrue(j.colorCabeza1().equals("Azul"));
    }

    @Test
    public void deberiaSerpienteUnoMoverseHaciaLaDerecha() {
        String [][] colores= new String[2][3];
        colores[0][1]="Azul";
        colores[0][2]="Rojo";
        Juego j= new Juego("solo",colores,700,700,"Juan");
        j.empezar();
        int entero=j.getxPosicionSerpiente1();
        j.cambiarDireccion("derecha",null);
        j.actualizar();
        assertTrue(entero<j.getxPosicionSerpiente1());
    }

   @Test
    public void deberiaTenerTipoDiferente() {
       String[][] colores = new String[2][3];
       colores[0][1] = "Azul";
       colores[0][2] = "Rojo";
       Juego j = new Juego("solo", colores, 700, 700, "Juan");
       j.empezar();
       String c1 = j.getColorComida1();
       String c2 = j.getColorComida2();
       assertTrue(c1 != c2);
   }

    @Test
    public void deberiaTenerEstadoMuerta() {
        String[][] colores = new String[2][3];
        colores[0][1] = "Azul";
        colores[0][2] = "Rojo";
        Juego j = new Juego("solo", colores, 700, 700, "Juan");
        j.empezar();
        boolean vivo=j.muerto1();
        assertTrue(vivo==false);
    }

    public void deberiaTenerUnaVelocidadMenor() {
        String[][] colores = new String[2][3];
        colores[0][1] = "Azul";
        colores[0][2] = "Rojo";
        Juego j = new Juego("solo", colores, 700, 700, "Juan");
        j.empezar();
        Serpiente s =j.getSerpiente1();
        s.disminuirVelocidad();
        int velocidad=20;
        assertTrue(j.getRapidez()<velocidad);
    }




}
