package Aplicacion;
/**
 *Clase que un tipo de sorpresa, la lupa en modo de un solo jugador a la serpiente que la consume no le hara efecto el
 * siquiente alimento que come, y si es en modo multijugador sera al contrincante al que no le hara efecto el siguiente
 * alimento
 * Autor
 * @NathaliaGarcia
 * @Ricardo Olarte
 * Version 1
 * @2021-1
 */
public class Lupa extends Sorpresa{

    /**
     *Constructor de la clase lupa
     */
    public Lupa(){
        super("Lupa");
    }
    /**
     *Permite que el efecto del siguiente alimento se anuele
     * @param serpiente que atrapo la sorpresa lupa
     */
    public  void efectoSorpresa(Serpiente serpiente){
        serpiente.setProtegido(true);
    }
}
