package Aplicacion;

/**
 * Clase que representa un tipo de alimento, la fruta arcoriris permite aumentar el tamaño de la serpiente que la consume
 * en tres unidades, esta furta aparece al azar en alguna posicion del tablero, si no es consumida en 20 segundos desaparece
 * para que se cree otra aliemnto en su lugar
 * Autor
 * @NathaliaGarcia
 * @Ricardo Olarte
 * Version
 * @2021-1
 */


public class FrutaArcoiris extends Comida {

    /**
     * Constructor de la clase FrutaArcoiris
     */
    public FrutaArcoiris(){
        super("FrutaArcoIris");
        color="";
    }

    /**
     * Permite a la serpiente crecer 3 unidades si consume una FrutaArcoiris
     * @param serpiente que consume la fruta arcoiris
     */
    @Override
    public void efectoComida(Serpiente serpiente){
        serpiente.crece();
        serpiente.crece();
        serpiente.crece();
    }
}
