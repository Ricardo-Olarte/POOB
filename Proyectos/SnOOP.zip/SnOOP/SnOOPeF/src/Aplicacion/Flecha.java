package Aplicacion;

import java.net.PortUnreachableException;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Clase que representa una de las sorpresas del juego, la flecha presenta dos modalidades una que permite aumentar la velocidad
 * por un periodo de tiempo y otra que permite disminuir la velocidad de la serpiente que la atrapo, esta puede activar la ejecucion
 * de la sopresa cuando desee
 * Autor
 * @NathaliaGarcia
 * @Ricardo Olarte
 * Version
 * @2021-1
 */

public abstract class Flecha extends Sorpresa{

    /**
     * Constructor de la clase flecha
     * @param nombre tipo de fecha, que puede ser FlechaDisminuirVelocidad o
     *FlechaVelocidad
     */
    public Flecha(String nombre){
        super(nombre);
    }

    /**
     * Una vez transcurrido el tiempo de duración de la sorpresa flecha,
     * el poder se inactiva
     */
    public abstract void quitarSorpresa(Serpiente serpiente);

    /**
     * Tiempo de duracion de la sorpresa
     * @param serpiente serpiente sobre la cual tiene efecto el poder
     */
    public void tiempo(Serpiente serpiente){
        TimerTask timerTask= new TimerTask() {
            @Override
            public void run() {
                quitarSorpresa(serpiente);
            }
        };
        Timer tarea= new Timer();
        tarea.schedule(timerTask,10000);
    }

    /**
     * Determina el efecto que tendra la sorpresa sobre la serpiente dependiendo de
     * de si es una flecha para aumentar velocidad o una flecha para dismunuir velocidad
     * @param serpiente que atrapo la flecha
     */
    public  abstract void efectoSorpresa(Serpiente serpiente);

}
