package Aplicacion;

import java.awt.*;
import java.util.ArrayList;

/**
 * La clase serpiente representa el personaje del juego, donde la serpiente esta compuesta por cabeza y cuerpo
 * el cuerpo se compone de una serie de circulos que pueden añadirse o eliminarse segun las caracteristicas del
 * alimento que consume, esta se puede mover al rededor del tablero, consumir alimentos, estrellarse con los bordes
 *  del tablero o con su propio cuerpo y morir.
 * Autor
 * @NathaliaGarcia
 * @Ricardo Olarte
 * Version
 * @2021-1
 */

public class Serpiente {

    /**
     * Atributos clase Serpiente
     */
    private Circulo cabeza;
    private ArrayList<Circulo> cuerpo;
    private String colorCabeza;
    private String colorCuerpo;
    private String direccion;
    private boolean esVisible;
    private int distanciaCuerpo=15;
    private int puntaje;
    private boolean muerto=false;
    private Serpiente contrincante;
    private Sorpresa sorpresa;
    private int numeroSorpresas=0;
    private String nombre;
    protected boolean protegido=false;

    /**
     * Constructor Serpiente
     * @param colorCabeza, es de tipo color, indica el color que tendra la cabeza de la serpiente
     * @param colorCuerpo, es de tipo color, indica el color que tendra el cuerpo de la serpiente
     * @param nombre nombre dado a la serpiente
     */
    public Serpiente(String colorCabeza, String colorCuerpo, String nombre){
        this.colorCabeza = colorCabeza;
        this.colorCuerpo = colorCuerpo;
        this.nombre= nombre;
        direccion="derecha";
        puntaje = -3;
        setPosicion(50,50);
        crece();
        crece();
        crece();

    }



    /**
     *Le da visibilidad a la serpiente
     */
    public void hacerVisible(){
        if(!esVisible){
            esVisible = true;
        }
    }

    /**
     *Hace invisible a la serpiente
     */
    public void hacerInvisible(){
        if(esVisible){
            esVisible =  false;
        }
    }

    /**
     *Permite a la serpiente direccionar su movimiento hacia la derecha
     */
    public void moverDerecha(){

        movimientoCola();
        cabeza.moverDerecha();
    }

    /**
     *Permite a la serpiente direccionar su movimiento hacia la izquierda
     */
    public void moverIzquierda(){

        movimientoCola();
        cabeza.moverIzquierda();
    }

    /**
     *Permite a la serpiente direccionar su movimiento hacia arriba
     */
    public void moverArriba(){
        movimientoCola();
        cabeza.moverArriba();
    }

    /**
     *Permite a la serpiente direccionar su movimiento hacia abajo
     */
    public void moverAbajo(){
        movimientoCola();
        cabeza.moverAbajo();
    }

    /**
     * Permite que la cola de la serpiente cambie de posicion al moverse
     */
    private void movimientoCola() {
        for(int i=cuerpo.size()-1;i>0;i--){
            cuerpo.get(i).cambiarPosicion(cuerpo.get(i-1).getxPosicion(),cuerpo.get(i-1).getyPosicion());
        }
        cuerpo.get(0).cambiarPosicion(cabeza.getxPosicion(), cabeza.getyPosicion());
    }

    /**
     *Permite eliminar los circulos que componen el cuerpo, segun el alimento que consumio, si es
     * en modo de un jugador le afecta a si mismo y si es en modo multijugador depende de la condicion
     * para afectar al contrincante
     * @param color
     */
    public void disminuirTamano(String color){
        if(!protegido) {
            if (contrincante != null && contrincante.getColorCabeza().equals(color)) {
                cuerpo.remove(cuerpo.size() - 1);
                cuerpo.remove(cuerpo.size() - 1);
            } else {
                cuerpo.remove(cuerpo.size() - 1);
            }
        }else{
            setProtegido(false);
        }
    }

    /**
     * Permite que la serpiente reduzca su tamaño
     */
    public void disminuirTamano() {
        cuerpo.remove(cuerpo.size() - 1);
    }



    /**
     *Direccion del movimiento de la serpiente
     * @return retorna derecha, izquierda, arriba o abajo
     */
    public String getDireccion(){
        return direccion;
    }

    /**
     *Posicion en el eje x
     * @return el valor de la posicion en x
     */
    public int getxPosicion(){
        return cabeza.getxPosicion();
    }

    /**
     *Posicion en el eje y
     * @return el valor de la posicion en y
     */
    public int getyPosicion(){
        return cabeza.getyPosicion();
    }

    /**
     *Segun el alimento que la serpiente haya consumido aumenta su longitud
     * tantos circulos como las condiciones del alimento lo indiquen
     */
    public void crece(){
        Circulo nuevoCirculo;
        int enteroX=0;
        int enteroY=0;
        enteroX= cuerpo.get(cuerpo.size()-1).getxPosicion();
        enteroY= cuerpo.get(cuerpo.size()-1).getyPosicion();
        if(direccion=="arriba"){
            nuevoCirculo = new Circulo(enteroX, enteroY+distanciaCuerpo);
        }else if(direccion=="abajo"){
            nuevoCirculo = new Circulo(enteroX, enteroY-distanciaCuerpo);
        }else if(direccion=="derecha"){
            nuevoCirculo = new Circulo(enteroX-distanciaCuerpo, enteroY);
        }else{
            nuevoCirculo = new Circulo(enteroX+distanciaCuerpo, enteroY);
        }
        nuevoCirculo.setColor(colorCuerpo);
        cuerpo.add(nuevoCirculo);
        puntaje++;

    }

    /**
     * Si la longitud de la serpiente es multiplo de 5
     * disminuye su velocidad
     */
    public void calculadVelocidadSerpienteSegunLongitud(){
        if(cuerpo.size()%5==0){
            cabeza.setVelocidad(cabeza.getVelocidad()-3);
        }
    }

    /**
     *Permite a la serpiente moverse en el tablero
     */
    public void mover(){
        if(!muerto) {
            if (direccion == "arriba") {
                moverArriba();
            } else if (direccion == "abajo") {
                moverAbajo();
            } else if (direccion == "derecha") {
                moverDerecha();
            } else {
                moverIzquierda();
            }
        }
        choques();
    }

    /**
     *Verifica si ocurre alguno de los dos choques posibles para una serpiente
     * ya sea la cabeza con el cuerpo o con alguno de los bordes del tablero
     */
    public void choques(){
       compararChoqueTablero();
        comparChoqueCuerpo();

    }

    /**
     *Verifica si la cabeza de la serpiente se estrella con su cuerpo
     */
    public  void comparChoqueCuerpo(){
        int xCabeza = cabeza.getxPosicion();
        int yCabeza = cabeza.getyPosicion();
        for(Circulo c: cuerpo){
            if(xCabeza == c.getxPosicion() && yCabeza == c.getyPosicion()){
                muerto=true;
            }
        }
    }

    /**
     *Verifica si la serpiente se estrella con alguno de los bordes
     * del tablero
     */
    public  void compararChoqueTablero(){
        int xCabeza = cabeza.getxPosicion();
        int yCabeza = cabeza.getyPosicion();
        if(xCabeza < 50){
            muerto=true;
        }
        if(yCabeza <15){
            muerto=true;
        }
        if(xCabeza > Juego.anchoTablero-30){
            muerto=true;
        }
        if(yCabeza > Juego.altoTablero-30){
            muerto=true;
        }
    }



    /**
     *Longitud del cuerpo de la serpiente
     * @return longitud de la serpiente
     */
    public int getLongitudCuerpo(){
        return cuerpo.size();
    }

    /**
     *Nombre de la serpiente
     * @return nombre que le asigno el jugador a la serpiente
     */
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     *Evalua si la serpiente se encuentra protegida del efecto del
     * alimento que consumio, valido para dulce
     * @return true si la serpiente se encuentra protegida y false
     * si no se encuentra protegida
     */
    public boolean isProtegido() {
        return protegido;
    }

    /**
     *Detrmina si el estado de la serpiente es protegido
     */
    public void setProtegido(boolean protegido) {
        this.protegido = protegido;
    }

    public int[] getCuerpo(int numero){
        int[] lista= new int[2];
        try {
            lista[0] = cuerpo.get(numero).getxPosicion();
            lista[1] = cuerpo.get(numero).getyPosicion();
        }catch (Exception e) {

        }
        return lista;
    }

    /**
     *Determina si la serpiente se encuentra con vida
     * @return true si la serpiente esta muera o false
     * si esta con vida
     */
    public boolean isMuerto() {
        return muerto;
    }

    public void setMuerto(boolean muerto) {
        this.muerto = muerto;
    }

    /**
     *Determina la cantidad de sorpresas que ha usado durante el juego
     * @return numero de sorpresas usadas
     */
    public int getNumeroSorpresas() {
        return numeroSorpresas;
    }

    public void setNumeroSorpresas(int numeroSorpresas) {
        this.numeroSorpresas = numeroSorpresas;
    }

    /**
     *Permite a la serpiente modificar su direccion
     * @dir derecha, izquierda, arriba,abajo
     */
    public void cambiarDireccion(String dir) {
        if(direccion=="arriba" && (dir=="derecha" || dir=="izquierda")){
            direccion=dir;
        }if(direccion=="abajo" && (dir=="derecha" || dir=="izquierda")){
            direccion=dir;
        }if(direccion=="derecha" && (dir=="arriba" || dir=="abajo")){
            direccion=dir;
        }if(direccion=="izquierda" && (dir=="arriba" || dir=="abajo")){
            direccion=dir;
        }
        mover();
    }

    public void setPosicion( int posicionX, int posicionY){
        cabeza = new Circulo(posicionX,posicionY);
        cuerpo = new ArrayList<>();
        Circulo c= new Circulo(cabeza.getxPosicion()-20,cabeza.getyPosicion());
        c.setColor(colorCuerpo);
        cuerpo.add(c);
        crece();
        crece();
        crece();
    }
    public Rectangle getCirculo(){
        return cabeza.getCirculo();
    }

    /**
     * Determina color de la cabeza de la serpiente
     * @return color de la cabeza de la serpiente
     */
    public String getColorCabeza(){
        return colorCabeza;
    }

    /**
     * Determina color de la cuerpo de la serpiente
     * @return color de la cuerpo de la serpiente
     */
    public String getColorCuerpo() {
        return colorCuerpo;
    }

    /**
     *Permite aumentar la velocidad a la que se mueve la serpiente
     */
    public void aumentarVelocidad() {
        cabeza.setVelocidad(cabeza.getVelocidad()+10);
    }

    /**
     *Permite disminuir la velocidad a la que se mueve la serpiente
     * si el modo del juego es mutijugador
     */
    public void disminuirVelocidadContrincante(){
        if(contrincante!=null){
            contrincante.disminuirVelocidad();
        }else{
            disminuirVelocidad();
        }
    }

    /**
     *Permite disminuir la velocidad a la que se mueve la serpiente
     */
    public void disminuirVelocidad() {
        cabeza.setVelocidad(cabeza.getVelocidad()-10);
    }

    /**
     *Permite a la serpiente obtener una sorpresa
     */
    public void obtenerSorpresa(Sorpresa sorpresa) {
        this.sorpresa=sorpresa;
    }

    /**
     *Permite aumentar la velocidad a la que se mueve el contrincante, cuando
     * el otro jugador ha tomado la sorpresa que permite disminuir la velocidad del
     * otro, la aumenta hasta dejarla en su estado inicial
     */
    public void aumentarVelocidadContrincante() {
        if(contrincante!=null){
            contrincante.aumentarVelocidad();
        }else {
            aumentarVelocidad();
        }
    }

    /**
     *Permite a la serpiente hacer uso de la sorpresa
     */
    public void utilizarSorpresa(){
        if(sorpresa!=null){
            sorpresa.efecto(this);
            sorpresa=null;
        }
    }

    /**
     *Permite disminuir el tamaño de la serpiente a la mitad
     */
    public void disminuirTamanoSerpiente(){
        if(contrincante!=null){
            contrincante.disminuirAlaMitad();
        }else{
            disminuirAlaMitad();
        }

    }

    /**
     *Permite disminuir el tamaño de la serpiente a la mitad
     */
    private void disminuirAlaMitad() {
        int numero=cuerpo.size()/2;
        for(int i=0; i<numero;i++){
            cuerpo.remove(cuerpo.size()-1);
        }
    }

}
