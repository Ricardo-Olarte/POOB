package Aplicacion;

import java.awt.*;
import java.util.Random;

/**
 * Clase que representa un las sorpresas disponibles, permite que se generen flechas de velocidad,division, bloque
 * trampa, estrella de fuego y lupa,de estas solamente se pueden generar una en el tablera y aparece al azar y en tiempo
 * y tipo desconocidos para el/los jugadores,pueden hacer uso de la sorpresa cuando deseen y una vez utilizada su
 * efecto se pierde
 * Autor
 * @NathaliaGarcia
 * @Ricardo Olarte
 * Version
 * @2021-1
 */

public abstract class Sorpresa {

    private int xPosicion;
    private int yPosicion;
    private int tamano;
    private Random random;
    private Rectangle caja;
    private String nombre;
    private boolean existente;

    /**
     * Constructor de la calse sorpresa
     * @param  nombre representa el tipo de sorpresa que puede ser  flechas de velocidad,
     *division, bloque trampa, estrella de fuego o lupa
     */
    public Sorpresa(String nombre){
        xPosicion = 0;
        yPosicion = 0;
        posicionAleatoria();
        tamano = 25;
        this.nombre=nombre;
    }

    public void tiempoAleatorio(){}

    /**
     *Permite que la serpiente recoga la sorpresa
     * @param  serpiente que toma la sorpresa
     */
    public void recogerSorpresa(Serpiente serpiente){
        serpiente.obtenerSorpresa(this);
    }

    /**
     *Determina la ubicacion de la sorpresa de forma aleatoria
     */
    public void posicionAleatoria(){
        random = new Random();
        xPosicion = random.nextInt(350)+60;
        yPosicion = random.nextInt(200)+60;
        xPosicion += 50;
        yPosicion += 50;
    }

    /**
     *Dependiendo de la sorpresa atrapada la serpiente reacciona de cierta manera
     * @param serpiente  que atrapo la sorpresa
     */
    public abstract void efectoSorpresa(Serpiente serpiente);{}

    public void efecto(Serpiente serpiente){
        serpiente.setNumeroSorpresas(serpiente.getNumeroSorpresas()+1);
        efectoSorpresa(serpiente);
    }

    public void usoSorpresa(Serpiente serpiente){
        serpiente.obtenerSorpresa(null);
        efectoSorpresa(serpiente);
    }

    public void choqueComida(Comida comida){
        comida.setExistente(false);
    }

    public boolean isExistente() {
        return existente;
    }

    public void setExistente(boolean existente) {
        this.existente = existente;
    }

    public void hacerVisible(){}

    public void hacerInvisible(){}

    public int getxPosicion(){
        return xPosicion;
    }

    public int getyPosicion(){
        return yPosicion;
    }

    public Rectangle getSorpresa(){
        caja = new Rectangle(xPosicion,yPosicion,25,25);
        return caja;
    }

    public String getTipo(){
        return nombre;
    }

}
