package Aplicacion;

import java.util.Random;

/**
 * Clase que representa un tipo de alimento, la fruta se puede presentar en los colores verde, azul, amarillo y rojo y
 * aparece en el tablero al azar, si la serpiente consume una fruta crece una undad de longitud, pero si la fruta tiene
 * el color de la serpiente entonces crece dos unidades de longitud, si la fruta no se ha consumido en 20 segundos esta
 * desaparece para que se cree otro alimento
 * Autor
 * @NathaliaGarcia
 * @Ricardo Olarte
 * Version
 * @2021-1
 */

public class Fruta extends Comida{

    /**
     * Constructor de la clase comida
     */
    public Fruta(){
        super("Fruta");
    }

    /**
     * Permite que la serpiente crezca si consume una fruta crece una unidad, si
     * el color de la fruta es igual al de la serpiente crece 2 unidades
     * @param  serpiente que consumio la fruta
     */
    public void  efectoComida(Serpiente serpiente){
        if(serpiente.getColorCabeza().equals(color)){
            serpiente.crece();
            serpiente.crece();
        }else{
            serpiente.crece();
        }
    }



}