package Aplicacion;

public class BloqueTrampa extends Sorpresa{
    public BloqueTrampa(){
        super("Bloque");
    }
    public  void efectoSorpresa(Serpiente serpiente){
        Juego.bloques.add(new Bloque());
    }
}
