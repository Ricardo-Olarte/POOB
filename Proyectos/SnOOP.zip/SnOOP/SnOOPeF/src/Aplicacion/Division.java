package Aplicacion;

/**
 * Clase que representa una de las sorpresas del juego, si el juego es para un solo jugador tiene efecto
 * sobre la serpiente del mismo, reduciendo la longitud de la serpiente a la mitad, si es multijugador
 * reduce la longitud de la serpiente a la mitad
 * Autor
 * @NathaliaGarcia
 * @Ricardo Olarte
 * Version
 * @2021-1
 */

public class Division extends Sorpresa{

    /**
     * Constructor de la clase Divison
     */
    public  Division(){
        super("Division");
    }

    /**
     * Permite partir a la mitad el cuerpo de la serpiente,
     * que tomo la sorpresa division
     */
    public  void efectoSorpresa(Serpiente serpiente){
        serpiente.disminuirTamanoSerpiente();
    }

}
