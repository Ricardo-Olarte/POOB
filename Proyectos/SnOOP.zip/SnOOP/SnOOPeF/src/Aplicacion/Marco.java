package Aplicacion;

/**
 *Clase que representa los bordes del tablero, estos limitan el espacio de juego de la serpiente
 * y si la serpiente se estrella con estos muere
 * Autor
 * @NathaliaGarcia
 * @Ricardo Olarte
 * Version
 * @2021-1
 */

public class Marco {
    private Rectangulo rectanguloSuperior;
    private Rectangulo rectanguloInferior;
    private Rectangulo rectanguloDerecha;
    private Rectangulo rectanguloIzquierda;
    private int base;
    private int altura;

    /**
     *Constructor de la clase Marco
     */
    public  Marco(){
        rectanguloSuperior= new Rectangulo(base, altura);
        rectanguloInferior=new Rectangulo(base, altura);;
        rectanguloDerecha=new Rectangulo(base, altura);;
        rectanguloIzquierda=new Rectangulo(base, altura);;
    }
}
