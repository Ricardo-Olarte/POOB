package Aplicacion;

/**
 * Clase que representa una de las sorpresas del juego, tipo de flecha que disminuye la velocidad, esta aparece al
 * azar en algun punto del tablero y se activa cuando el jugador desea, su duracion es un tiempo determinado, luego de
 * que este tiempo termine su efecto desaparece
 * Autor
 * @NathaliaGarcia
 * @Ricardo Olarte
 * Version
 * @2021-1
 */


public class FlechaDiminuirVelocidad extends Flecha{

    /**
     * Constructor de la clase FlechaDisminuirVelocidad
     */
    public FlechaDiminuirVelocidad(){
        super("FlechaDiminuirVelocidad");
    }

    /**
     * Quita el efecto que la FlechaDisminuirVelocidad da a la serpiente
     *  * aumentando su velocidad para que quede igual a la inicial
     * @param serpiente que atrapo la flecha
     */
    @Override
    public void quitarSorpresa(Serpiente serpiente) {
        serpiente.aumentarVelocidadContrincante();
    }

    /**
     * Genera que la velocidad de la serpiente disminuya durante un tiempo
     * @param serpiente que atrapo la flecha
     */
    public  void efectoSorpresa(Serpiente serpiente){
        serpiente.disminuirVelocidadContrincante();
        tiempo(serpiente);
    }
}
