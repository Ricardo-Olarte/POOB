package Aplicacion;

/**
 * Clase que representa una de las sorpresas del juego, tipo de flecha que aumenta la velocidad, esta aparece al
 * azar en algun punto del tablero y se activa cuando el jugador desea, su duracion es un tiempo determinado, luego de
 * que este tiempo termine su efecto desaparece
 * Autor
 * @NathaliaGarcia
 * @Ricardo Olarte
 * Version
 * @2021-1
 */

public class FlechaVelocidad extends Flecha{

    /**
     * Constructor de la clase FlechaDisminuirVelocidad
     */
    public FlechaVelocidad(){
        super("FlechaVelocidad");
    }

    /**
     * Quita el efecto que la FlechaDisminuirVelocidad da a la serpiente,
     * disminuyendo su velocidad para que quede igual a la inicial
     * @param serpiente que atrapo la flecha
     */
    @Override
    public void quitarSorpresa(Serpiente serpiente) {
        serpiente.disminuirVelocidad();
    }

    /**
     * Genera que la velocidad de la serpiente aumente durante un tiempo
     * @param serpiente que atrapo la flecha
     */
    public  void efectoSorpresa(Serpiente serpiente){
        serpiente.aumentarVelocidad();
        tiempo(serpiente);
    }

}
