package Aplicacion;
/**
 * Clase que permite que se genere el crecimiento de la serpiente al hacer uso de la estrella de fuego,
 * y en la cual se realiza el moviemiento de la estrella e fuego
 * Autor
 * @NathaliaGarcia
 * @Ricardo Olarte
 * Version 1
 * @2021-05-23
 */

public class BolaDeFuego {
    private int xPosicion;
    private int yPosicion;
    private String direccion;
    private Serpiente serpienteDuena;

    /**
     * Constructor de la clase BolaDeFuego
     * @param direccion hacia la que se lanza la bola de fuego
     * @param xPosicion posicion x de la bola de fuego
     * @param yPosicion posicion y de la bola de fuego
     * @param serpienteDuena serpiente que atrapo la sorpresa
     */
    public BolaDeFuego(String direccion,int xPosicion, int yPosicion, Serpiente serpienteDuena){
        this.xPosicion=xPosicion;
        this.yPosicion=yPosicion;
        this.direccion=direccion;
        this.serpienteDuena=serpienteDuena;
    }

    /**
     * Genera el crecimiento de la serpiente que rompio el bloque
     * en cinco unidades
     */
    public void choqueBloque(){
        serpienteDuena.crece();
        serpienteDuena.crece();
        serpienteDuena.crece();
        serpienteDuena.crece();
        serpienteDuena.crece();
    }


    /**
     * Permite que la bola de fuego se mueva a la derecha
     */
    public void moverDerecha(){
        xPosicion+=30;
    }

    /**
     * Permite que la bola de fuego se mueva a la izquierda
     */
    public void moverIzquierda(){
        xPosicion-=30;
    }

    /**
     * Permite que la bola de fuego se mueva hacia arriba
     */
    public void moverArriba(){
        yPosicion-=30;
    }

    /**
     * Permite que la bola de fuego se mueva hacia abajo
     */
    public void moverAbajo(){
        yPosicion+=30;
    }

    public void choqueSorpresa(Sorpresa sorpresa){
        sorpresa.setExistente(false);
    }
    /**
     * Permite que se realicen los distintos movimientos en el tablero
     */
    public void mover(){
            if (direccion == "arriba") {
                moverArriba();
            } else if (direccion == "abajo") {
                moverAbajo();
            } else if (direccion == "derecha") {
                moverDerecha();
            } else {
                moverIzquierda();
            }

    }
    /**
     * Posicion en el eje x de la bola de fuego
     * @return posicion en x
     */
    public int getxPosicion() {
        return xPosicion;
    }

    /**
     * Posicion en el eje y de la bola de fuego
     * @return posicion en y
     */
    public int getyPosicion() {
        return yPosicion;
    }

    public void setxPosicion(int xPosicion) {
        this.xPosicion = xPosicion;
    }

    public void setyPosicion(int yPosicion) {
        this.yPosicion = yPosicion;
    }
}
