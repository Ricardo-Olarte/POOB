package Aplicacion;

import java.io.Serializable;

/**
 * Clase que presenta la informacion del jugador
 * Autor
 * @NathaliaGarcia
 * @Ricardo Olarte
 * Version
 * @2021-1
 */

public class Jugador implements Serializable {
    private String nombre;
    String[ ]   colores= new  String[2];
    private int puntos;
    private int numSorpresas;
    private String sorpresaPendiente;

    public Jugador(String nombre) {
        nombre = nombre;
        puntos = 0;
        numSorpresas = 0;
        sorpresaPendiente = null;
    }

    /**
     * metodo que se encarga de actualizar el puntaje
     */
    public void puntaje() {
        puntos++;
    }



}
