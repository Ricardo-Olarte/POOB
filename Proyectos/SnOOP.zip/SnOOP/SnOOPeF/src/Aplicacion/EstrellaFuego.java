package Aplicacion;

/**
 * Clase que representa una de las sorpresas del juego, permite a la serpiente que la recoge usarla cuando desee
 * y una vez usado pierde el poder, este le permite romper bloques, si los rompe la serpiente crece cinco unidades,
 * sin embargo tambien se pueden destruir frutas y sorpresas con este y si el modo de juego es multijugador permite
 * atacar al contrincante lanzando la estrella de fuego sobre el cuerpo de este, lo cual genera que el cuerpo del
 * contrincante se parta en el lugar en el que dio la estrella de fuego
 *  *
 * Autor
 * @NathaliaGarcia
 * @Ricardo Olarte
 * Version
 * @2021-1
 */

public class EstrellaFuego extends Sorpresa{


    public EstrellaFuego(){
        super("EstrellaFuego");
    }

    /**
     * Permite a la serpiente disparar la estrella de fuego
     * @param serpiente que atrapo la estrella de fuego
     */
    public  void efectoSorpresa(Serpiente serpiente){
        Juego.bolasFuego.add(new BolaDeFuego(serpiente.getDireccion(),serpiente.getxPosicion(),serpiente.getyPosicion(),serpiente));
    }

}
