package Aplicacion;

import java.awt.*;

/**
 * Clase que representa las caracteristicas de un rectangulo
 * Autor
 * @NathaliaGarcia
 * @Ricardo Olarte
 * Version
 * @2021-1
 */

public class Rectangulo {

    /**
     * Atributos de la clase Rectangulo
     */
    private int altura;
    private int base;
    private int xPosicion;
    private  int yPosicion;
    private Color color;

    /**
     * Constructor de rectangulo
     */
    public Rectangulo(int altura, int base){
        this.altura = altura;
        this.base = base;
    }
}
