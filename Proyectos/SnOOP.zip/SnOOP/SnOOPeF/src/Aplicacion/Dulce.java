package Aplicacion;

/**
 * Clase que representa uno de los alimentos del juego, se puede presentar en los colores verde, azul, amarillo y rojo
 * y se ubica en el tablero del juego de manera aleatoria. La serpiente que lo consume disminuye su tamaño en una unidad
 * en modo de juego solitario, si es multijugador y el color del dulce y la cerpiente contrincante son iguales su longitud
 * disminuye en dos unidades
 * Autor
 * @NathaliaGarcia
 * @Ricardo Olarte
 * Version 1
 * @2021-05-23
 */

public class Dulce extends Comida{

    public Dulce(){
        super("Dulce");
    }
    /**
     * Permite disminuir el tamaño de la serpiente que consume el dulce
     * @param serpiente que consume el dulce
     */
    public void efectoComida(Serpiente serpiente){
        serpiente.disminuirTamano(color);
    }
}
