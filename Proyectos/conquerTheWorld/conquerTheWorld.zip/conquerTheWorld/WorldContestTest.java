import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class WorldContestTest.
 *
 * @author  Acosta
 * @author  Olarte
 * @version 2021-2
 */
public class WorldContestTest
{
    private WorldContest wc;
    int n1 = 3, n2 = 6, n3 = 3;
    int[][] routes1 = {{1,2,5},{3,1,5}}, armies1 = {{2,1},{5,0},{1,3}};
    int[][] routes2 = {{1,2,2},{1,3,5},{1,4,1},{2,5,5},{2,6,1}},armies2 = {{0,0},{1,0},{2,1},{2,1},{0,1},{0,1}};
    int[][] routes3 = {{1,2,5},{3,1,5}}, armies3 = {{0,1},{1,0},{1,3}};
    
    // int nations1 = 3;
    // int[][] routes1 = {{1, 2, 5},{3, 1, 5}};
    // int[][] armies1 = {{2, 1},{5, 0},{1, 3}};
    
    // int nations2 = 6;
    // int[][] routes2 = {{1, 2, 2},{1, 3, 5},{1, 4, 1},{2, 5, 5},{2, 6, 1}};
    // int[][] armies2 = {{0, 0},{1, 0},{2, 1},{2, 1},{0, 1},{0, 1}};

    // int nations4 = 4;
    // int[][] routes4 = {{1, 3, 5},{1, 2, 1}, {2, 3, 1}};
    // int[][] armies4 = {{7, 3},{1, 3},{1, 3}, {0, 0}};

    // int nations7 = 4;
    // int[][] routes7 = {{1, 3, 5},{1, 2, 1}, {2, 3, 1}};
    // int[][] armies7 = {{3, 3},{3, 3},{3, 3}, {0, 0}};

    // int nations3 = 4;
    // int[][] routes3 = {{1, 3, 5},{1, 2, 1}, {2, 3, 1}};
    // int[][] armies3 = {{1, 3},{1, 3},{1, 3}, {0, 0}};

    // int nations5 = 4;
    // int[][] routes5 = {{1, 3, 5},{1, 2, 1}, {2, 3, 1}};
    // int[][] armies5 = {{3, 3},{1, 3},{1, 3}, {0, 0}};

    // int nations6 = 4;
    // int[][] routes6 = {{1, 3, 5},{1, 2, 1}, {2, 3, 1}};
    // int[][] armies6 = {{3, 3},{2, 3},{1, 3}, {0, 0}};

    WorldContest contest = new WorldContest();
    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @BeforeEach
    public void setUp()
    {
        wc = new WorldContest();
    }
    
    @Test
    public void shouldAOsolveProblem(){}
    
    @Test
    public void shouldAOnotSolveProblem(){}
    
    @Test
    public void segunSAdeberiaResolver() {
        assertTrue(contest.solve(n1, routes1, armies1) == 15);
        assertTrue(contest.ok());
        assertTrue(contest.solve(n2, routes2, armies2) == 9);
        assertTrue(contest.ok());
    }
    
    /**
     * Prueba para solve.
     * No debería resolver el problema de la maratón debido a que no hay suficientes ejércitos.
     */
    @Test
    public void segunSAnoDeberiaResolver() {
        contest.solve(n3, routes3, armies3);
        assertFalse(contest.ok());
    }
    
    @Test
    public void segunOVDeberiaResolverBienElProblema(){
        // assertEquals(15, WorldContest.solve(nations1, routes1, armies1));
        // assertTrue(WorldContest.ok());
        // assertEquals(9, WorldContest.solve(nations2, routes2, armies2));
        // assertTrue(WorldContest.ok());
        // assertEquals(6, WorldContest.solve(nations4, routes4, armies4));
        // assertTrue(WorldContest.ok());
        // assertEquals(0, WorldContest.solve(nations7, routes7, armies7));
        // assertTrue(WorldContest.ok());
    }

    /**
     * Metodo que prueba en World si no resuelve los problemas imposibles de resolver
     */
    @Test
    public void segunOVNoDeberiaRetornarUnResultadoIncorrecto(){
        // assertEquals(0, WorldContest.solve(nations3, routes3, armies3));
        // assertFalse(WorldContest.ok());
        // assertEquals(0, WorldContest.solve(nations5, routes5, armies5));
        // assertFalse(WorldContest.ok());
        // assertEquals(0, WorldContest.solve(nations6, routes6, armies6));
        // assertFalse(WorldContest.ok());
    }

    /**
     * Metodo que prueba en World si el metodo ok es funcional para cada caso
     */
    @Test
    public void segunOVDeberiaHacerBienElOk(){
        // assertEquals(15, WorldContest.solve(nations1, routes1, armies1));
        // assertTrue(WorldContest.ok());
        // assertEquals(9, WorldContest.solve(nations2, routes2, armies2));
        // assertTrue(WorldContest.ok());
        // assertEquals(6, WorldContest.solve(nations4, routes4, armies4));
        // assertTrue(WorldContest.ok());
        // assertEquals(0, WorldContest.solve(nations7, routes7, armies7));
        // assertTrue(WorldContest.ok());
        // assertEquals(0, WorldContest.solve(nations3, routes3, armies3));
        // assertFalse(WorldContest.ok());
        // assertEquals(0, WorldContest.solve(nations5, routes5, armies5));
        // assertFalse(WorldContest.ok());
        // assertEquals(0, WorldContest.solve(nations6, routes6, armies6));
        // assertFalse(WorldContest.ok());
    }
    
    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @AfterEach
    public void tearDown()
    {
    }
}
