/**
 * Nation class, it's represented as circles on the map
 * 
 * @Acosta - Olarte 
 * @2021-2
 */
public class Route
{  
    private int x;
    private int y;
    private int fx;
    private int fy;
    private int cost;
    
    /**
     * Constructor for objects of class Route
     */
    public Route(int x, int y, int fx, int fy, int cost)
    {
        this.x = x;
        this.y = y;
        this.fx = fx;
        this.fy = fy;
        this.cost = cost;
    }

    /**
     * Makes Route visible
     */
    public void makeVisible()
    {
        Canvas canvas = Canvas.getCanvas();
        canvas.draw(this,"cyan",new java.awt.geom.Line2D.Double(x,y,fx,fy));
    }
    
    /**
     * Makes Route invisible
     */
    public void makeInvisible(){
        Canvas canvas = Canvas.getCanvas();
        canvas.erase(this);
    }
    
    /**
     * @return int[], its integer list, contains a positions of the second node
     */
    public int[] getPositions(){
        int[] positions = {this.fx,this.fy};
        return positions;
    }
}