/**
 * Nation class, it's represented as circles on the map
 * 
 * @author Acosta
 * @author Olarte
 * @version 2021-2
 */
public class Route
{  
    protected Nation a;
    protected Nation b;
    protected int cost;
    /**
     * Constructor for objects of class Route
     */
    public Route(Nation a, Nation b, int cost){
        this.a = a;
        this.b = b;
        this.cost = cost;
    }

    /**
     * Makes Route visible
     */
    public void makeVisible()
    {
        Canvas canvas = Canvas.getCanvas();
        canvas.draw(this, "cyan", new java.awt.geom.Line2D.Double(a.getX() + 50, a.getY() + 50, b.getX() + 50,b.getY() + 50));
    }
    
    /**
     * Makes Route invisible
     */
    public void makeInvisible(){
        Canvas canvas = Canvas.getCanvas();
        canvas.erase(this);
    }
    
    /**
     * 
     */
    public boolean bothNation(Nation a, Nation b){
        return (this.a==a || this.b == a) && (this.a==b || this.b == b);
    }
    
    /**
     * Set a new Nation in a or b, because, it is the nation conquered
     */
    public void setNewNation(Nation c){
        if(a.equals(c)){
            this.b = c;
        }else{
            this.a = c;
        }
    }
    
    /**
     * @return int[], its integer list, contains a positions of the second node
     */
    public int[] getPositions(){
        int[] positions = {b.getX(),b.getY()};
        return positions;
    }
    
    /**
     * @return cost of the route
     */
    public int getCost(Nation c){
        if(c.equals(a)){
            return cost + b.getArmies();
        }
        return cost + a.getArmies();
    }
    
    /**
     * @return
     */
    public String getType(){
        return "normal";
    }
    
    /**
     * @return cost of the route
     */
    public int getCostRoute(){
        return cost;
    }
    
    /**
     * @return
     * @param c, its the name nation, if the this route has it
     */
    public boolean routeNations(String c){
        return c.equals(this.a.getColor()) || c.equals(this.b.getColor());
    }
    
    /**
     * @return if the nation a can attack nation b
     */
    public boolean attack(){
        int armyTemp = a.getArmies() - cost - b.getArmies();
        if(armyTemp >= 0){
            a.setArmies(a.getArmies() - cost);
            b.setArmies(-(a.getArmies() + cost));
            b.attacked(a,armyTemp);
            return true;
        }
        return false;
    }
    
    /**
     * Delete this route
     */
    public void delRoute(){
        a.delRoute(b.getColor());
        b.delRoute(a.getColor());
    }
}