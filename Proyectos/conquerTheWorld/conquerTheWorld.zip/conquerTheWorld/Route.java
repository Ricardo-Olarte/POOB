/**
 * Nation class, it's represented as circles on the map
 * 
 * @Acosta - Olarte 
 * @2021-2
 */
public class Route
{  
    private int x;
    private int y;
    private int fx;
    private int fy;
    
    /**
     * Constructor for objects of class Route
     */
    public Route(int x, int y, int fx, int fy)
    {
        this.x = x;
        this.y = y;
        this.fx = fx;
        this.fy = fy;
    }

    /**
     * Makes Route visible
     */
    public void makeVisible()
    {
        Canvas canvas = Canvas.getCanvas();
        canvas.draw(this,"cyan",new java.awt.geom.Line2D.Double(x,y,fx,fy));
    }
    
    /**
     * Makes Route invisible
     */
    public void makeInvisible(){
        Canvas canvas = Canvas.getCanvas();
        canvas.erase(this);
    }
}