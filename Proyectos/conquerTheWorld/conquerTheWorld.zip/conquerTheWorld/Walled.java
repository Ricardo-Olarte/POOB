
/**
 * Write a description of class Walled here.
 * 
 * @author Acosta
 * @author Olarte
 * @version 2021-2
 */
public class Walled extends Nation
{
    private String type;
    
    /**
     * Constructor for objects of class Walled
     */
    public Walled(String type,String color, int x, int y, int armies){
        super(type,color,x,y,armies);
        this.type = "walled";
    }
    
    /**
     * Try to conquer, but don't leave these army
     */
    @Override
    public void tryConquer(){
    }
    
    /**
     * @return
     */
    @Override
    public String getType(){
        return type;
    }
}
