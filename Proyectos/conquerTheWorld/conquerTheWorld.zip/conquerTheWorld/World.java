import java.util.*;
// Nación: rectangle, army: triangle
/**
 * Conquer the world simulator
 * 
 * @Acosta - Olarte 
 * @2021-2
 */
public class World
{
    
    private int length;
    private int width;
    private int x;
    private int y;
    private ArrayList<Nation> nations;
    private ArrayList<Route> routes;
    private String color;
    private Rectangle background;

    /**
     * Constructor for objects of class World
     */
    public World(int length, int width)
    {
        this.length = length;
        this.width = width;
        background = new Rectangle(length, width, 0, 0);
        nations = new ArrayList<Nation>();
        routes = new ArrayList<Route>();
    }
    
    /**
     * Add nation in the World
     * @param String color,its a skin of the nation
     * @param int x, its a position horizontal in the World
     * @param int y, its a position vertical in the World
     * @param int_armies, its a quantity of the armies
     */
    public void addNation(String color,int x,int y,int int_armies){
        Nation nation = new Nation(color, x, y, int_armies);
        nations.add(nation);
    }
    
    /**
     * Add a new route when has a two nodes A and B
     * @param String locationA, its a first node
     * @param String locationB, its a second node
     * @param int int_cost, its a quantity of the cost
     */
    public void addRoute(String locationA,String locationB,int int_cost){ //guardar costo?
        for(Nation n:nations){
            if(n.getColor() == locationA || n.getColor() == locationB){
                n.setRoute(locationA, locationB);
                for(Nation n1:nations){
                    if(n1.getColor() == locationA || n1.getColor() == locationB){
                        
                    }
                }
            }
        }
    }
    
    /**
     * Draws line between two points
     * @param int x first point X coordinate
     * @param int y first point Y coordinate
     * @param int fx second point X coordinate
     * @param int fy second point Y coordinate
     */
    private void drawRoute(int x, int y, int fx, int fy){
        Canvas canvas = Canvas.getCanvas();
        canvas.draw(this, "cyan", new java.awt.geom.Line2D.Double(x + 50, y + 50, fx + 50,fy + 50));
    }
    
    /**
     * Draws line between two points
     * @param int x first point X coordinate
     * @param int y first point Y coordinate
     * @param int fx second point X coordinate
     * @param int fy second point Y coordinate
     */
    public void eraseRoute(int x, int y, int fx, int fy){
        Canvas canvas = Canvas.getCanvas();
        canvas.draw(this, "gray", new java.awt.geom.Line2D.Double(x + 50, y + 50, fx,fy));
    }
    
    /**
     * Puts the army in a given location
     * @param String location, its the location to put the army
     */
    public void putArmy(String location){
        for(Nation n:nations){
            if(n.getColor() == location){
                n.setArmy();
            }
        }
    }
    
    /**
     * Deletes Nation of a given color
     * @param String color, delete a specific nation
     */
    public void delNation(String color){
        String tempColor;
        for(int i=0;i<nations.size();i++){
            tempColor = nations.get(i).getColor();
            if(tempColor == color){
                nations.remove(i);
            }
        }
    }
    
    /**
     * Deletes street in two nodes
     * @param String locationA, its the first node
     * @param String locationB, its the second node
     */
    public void delStreet(String locationA,String locationB){
        for(Nation n:nations){
            if(n.getColor() == locationA || n.getColor() == locationB){
                n.delRoute(locationA,locationB);
            }
        }
    }
    
    /**
     * Deletes an Army in a specific location
     * @param String location, its the place where Army is located
     */
    public void removeArmy(String location){
        for(Nation n:nations){
            if(n.getColor() == location){
                n.delArmy();
            }
        }
    }
    
    /**
     * Move the army an another route
     * @param String locationA, its the first node
     * @param String locationB, its the second node
     */
    public void moveArmyOneRoute(String locationA,String locationB){
    }
    
    /**
     * Its all nations conquered
     * @return String[], its all nations coquered
     */
    public String[] conqueredNations(){
        return null;
    }
    
    /**
     * @return int
     */
    public int payments(){
        return -1;
    }
    
    /**
     * Its when the world was conquer for specific nation
     * @returns boolean, indicate if the world was conquer
     */
    public boolean conquer(){
        return false;
    }
    
    /**
     * Makes World, Nations, Armies and routes Visible
     */
    public void makeVisible(){
        ArrayList<Route> routes = new ArrayList<Route>();
        background.makeVisible();
        for(Nation n:nations){
            n.makeVisible();
        }
        for(Route r:routes){
            r.makeVisible();
        }
    }
    
    /**
     * Makes World Invisible
     */
    public void makeInvisible(){
        background.makeInvisible();
        for(Nation n:nations){ 
            n.makeInvisible();
        }
        for(Route r:routes){
            r.makeInvisible();
        }
    }
    
    /**
     * Finishes the simulator
     */
    public void finish(){
        System.exit(0);
    }
    
    /**
     * Its a the last movement of the simulator
     * @return boolean, if the movement can do it its true, else false
     */
    public boolean ok(){
        return false;
    }
}
