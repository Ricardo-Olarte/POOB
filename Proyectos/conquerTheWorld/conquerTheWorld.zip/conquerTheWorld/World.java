import java.util.*;
// Nación: rectangle, army: triangle
/**
 * Its a simulator class, about the conquer all of the World
 * 
 * @Acosta - Olarte 
 * @2021-2
 */
public class World
{
    
    private int length;
    private int width;
    private int x;
    private int y;
    private ArrayList<String[]> nations;
    private ArrayList<String[]> citys;
    private ArrayList<String[]> routes;
    private ArrayList<int[]> armys;
    private ArrayList<int[]> positions;
    private String color;

    /**
     * Constructor for objects of class World
     */
    public World(int length, int width)
    {
        this.length = length;
        this.width = width;
        nations = new ArrayList<String[]>();
        citys = new ArrayList<String[]>();
        routes = new ArrayList<String[]>();
        positions = new ArrayList<int[]>();
        armys = new ArrayList<int[]>();
    }
    
    /**
     * Add nation in the World
     * @param String color,its a skin of the nation
     * @param int x, its a position horizontal in the World
     * @param int y, its a position vettical in the World
     * @param int_armies, its a quantity of the army
     */
    public void addNation(String color,int x,int y,int int_armies){
        String[] nation = new String[1];
        int[] position = new int[2];
        int[] army = new int[1];
        nation[0] = color;
        position[0] = x;
        position[1] = y;
        army[0] = int_armies;
        nations.add(nation);
        positions.add(position);
        armys.add(army);
    }
    
    /**
     * Add a new route when has a two nodes A and B
     * @param String locationA, its a first node
     * @param String locationB, its a second node
     * @param int int_cost, its a quantity of the cost
     */
    public void addRoute(String locationA,String locationB,int int_cost){
        String[] route = new String[2];
        route[0] = locationA;
        route[1] = locationB;
        routes.add(route);
    }
    
    /**
     * Its a Army and put in a location
     * @param String location, its a place of the Army
     */
    public void putArmy(String location){
    }
    
    /**
     * Its a nation deleted for the color skin
     * @param String color, delete a specific nation
     */
    public void delNation(String color){
        String[] tempColor;
        for(int i=0;i<nations.size();i++){
            tempColor = nations.get(i);
            if(tempColor[0] == color){
                nations.remove(i);
            }
        }
    }
    
    /**
     * Its elminitation street in two nodes
     * @param String locationA, its the first node
     * @param String locationB, its the second node
     */
    public void delStreet(String locationA,String locationB){
        String[] tempColor;
        for(int i=0;i<routes.size();i++){
            tempColor = routes.get(i);
            if(tempColor[0] == locationA && tempColor[1] == locationB){
                routes.remove(i);
            }
        }
    }
    
    /**
     * Its a elmination of the Army in that location
     * @param String location, its the place where Army that located
     */
    public void removeArmy(String location){
    }
    
    /**
     * Move the army an another route
     * @param String locationA, its the first node
     * @param String locationB, its the second node
     */
    public void moveArmyOneRoute(String locationA,String locationB){
    }
    
    /**
     * Its all nations conquered
     * @return String[], its all nations coquered
     */
    public String[] conqueredNations(){
        return null;
    }
    
    /**
     * @return int
     */
    public int payments(){
        return -1;
    }
    
    /**
     * Its when the world was conquer for specific nation
     * @returns boolean, indicate if the world was conquer
     */
    public boolean conquer(){
        return false;
    }
    
    /**
     * Makes World Visible
     */
    public void makeVisible(){
    }
    
    /**
     * Makes World Invisible
     */
    public void makeInvisible(){}
    
    /**
     * Finished the simulator
     */
    public void finish(){}
    
    /**
     * Its a the last movement of the simulator
     * @return boolean, if the movement can do it its true, else false
     */
    public boolean ok(){
        return false;
    }
}
