import java.util.*;

/**
 * Conquer the world simulator
 * 
 * @author Acosta
 * @author Olarte
 * @version 2021-2
 */
public class World
{
    private int length;
    private int width;
    private int x;
    private int y;
    private int nations;
    private int pos;
    private int allCost;
    private int colorN;
    private int totalCost;
    private int[][] routes;
    private int[][] armies;
    private boolean isOk;
    private String color;
    private Rectangle background;
    private Random random;
    private ArrayList<Nation> allNations;
    private ArrayList<String> nameNations;
    private ArrayList<String> actions;
    
    /**
     * Constructor for objects of class World
     * @param length, its the size of the world
     * @param width. its the size of the world
     */
    public World(int length,int width)
    {
        this.length = length;
        this.width = width;
        background = new Rectangle(length, width, 0, 0);
        allNations = new ArrayList<Nation>();
        actions = new ArrayList<String>();
        nameNations = new ArrayList<String>();
        actions.add("begin");
        isOk = true;
        pos = 0; totalCost = 0;
        allCost = 0;
        colorN = 0;
    }
    
    /**
     * Second constructor for objects of class World
     * @param nations, its the quantity of the nations
     * @param routes[][],its a vector, where Xi its the conexion of each nation
     * @param armies[][],Xi its a quantity nation'll have with armys
     */
    public World(int nations,int[][] routes,int[][] armies){
        this.nations = nations;
        this.routes = routes;
        this.armies = armies;
        x = 0;y = 0;totalCost = 0;pos = 0;allCost = 0;colorN = 0;length = 720;width = 1080;
        actions = new ArrayList<String>();
        background = new Rectangle(length, width, 0, 0);
        allNations = new ArrayList<Nation>();
        nameNations = new ArrayList<String>();
        isOk = true;
        for(int i=0;i<nations;i++){
            if(x>700){
                x = 0;
                y += 150;
            }
            if(y>1200){
                y = 0;
            }
            Nation nation = new Nation(color, x, y, armies[i][0]);
            allNations.add(nation);
            x += 150;
        }
        for(int i=0;i<nations-1;i++){
            addRoute(allNations.get(routes[i][0]-1).getColor(),allNations.get(routes[i][1]-1).getColor(),routes[i][2]);
        }
    }
    
    /**
     * Add nation in the World
     * @param color,its a skin of the nation
     * @param x, its a position horizontal in the World
     * @param y, its a position vertical in the World
     * @param int_armies, its a quantity of the armies
     */
    public void addNation(String color,int x,int y,int int_armies){
        Nation nation = new Nation(color, x, y, int_armies);
        if(!(nameNations.contains(color))){
            allNations.add(nation);
            actions.add("AddNation");
            nameNations.add(color);
        }else{
            isOk = false;
            ok();
        }
    }
    
    /**
     * Add nation in the World
     * @param type, its the other thing about nation
     * @param color,its a skin of the nation
     * @param x, its a position horizontal in the World
     * @param y, its a position vertical in the World
     * @param int_armies, its a quantity of the armies
     */
    public void addNation(String type,String color,int x,int y,int int_armies){
        if(type == "normal"){
            Nation nation = new Nation(color, x, y, int_armies);
            if(!(nameNations.contains(color))){
                allNations.add(nation);
                actions.add("AddNation");
                nameNations.add(color);
            }else{
                isOk = false;
                ok();
            }
        }
        if(type == "walled"){
            Walled nation = new Walled(color, x, y, int_armies);
            if(!(nameNations.contains(color))){
                allNations.add(nation);
                actions.add("AddNation");
                nameNations.add(color);
            }else{
                isOk = false;
                ok();
            }
        }
        if(type == "aggressive"){
            Aggressive nation = new Aggressive(color, x, y, int_armies);
            if(!(nameNations.contains(color))){
                allNations.add(nation);
                actions.add("AddNation");
                nameNations.add(color);
            }else{
                isOk = false;
                ok();
            }
        }
    }
    
    /**
     * Add a new route when has a two nodes A and B
     * @param locationA, its a first node
     * @param locationB, its a second node
     * @param int_cost, its a quantity of the cost
     */
    public void addRoute(String locationA,String locationB,int int_cost){
        for(Nation n:allNations){
            if(locationA == n.getColor()){
                for(Nation n1:allNations){
                    if(locationB == n1.getColor()){
                        n.setRoute("normal",n1, int_cost);
                        n1.setRoute("normal",n, int_cost);
                    }
                }
            }
        }
        actions.add("AddRoute");
    }
    
    /**
     * Add a new route when has a two nodes A and B
     * @param locationA, its a first node
     * @param locationB, its a second node
     * @param int_cost, its a quantity of the cos
     */
    public void addRoute(String type,String locationA,String locationB,int int_cost){
        for(Nation n:allNations){
            if(locationA == n.getColor()){
                for(Nation n1:allNations){
                    if(locationB == n1.getColor()){
                        n.setRoute(type, n1, int_cost);
                        n1.setRoute(type, n, int_cost);
                    }
                }
            }
        }
        actions.add("AddRoute");
    }
    
    /**
     * Puts the army in a given location
     * @param location, its the location to put the army
     */
    public void putArmy(String location){
        for(Nation n:allNations){
            if(n.getColor() == location){
                n.setArmy("normal");
            }
        }
    }
    
    /**
     * Puts the army in a given location
     * @param location, its the location to put the army
     */
    public void putArmy(String type, String location){
        for(Nation n:allNations){
            if(n.getColor() == location){
                n.setArmy(type);
            }
        }
    }
    
    /**
     * Deletes Nation of a given color
     * @param color, delete a specific nation
     */
    public void delNation(String color){
        String tempColor;
        for(int i=0;i<allNations.size();i++){
            tempColor = allNations.get(i).getColor();
            if(tempColor == color){
                allNations.remove(i);
            }
        }
    }
    
    /**
     * Deletes street in two nodes
     * @param locationA, its the first node
     * @param locationB, its the second node
     */
    public void delRoute(String locationA,String locationB){
        for(Nation n:allNations){
            if(n.getColor() == locationA){
                for(Nation n1: allNations){
                    if(n1.getColor() == locationB){
                        n.delRoute(n1.getX(), n1.getY());
                        n1.delRoute(n.getX(), n.getY());
                    }
                }
            }
        }
    }
    
    /**
     * Deletes an Army in a specific location
     * @param location, its the place where Army is located
     */
    public void removeArmy(String location){
        for(Nation n:allNations){
            if(n.getColor() == location){
                n.delArmy();
            }
        }
    }
    
    /**
     * Move the army an another route
     * @param locationA, its the first node
     * @param locationB, its the second node
     */
    public void moveArmyOneRoute(String locationA,String locationB){
        for(Nation n:allNations){
            if(n.getColor()==locationB){
                for(Nation n1:allNations){
                    if(n1.getColor()==locationA){
                        n.setArmies(n1.getArmies());
                        removeArmy(locationA);
                        allCost += n.getCostRoute(n1.getColor());
                    }
                }
            }
        }
    }
    
    /**
     * Move all army
     * @param nationA, its one node
     * @param nationB, its a second node
     */
    public void moveArmy(String nationA,String nationB){
        for(Nation n:allNations){
            if(n.getColor()==nationA){
                for(Nation n1:allNations){
                    if(n1.getColor()==nationB){
                        n1.setArmies(n.getArmies());
                        allCost += n.getCostRoute(n1.getColor());
                    }
                }
            }
        }
    }
   
    /**
     * @param nation, try to conquer other nations
     */
    public void tryToConquer(String nation){
        for(Nation n:allNations){
            if(n.getColor() == nation){
                n.tryConquer();
                totalCost += n.getTotalCost();
            }
        }
    }
    
    /**
     * @return arraylist<Nation>, its a  container when has all allNations
     */
    public ArrayList<Nation> getWorld(){
        return allNations;
    }
    
    /**
     * Its all allNations conquered
     * @return its all allNations coquered
     */
    public String[] conqueredNations(){
        String[] tempConquer = new String[allNations.size()];
        for(int i=0;i<allNations.size();i++){
            tempConquer[i] = allNations.get(i).getColor();
        }
        return tempConquer;
    }
    
    /**
     * @return allCost, sum all cost of the route when the nation used the route
     */
    public int payments(){
        return allCost;
    }
    
    /**
     * Its when the world was conquer for specific nation
     * @returns boolean, indicate if the world was conquer
     */
    public boolean conquer(){
        for(int i=1;i<allNations.size() - 1;i++){
            if(allNations.get(i-1).getColor() != allNations.get(i).getColor()){
                return false;
            }
        }
        return true;
    }
    
    /**
     * Makes World, allNations, Armies and routes Visible
     */
    public void makeVisible(){
        background.makeVisible();
        for(Nation n:allNations){
            n.makeVisible();
        }
        actions.add("makeVisible");
    }
    
    /**
     * Makes World Invisible
     */
    public void makeInvisible(){
        background.makeInvisible();
        for(Nation n:allNations){ 
            n.makeInvisible();
        }
        actions.add("makeInvisible");
    }
    
    /**
     * @return String, is a color of the random
     */
    public String randomColor(){
        String[] temp = {"red","blue","yellow","magenta","white","orange","gray","cyan"};
        colorN = (colorN+1>=8)?0:colorN+1;
        // String hexadecimal = "";
        // String caracteresHexadecimales = "0123456789abcdef";
        // while (colorN > 0) {
            // int residuo = colorN % 16;
            // hexadecimal = caracteresHexadecimales.charAt(residuo) + hexadecimal;
            // colorN /= 16;
        // }
        return temp[colorN];
    }
    
    /**
     * Comeback the last action
     */
    public void undo(){
        pos--;
        if(pos>=1){
            if(actions.get(pos).equals("makeVisible")){
                makeVisible();
            }
            if(actions.get(pos).equals("makeInvisible")){
               makeInvisible(); 
            }
            if(actions.get(pos).equals("addNation")){
                allNations.remove(pos);
            }
            if(actions.get(pos).equals("addRoute")){
                allNations.remove(pos);
            } 
        }else{
            isOk = false;
            ok();
        }
    }
    
    /**
     * Do again the next action
     */
    public void redo(){
        pos++;
        if(pos<actions.size()){
            if(actions.get(pos).equals("makeVisible")){
               makeVisible(); 
            }
            if(actions.get(pos).equals("makeInvisible")){
               makeInvisible(); 
            }
        }else{
            isOk = false;
            ok();
        }
    }
    
    /**
     * Finishes the simulator
     */
    public void finish(){
        System.exit(0);
    }
    
    /**
     * Its a the last movement of the simulator
     * @return if the movement can do it its true, else false
     */
    public boolean ok(){
        if(!isOk){
            System.out.println("Can't do it");
            return false;
        }
        return true;
    }
    
    /**
     * @return sum of the cost each one route
     */
    public int getTotalCost(){
        return totalCost;
    }
    
    //{{1,2,5},{3,1,5}}
    //{{2,1},{5,0},{1,3}}
}