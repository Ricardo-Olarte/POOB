import java.util.*;
// Nación: rectangle, army: triangle
/**
 * Conquer the world simulator
 * 
 * @Acosta - Olarte 
 * @2021-2
 */
public class World
{
    private int length;
    private int width;
    private int x;
    private int y;
    private int nations;
    private int pos;
    private int[][] routes;
    private int[][] armies;
    private String color;
    private Rectangle background;
    private Random random;
    private ArrayList<Nation> allNations;
    private ArrayList<String> actions;
    private ArrayList<Boolean> isConquered;
    /**
     * Constructor for objects of class World
     */
    public World(int length,int width)
    {
        this.length = length;
        this.width = width;
        background = new Rectangle(length, width, 0, 0);
        allNations = new ArrayList<Nation>();
        actions.add("begin");
        pos = 0;
    }
    
    /**
     * Second constructor for objects of class World
     */
    public World(int nations,int routes[][],int armies[][]){
        this.nations = nations;
        this.routes = routes;
        this.armies = armies;
        x = 0;
        y = 0;
        pos = 0;
        length = 720;
        width = 1080;
        background = new Rectangle(length, width, 0, 0);
        allNations = new ArrayList<Nation>();
        for(int i=0;i<nations;i++){
            if(x>700){
                x = 0;
                y += 150;
            }
            if(y>1200){
                y = 0;
            }
            addNation(randomColor(),x,y,armies[i][0]);
            x += 150;
        }
        for(int i=0;i<routes.length;i++){
            addRoute(allNations.get(routes[i][0]-1).getColor(),allNations.get(routes[i][1]-1).getColor(),routes[i][2]);
        }
    }
    
    /**
     * Add nation in the World
     * @param String color,its a skin of the nation
     * @param int x, its a position horizontal in the World
     * @param int y, its a position vertical in the World
     * @param int_armies, its a quantity of the armies
     */
    public void addNation(String color,int x,int y,int int_armies){
        Nation nation = new Nation(color, x, y, int_armies);
        allNations.add(nation);
    }
    
    /**
     * Add a new route when has a two nodes A and B
     * @param String locationA, its a first node
     * @param String locationB, its a second node
     * @param int int_cost, its a quantity of the cost
     */
    public void addRoute(String locationA,String locationB,int int_cost){
        for(Nation n:allNations){
            if(locationA == n.getColor()){
                for(Nation n1:allNations){
                    if(locationB == n1.getColor()){
                        n.setRoute(n1.getX(), n1.getY(), int_cost);
                        n1.setRoute(n.getX(), n.getY(), int_cost);
                    }
                }
            }
        }
    }
    
    /**
     * Puts the army in a given location
     * @param String location, its the location to put the army
     */
    public void putArmy(String location){
        for(Nation n:allNations){
            if(n.getColor() == location){
                n.setArmy();
            }
        }
    }
    
    /**
     * Deletes Nation of a given color
     * @param String color, delete a specific nation
     */
    public void delNation(String color){
        String tempColor;
        for(int i=0;i<allNations.size();i++){
            tempColor = allNations.get(i).getColor();
            if(tempColor == color){
                allNations.remove(i);
            }
        }
    }
    
    /**
     * Deletes street in two nodes
     * @param String locationA, its the first node
     * @param String locationB, its the second node
     */
    public void delRoute(String locationA,String locationB){
        for(Nation n:allNations){
            if(n.getColor() == locationA){
                for(Nation n1: allNations){
                    if(n1.getColor() == locationB){
                        n.delRoute(n1.getX(), n1.getY());
                        n1.delRoute(n.getX(), n.getY());
                    }
                }
            }
        }
    }
    
    /**
     * Deletes an Army in a specific location
     * @param String location, its the place where Army is located
     */
    public void removeArmy(String location){
        for(Nation n:allNations){
            if(n.getColor() == location){
                n.delArmy();
            }
        }
    }
    
    /**
     * Move the army an another route
     * @param String locationA, its the first node
     * @param String locationB, its the second node
     */
    public void moveArmyOneRoute(String locationA,String locationB){
        for(Nation n:allNations){
            if(n.getColor()==locationB){
                for(Nation n1:allNations){
                    if(n1.getColor()==locationA){
                        n.setArmies(n1.getArmies());
                        removeArmy(locationA);
                    }
                }
            }
        }
    }
    
    /**
     * Move all army
     * @param String nationA, its one node
     * @param String nationB, its a second node
     */
    public void moveArmy(String nationA,String nationB){
        for(Nation n:allNations){
            if(n.getColor() == nationA){
                for(Nation n1:allNations){
                    if(n1.getColor() == nationB){
                        n1.setArmies(n.getArmies());
                    }
                }
                removeArmy(nationA);
            }
        }
    }
    
    /**
     * @param String nation, try to conquer other nations
     */
    public void tryToConquer(String nation){}
    
    /**
     * @return array list, its a  container when has all allNations
     */
    public ArrayList<Nation> getWorld(){
        return allNations;
    }
    
    /**
     * Its all allNations conquered
     * @return String[], its all allNations coquered
     */
    public String[] conqueredNations(){
        String[] tempConquer = new String[allNations.size()];
        for(int i=0;i<allNations.size();i++){
            tempConquer[i] = allNations.get(i).getColor();
        }
        return tempConquer;
    }
    
    /**
     * @return int
     */
    public int payments(){
        return -1;
    }
    
    /**
     * Its when the world was conquer for specific nation
     * @returns boolean, indicate if the world was conquer
     */
    public boolean conquer(){
        for(int i=0;i<allNations.size();i++){
            return false;
        }
        return false;
    }
    
    /**
     * Makes World, allNations, Armies and routes Visible
     */
    public void makeVisible(){
        background.makeVisible();
        for(Nation n:allNations){
            n.makeVisible();
        }
        actions.add("makeVisible");
    }
    
    /**
     * Makes World Invisible
     */
    public void makeInvisible(){
        background.makeInvisible();
        for(Nation n:allNations){ 
            n.makeInvisible();
        }
        actions.add("makeInvisible");
    }
    
    /**
     * @return String, is a color of the random
     */
    public String randomColor(){
        Random numAleatorio = new Random();
        int n = numAleatorio.nextInt(8);
        int cont = 0;
        String[] temp = {"red","blue","yellow","green","magenta","white","orange","gray"};
        ArrayList<String> used = new ArrayList<String>();
        for(int i=0;i<allNations.size();i++){
            used.add(allNations.get(i).getColor());
        }
        while(used.contains(temp[n])){
            n = numAleatorio.nextInt(8);
        }
        return temp[n];
    }
    
    /**
     * Comeback the last action
     */
    public void undo(){
        pos--;
        if(pos>=1){
            if(actions.get(pos).equals("makeVisible")){
                makeVisible();
            }
            if(actions.get(pos).equals("makeInvisible")){
               makeInvisible(); 
            }
            actions.remove(actions.size() - 1);
        }else{
            System.out.println("Can´t do that anymore");
        }
    }
    
    /**
     * Do again the next action
     */
    public void redo(){
        pos++;
        if(pos<actions.size()){
            if(actions.get(pos).equals("makeVisible")){
               makeVisible(); 
            }
            if(actions.get(pos).equals("makeInvisible")){
               makeInvisible(); 
            }
        }else{
            System.out.println("Can´t do that anymore");
        }
    }
    
    /**
     * Finishes the simulator
     */
    public void finish(){
        System.exit(0);
    }
    
    /**
     * Its a the last movement of the simulator
     * @return boolean, if the movement can do it its true, else false
     */
    public boolean ok(){
        return false;
    }
}

// {{1,2,5},{3,1,5}}
// {{2,1},{5,0},{1,3}}