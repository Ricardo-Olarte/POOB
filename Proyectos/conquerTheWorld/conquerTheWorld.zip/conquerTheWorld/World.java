import java.util.*;
// Nación: rectangle, army: triangle
/**
 * Conquer the world simulator
 * 
 * @Acosta - Olarte 
 * @2021-2
 */
public class World
{
    
    private int length;
    private int width;
    private int x;
    private int y;
    private ArrayList<Nation> nations;
    private ArrayList<String[]> cities;
    private ArrayList<int[]> armys;
    private ArrayList<int[]> positions;
    private String color;
    private Rectangle background;

    /**
     * Constructor for objects of class World
     */
    public World(int length, int width)
    {
        this.length = length;
        this.width = width;
        background = new Rectangle(length, width, 0, 0);
        nations = new ArrayList<Nation>();
    }
    
    /**
     * Add nation in the World
     * @param String color,its a skin of the nation
     * @param int x, its a position horizontal in the World
     * @param int y, its a position vertical in the World
     * @param int_armies, its a quantity of the army
     */
    public void addNation(String color,int x,int y,int int_armies){
        Nation nation = new Nation(color, x, y, int_armies);
        nations.add(nation);
    }
    
    /**
     * Add a new route when has a two nodes A and B
     * @param String locationA, its a first node
     * @param String locationB, its a second node
     * @param int int_cost, its a quantity of the cost
     */
    public void addRoute(String locationA,String locationB,int int_cost){
        for(Nation n:nations){
            if(n.getColor() == locationA || n.getColor() == locationB){
                n.setRoute(locationA, locationB);
            }
        }
    }
    
    /**
     * Its a A rmy and put in a location
     * @param String location, its a place of the Army
     */
    public void putArmy(String location){
    }
    
    /**
     * Its a nation deleted for the color skin
     * @param String color, delete a specific nation
     */
    public void delNation(String color){
        String tempColor;
        for(int i=0;i<nations.size();i++){
            tempColor = nations.get(i).getColor();
            if(tempColor == color){
                nations.remove(i);
            }
        }
    }
    
    /**
     * Its elminitation street in two nodes
     * @param String locationA, its the first node
     * @param String locationB, its the second node
     */
    public void delStreet(String locationA,String locationB){
        for(Nation n:nations){
            if(n.getColor() == locationA || n.getColor() == locationB){
                n.delRoute(locationA,locationB);
            }
        }
    }
    
    /**
     * Its a elmination of the Army in that location
     * @param String location, its the place where Army that located
     */
    public void removeArmy(String location){
    }
    
    /**
     * Move the army an another route
     * @param String locationA, its the first node
     * @param String locationB, its the second node
     */
    public void moveArmyOneRoute(String locationA,String locationB){
    }
    
    /**
     * Its all nations conquered
     * @return String[], its all nations coquered
     */
    public String[] conqueredNations(){
        return null;
    }
    
    /**
     * @return int
     */
    public int payments(){
        return -1;
    }
    
    /**
     * Its when the world was conquer for specific nation
     * @returns boolean, indicate if the world was conquer
     */
    public boolean conquer(){
        return false;
    }
    
    /**
     * Makes World Visible
     */
    public void makeVisible(){
        background.makeVisible();
        for(Nation n:nations){
            n.makeVisible();
        }
    }
    
    /**
     * Makes World Invisible
     */
    public void makeInvisible(){
        background.makeInvisible();
        for(Nation n:nations){
            n.makeInvisible();
        }
    }
    
    /**
     * Finished the simulator
     */
    public void finish(){}
    
    /**
     * Its a the last movement of the simulator
     * @return boolean, if the movement can do it its true, else false
     */
    public boolean ok(){
        return false;
    }
}
