
/**
 * Write a description of class Dealer here.
 * 
 * @author Acosta
 * @author Olarte
 * @version 2021-2
 */
public class Dealer extends Route
{
    /**
     * Constructor for objects of class Dealer
     */
    public Dealer(Nation a, Nation b, int cost){
        super(a,b,cost);
    }
    
    @Override
    /**
     * @return if the nation a can attack nation b
     */
    public boolean attack(){
        int armyTemp = a.getArmies() - cost - b.getArmies();
        if(armyTemp >= 0){
            a.setArmies(a.getArmies() - cost);
            b.setArmies(-(a.getArmies() + cost));
            b.attacked(a,armyTemp);
            return true;
        }
        cost += cost;
        return false;
    }
}