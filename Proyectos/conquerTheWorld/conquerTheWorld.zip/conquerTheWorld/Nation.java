import java.util.*;
/**
 * Nation class, it's represented as circles on the map
 * 
 * @author Acosta
 * @author Olarte
 * @version 2021-2
 */
public class Nation
{
    protected String color;
    protected int x;
    protected int y;
    protected int host;
    protected int armies;
    protected int totalCost;
    private String type;
    protected Circle nation;
    protected Army army;
    protected ArrayList<Route> routes;
    
    /**
     * Constructor for objects of class Nation
     * @param String color, its a skin of the nation
     * @param int x, its a position horizontal in the World
     * @param int y, its a position vertical in the World
     * @param int_armies, its a quantity of the armies
     */
    public Nation(String type,String color, int x, int y, int armies){
        this.type = type;
        this.color = color;
        this.x = x;
        this.y = y;
        this.armies = armies;
        this.host = 0;
        totalCost = 0;
        routes = new ArrayList<Route>();
        nation = new Circle(color,x,y,100);
    }
    
    /**
     * Makes Nation visible
     */
    public void makeVisible(){
        nation.makeVisible();
        if(!Objects.isNull(army)){
            army.makeVisible();
        }
        for(Route r: routes){
            r.makeVisible();
        }
    }
    
    /**
     * Makes Nation invisible
     */
    public void makeInvisible(){
        nation.makeInvisible();
        if(!Objects.isNull(army)){
            army.makeInvisible();
        }
        for(Route r: routes){
            r.makeInvisible();
        }
    }
    
    /**
     * @returns Nation color
     */
    public String getColor(){
        return color;
    }
    
    
    
    /**
     * Sets Route
     * @param otherNation, it's the other nation with connected the both nations
     * @param int cost, its the value of the route
     */
    public void setRoute(String type, Nation otherNation, int cost){
        if(type.equals("normal")){}
        Route route = new Route(this, otherNation,cost);
        routes.add(route);
    }
    
    /**
     * Deletes Route
     * @param locationA, it's the color of the country on locationA
     * @param locationB, it's the color of the country on locationB
     */
    public void delRoute(int fx, int fy){
        for(Route r:routes){
            int[] temPositions = r.getPositions();
            if(fx == temPositions[0] && fy == temPositions[1]){
                r.makeInvisible();
                routes.remove(r);         
            }
        }
    }
    
    /**
     * Deletes Route
     * @param locationA, it's the color of the country on locationA
     * @param locationB, it's the color of the country on locationB
     */
    public void delRoute(String locationB){
        for(Route r:routes){
            if(r.routeNations(locationB)){
                r.makeInvisible();
                routes.remove(r);         
            }
        }
    }
    
    /**
     * Sets Army
     */
    public void setArmy(String type){
        this.type = type;
        host += 1;
        army = new Army(this.x,this.y,this.host);
    }
    
    /**
     * Set newArmy, its when the army move another position
     * @paran int, its the newArmy
     */
    public void setArmies(int newArmy){
        int n = host+newArmy;
        if(n<0){
            army.setArmies(x,y,0);
        }else{
            army.setArmies(x,y,host+newArmy);
        }
    }
    
    /**
     * @return the quantity of the armies
     */
    public int getArmies(){
        return host;
    }
    
    /**
     * @return
     */
    public String getType(){
        return type;
    }
    
    /**
     * Deletes Army
     */
    public void delArmy(){
        if(!Objects.isNull(army)){
            army.del();
        }
        army = null;
        this.host = 0;
    }
    
    /**
     * @return 
     */
    public int getCostRoute(String name_b){
        for(Route r: routes){
            if(r.routeNations(name_b)){
                return r.getCostRoute();
            }
        }
        return 0;
    }
    
    /**
     * @return
     */
    public int getX(){
        return x;
    }
    
    /**
     * @return 
     */
    public int getY(){
        return y;
    }
    
    /**
     * @return
     */
    public int getTotalCost(){
        return totalCost;
    }
    
    /**
     * @param b, its the other nation that attack this nation
     */
    public void attacked(Nation b, int armies_enemies){
        makeInvisible();
        this.color = b.getColor();
        delArmy();
        this.armies = armies_enemies + this.armies;
        setArmy(this.type);
        makeVisible();
    }
    
    /**
     * find the menor cost in all routes
     */
    public int menorCost(){
        int n = (int) Float.POSITIVE_INFINITY;
        for(Route r: routes){
            if(r.getCost(this) < n){
                n = r.getCost(this);
            }
        }
        return n;
    }
    
    /**
     * try conquer other nations
     */
    public void tryConquer(){
        int temp = menorCost();
        for(Route r: routes){
            if(temp == r.getCost(this) && temp <= armies){
                int move = temp - r.getCostRoute();
                setArmies(- r.getCostRoute());
                totalCost += r.getCostRoute();
                if(r.getType().equals("weak")){
                    r.delRoute();
                }
            }
        }
    }
}