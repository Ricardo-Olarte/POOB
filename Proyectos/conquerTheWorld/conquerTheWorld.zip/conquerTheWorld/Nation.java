import java.util.*;
/**
 * Nation class, it's represented as circles on the map
 * 
 * @Acosta - Olarte 
 * @2021-2
 */
public class Nation
{
    private String color;
    private int x;
    private int y;
    private int armies;
    private Circle nation;
    private Army army;
    private ArrayList<Route> routes;
    /**
     * Constructor for objects of class Nation
     * @param String color, its a skin of the nation
     * @param int x, its a position horizontal in the World
     * @param int y, its a position vertical in the World
     * @param int_armies, its a quantity of the armies
     */
    public Nation(String color, int x, int y, int armies)
    {
        this.color = color;
        this.x = x;
        this.y = y;
        this.armies = armies;
        routes = new ArrayList<Route>();
        nation = new Circle(color,x,y,100);
    }
    
    /**
     * Makes Nation visible
     */
    public void makeVisible(){
        for(Route r: routes){
            r.makeVisible();
        }
    }
    
    /**
     * Makes Nation invisible
     */
    public void makeInvisible(){
        for(Route r: routes){
            r.makeInvisible();
        }
    }
    
    /**
     * @returns Nation color
     */
    public String getColor(){
        return color;
    }
    
    /**
     * @returns ArrayList that contains every Route on the map
     */
    public ArrayList<Route> getRoute(){
        return routes;
    }
    
    /**
     * Sets Route
     * @param locationA, it's the color of the country on locationA
     * @param locationB, it's the color of the country on locationB
     */
    public void setRoute(int fx, int fy, int cost){
        Route route = new Route(x,y,fx,fy,cost);
        routes.add(route);
    }
    
    /**
     * Deletes Route
     * @param locationA, it's the color of the country on locationA
     * @param locationB, it's the color of the country on locationB
     */
    public void delRoute(int fx, int fy){
        for(Route r:routes){
            int[] temPositions = r.getPositions();
            if(fx == temPositions[0] && fy == temPositions[1]){
                routes.remove(r);         
            }
        }
    }
    
    /**
     * @returns X coordinate
     */
    public int getX(){
        return x;
    }
    
    /**
     * @returns Y coordinate
     */
    public int getY(){
        return y;
    }
    
    /**
     * @returns armies, its the quntity of the army
     */
    public int getArmies(){
        return armies;
    }
    
    /**
     * Sets Army
     */
    public void setArmy(){
        army = new Army(armies);
    }
    
    /**
     * Set newArmy, its when the army move another position
     * @paran int, its the newArmy
     */
    public void setArmies(int newArmy){
        army.setArmies(newArmy);
    }
    
    /**
     * Deletes Army
     */
    public void delArmy(){
        army = null;
    }
    
    /**
     * 
     */
    public int[] getBestRoute(String locationB){
        return null;
    }
}