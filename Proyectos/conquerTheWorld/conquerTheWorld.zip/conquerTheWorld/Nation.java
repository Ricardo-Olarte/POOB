import java.util.*;
/**
 * Write a description of class Nation here.
 * 
 * @Acosta - Olarte 
 * @2021-2
 */
public class Nation
{
    private String color;
    private int x;
    private int y;
    private int armies;
    private Circle nation;
    private ArrayList<String[]> routes;

    /**
     * Constructor for objects of class Nation
     */
    public Nation(String color, int x, int y, int armies)
    {
        this.color = color;
        this.x = x;
        this.y = y;
        this.armies = armies;
        routes = new ArrayList<String[]>();
        nation = new Circle(color,x,y,100);
    }
    
    /**
     * Makes Nation visble
     */
    public void makeVisible(){
        nation.makeVisible();
    }
    
    public void makeInvisible(){
        nation.makeInvisible();
    }
    
    public String getColor(){
        return color;
    }
    
    public void setRoute(String locationA, String locationB){
        String[] route = {locationA, locationB};
        routes.add(route);
    }
    
    public void delRoute(String locationA, String locationB){
        String[] temp;
        for(int i=0;i<routes.size();i++ ){
            temp = routes.get(i);
            if((temp[0] == locationA || temp[0] == locationB) && (temp[1] == locationA || temp[1] == locationB)){
                routes.remove(i);
            }
        }
    }
}