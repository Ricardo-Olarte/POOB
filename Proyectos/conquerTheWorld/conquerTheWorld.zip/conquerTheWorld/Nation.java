import java.util.*;
/**
 * Nation class, it's represented as circles on the map
 * 
 * @Acosta - Olarte 
 * @2021-2
 */
public class Nation
{
    private String color;
    private int x;
    private int y;
    private int armies;
    private Circle nation;
    private ArrayList<Triangle> army;
    private ArrayList<String[]> routes;

    /**
     * Constructor for objects of class Nation
     * @param String color, its a skin of the nation
     * @param int x, its a position horizontal in the World
     * @param int y, its a position vertical in the World
     * @param int_armies, its a quantity of the armies
     */
    public Nation(String color, int x, int y, int armies)
    {
        this.color = color;
        this.x = x;
        this.y = y;
        this.armies = armies;
        routes = new ArrayList<String[]>();
        army = new ArrayList<Triangle>();
        nation = new Circle(color,x,y,100);
    }
    
    /**
     * Makes Nation visible
     */
    public void makeVisible(){
        nation.makeVisible();
        if(army.size()!=0){
            for(Triangle t:army){
                t.makeVisible();
            }
        }
    }
    
    /**
     * Makes Nation invisible
     */
    public void makeInvisible(){
        nation.makeInvisible();
        if(army.size()!=0){
            for(Triangle t:army){
                t.makeInvisible();
            }
        }
    }
    
    /**
     * Returns Nation color
     */
    public String getColor(){
        return color;
    }
    
    /**
     * Returns ArrayList that contains every Route on the map
     */
    public ArrayList<String[]> getRoute(){
        return routes;
    }
    
    /**
     * Sets Route
     * @param locationA, it's the color of the country on locationA
     * @param locationB, it's the color of the country on locationB
     */
    public void setRoute(String locationA, String locationB){
        String[] route = {locationA, locationB};
        routes.add(route);
    }
    
    /**
     * Deletes Route
     * @param locationA, it's the color of the country on locationA
     * @param locationB, it's the color of the country on locationB
     */
    public void delRoute(String locationA, String locationB){
        String[] temp;
        for(int i=0;i<routes.size();i++ ){
            temp = routes.get(i);
            if((temp[0] == locationA || temp[0] == locationB) && (temp[1] == locationA || temp[1] == locationB)){
                routes.remove(i);
            }
        }
    }
    
    /**
     * Returns X coordinate
     */
    public int getX(){
        return x;
    }
    
    /**
     * Returns Y coordinate
     */
    public int getY(){
        return y;
    }
    
    /**
     * Sets Army
     */
    public void setArmy(){
        for(int i=1;i<= armies;i++){
            Triangle triangle = new Triangle();
            triangle.changeColor("red");
            army.add(triangle);
        }
    }
    
    /**
     * Deletes Army
     */
    public void delArmy(){
        army.clear();
    }
}