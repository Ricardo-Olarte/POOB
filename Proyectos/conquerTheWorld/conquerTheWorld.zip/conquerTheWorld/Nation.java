/**
 * Write a description of class Nation here.
 * 
 * @Acosta - Olarte 
 * @2021-2
 */
public class Nation
{
    private String color;
    private int x;
    private int y;
    private int armies;
    private Rectangle nation;

    /**
     * Constructor for objects of class Nation
     */
    public Nation(String color, int x, int y, int armies)
    {
        nation = new Rectangle();
        nation.changeColor(color);
        nation.changePosition(x,y);
    }
    
    /**
     * Makes Nation visble
     */
    public void makeVisible(){
        nation.makeVisible();
    }
}