
/**
 * Write a description of class Aggressive here.
 * 
 * @author Acosta
 * @author Olarte
 * @version 2021-2
 */
public class Aggressive extends Nation

{
    private String type;
    
    /**
     * Constructor for objects of class Aggressive
     */
    public Aggressive(String color, int x, int y, int armies){
        super(color,x,y,armies);
        this.type = "agressive";
    }
    
    /**
     * @param b, its the nation attack this nation
     */
    @Override
    public void attacked(Nation b, int armies_enemies){
    }
}
