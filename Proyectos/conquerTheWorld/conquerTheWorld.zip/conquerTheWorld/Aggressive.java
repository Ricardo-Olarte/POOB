
/**
 * Write a description of class Aggressive here.
 * 
 * @author Acosta
 * @author Olarte
 * @version 2021-2
 */
public class Aggressive extends Nation

{
    private String type;
    
    /**
     * Constructor for objects of class Aggressive
     */
    public Aggressive(String type,String color, int x, int y, int armies){
        super(type,color,x,y,armies);
        this.type = "agressive";
    }
    
    /**
     * Set newArmy, its when the army move another position
     * @paran int, its the newArmy
     */
    public void setArmies(int newArmy){
    }
    
    /**
     * @param b, its the nation attack this nation
     */
    @Override
    public void attacked(Nation b, int armies_enemies){
    }
}
