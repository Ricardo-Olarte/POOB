/**
 * Write a description of class Nation here.
 * 
 * @Acosta - Olarte 
 * @2021-2
 */
public class Army
{
    private String color;
    private Triangle army;
    
    /**
     * Constructor for objects of class Nation
     */
    public Army(String location)
    {
        army = new Triangle();
        
    }
    
    /**
     * Makes Nation visble
     */
    public void makeVisible(){
        army.makeVisible();
    }

}