import java.util.*;
/**
 * Its the army of the some nation
 * 
 * @Acosta
 * @Olarte
 * @version 2021-2
 */
public class Army
{
    private int armies;
    private ArrayList<Triangle> army;
    /**
     * Constructor for objects of class Army
     */
    public Army(int armies)
    {
        this.armies = armies;
        army = new ArrayList<Triangle>();
        for(int i=0;i<armies;i++){
            Triangle triangle = new Triangle();
            army.add(triangle);
        }
    }

    /**
     * Makes visible army of the nation
     */
    public void makeVisible(){
        for(Triangle t: army){
            t.makeVisible();
        }
    }
    
    /**
     * Makes Invisible the army
     */
    public void makeInvisible(){
        for(Triangle t: army){
            t.makeInvisible();
        }
    }
    
    /**
     * put a new army in the actual army
     * @param int, its the number of the new Army
     */
    public void setArmies(int newArmies){
        for(int i=0;i<newArmies;i++){
            Triangle triangle = new Triangle();
            army.add(triangle);
        }
    }
}
