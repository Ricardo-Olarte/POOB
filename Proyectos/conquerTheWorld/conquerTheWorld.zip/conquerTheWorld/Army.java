import java.util.*;

/**
 * Its the army of the some nation
 * 
 * @Acosta
 * @Olarte
 * @version 2021-2
 */
public class Army
{
    protected int armies;
    protected ArrayList<Triangle> army;
    /**
     * Constructor for objects of class Army
     * @param int x,its a horizontal position
     * @param int y, its a vertical position
     * @param int armies, quantity of the army in the nation
     */
    public Army(int x, int y,int armies){
        this.armies = armies;
        army = new ArrayList<Triangle>();
        setArmies(x,y,armies);
    }

    /**
     * Makes visible army of the nation
     */
    public void makeVisible(){
        for(Triangle t: army){
            t.makeVisible();
        }
    }
    
    /**
     * Makes Invisible the army
     */
    public void makeInvisible(){
        for(Triangle t: army){
            t.makeInvisible();
        }
    }
    
    /**
     * Delete the army
     */
    public void del(){
        makeInvisible();
        army.clear();
        armies = 0;
    }
    
    /**
     * put a new army in the actual army
     * @param int x, its a horizontal position
     * @param int y, its a vertical position
     * @param int, its the number of the new Army
     */
    public void setArmies(int x, int y, int newArmies){
        makeInvisible();
        int a = x;
        int b = y;
        int m = 0;
        int n = 0;
        for(int i=0;i<newArmies;i++){
            Triangle triangle = new Triangle();
            triangle.moveHorizontal(a);
            triangle.moveVertical(b);
            a+=33;
            m+=33;
            if(m>99){
                m = 0;
                a = x;
                b += 33;
            }
            if(n>99){
                n = 0;
                a = x;
                b = y;
            }
            army.add(triangle);
        }
    }
}