import java.util.*;
/**
 * Write a description of class Army here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Army
{
    // instance variables - replace the example below with your own
    private int armies;
    private ArrayList<Triangle> army;
    
    /**
     * Constructor for objects of class Army
     */
    public Army(int armies)
    {
        this.armies = armies;
        army = new ArrayList<Triangle>();
        for(int i=0;i<armies;i++){
            Triangle triangle = new Triangle();
            army.add(triangle);
        }
    }

    /**
     * Makes visible army of the nation
     */
    public void makeVisible(){}
    
    /**
     * Makes Invisible the army
     */
    public void makeInvisible(){}
    
    /**
     * put a new army in the actual army
     * @param int, its the number of the new Army
     */
    public void setArmies(int newArmies){
        for(int i=armies-1;i<(armies+newArmies);i++){
            Triangle triangle = new Triangle();
            army.add(triangle);
        }
    }
}
