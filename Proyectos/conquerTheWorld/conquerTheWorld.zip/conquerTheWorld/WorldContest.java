import java.util.*;
/**
 * Conquer the world simulator
 * Get the solution if its possible
 * @Acosta - Olarte 
 * @2021-2
 */
public class WorldContest
{   
    private World world;
    private String nationBetter;
    private ArrayList<Nation> allNations;
    private int nations;
    private int min;
    private int[][] routes;
    private int[][] armies;
    
    /**
     * @return
     * @param int, its the quantity of the natios
     * @param int[][], its the routes each Xi
     * @param int[][], its the armies each Xi
     */
    public int solve(int nations, int[][] routes, int[][] armies){
        this.min = (int) Float.POSITIVE_INFINITY;
        world = new World(nations,routes,armies);
        allNations = new ArrayList<Nation>();
        allNations = world.getWorld();
        while(!world.conquer()){
            for(int j=0;j<nations;j++){
                world.tryToConquer(allNations.get(j).getColor());
                if(world.conquer()){
                    nationBetter = allNations.get(j).getColor();
                    min = (min>world.getTotalCost())?world.getTotalCost():min;
                }
            }
        }
        return min;
    }
    
    /**
     * @param int, its the quantity of the natios
     * @param int[][], its the routes each Xi
     * @param int[][], its the armies each Xi
     */
    public void simulate(int nations, int[][] routes, int[][] armies){
        this.nations = nations;
        this.routes = routes;
        this.armies = armies;
        world = new World(nations,routes,armies);
        world.makeVisible();
        world.tryToConquer(nationBetter);
        world.makeVisible();
    }
    
    /**
     * @return boolean, if the problem can resolve or not
     */
    public boolean ok(){
        return this.min!=(int) Float.POSITIVE_INFINITY;
    }
}