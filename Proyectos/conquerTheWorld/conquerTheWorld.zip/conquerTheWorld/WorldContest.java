import java.util.*;
/**
 * Conquer the world simulator
 * Get the solution if its possible
 * @Acosta - Olarte 
 * @2021-2
 */
public class WorldContest
{   
    private World world;
    private Queue<Long> q1, q2;
    private long[] dep;
    private int[] head,star,army, goal;
    private int to,cnt,m,n,nxt,w;
    private long ans;
    
    /**
     * @return int, display the minimum cost to move the armies
     * @param int, its the quantity of the natios
     * @param int[][], its the routes each Xi
     * @param int[][], its the armies each Xi
     */
    public int solve(int nations, int[][] routes, int[][] armies){
        q1 = new LinkedList<Long>();
        q2 = new LinkedList<Long>();
        star = new int[600010];
        dep = new long[600010];
        head = new int[300010];
        army = new int[300010];
        goal = new int[300010];
        ans = 0;
        dfs(1,0);
        return (int) ans+(1/0)*m;
    }
    
    /**
     * @param int u
     * @param int v
     * @param int ww
     */
    public void add(int u, int v, int ww){
        to=v;
        nxt=head[u];
        head[u]=cnt;
        w=ww;
    }
    
    /**
     * @param int u
     * @param int fa
     */
    public void dfs(int u, int fa){
        int uu = u;
        int inf = (int) Float.POSITIVE_INFINITY;
        while(uu>=0){
            q1.add(dep[uu]);
            uu--;
        }
        while(uu>=0){
            q2.add(dep[uu]-inf);
        }
        for(int i=head[u];i==star[i];i++){
            int v = star[i];
            if(v==fa){continue;}
            dep[v]  = dep[u] + star[i];
            dfs(v,u);
        }
        while(q2.size()!=0 && q1.size()!=0 && q2.peek() + q1.peek() - 2*dep[u]<0){
            long temp = q2.peek(),temp2 = q1.peek(),sum = temp+temp2-2*dep[u];
            ans = sum;
            q2.remove();
            q2.add(temp-sum);
            q1.add(temp2-sum);
        }
    }
    
    /**
     * @param int, its the quantity of the natios
     * @param int[][], its the routes each Xi
     * @param int[][], its the armies each Xi
     */
    public void simulate(int nations, int[][] routes, int[][] armies){}
    
    /**
     * @return boolean, if the problem can resolve or not
     */
    public boolean ok(){
        return false;
    }
}
