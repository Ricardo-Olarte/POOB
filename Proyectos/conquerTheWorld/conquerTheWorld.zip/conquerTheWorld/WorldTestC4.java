import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class WorldTestC4.
 *
 * @author  Acosta
 * @author  Olarte
 * @version 2021-2
 */
public class WorldTestC4
{ 
    World mundo,mundo3;
    
    @BeforeEach
    public void setUp() {
        mundo3 = new World (920,920);
        mundo = new World(500, 500);
    }
    
    /**
     * Prueba que una nacion especial pueda ser añadida.
     */    
    @Test
    public void shouldAddNationEspeciales(){  
        mundo3.addNation("normal","green", 100, 100, 5);
        assertTrue (mundo3.ok());
        mundo3.addNation("aggressive","red", 300, 100, 10);
        assertTrue (mundo3.ok());
        mundo3.addNation("aggressive","blue", 100, 300, 8);
        assertTrue (mundo3.ok());
        mundo3.addNation("normal","yellow", 300, 300, 6);
        assertTrue (mundo3.ok());
        mundo3.addNation("walled","orange", 100, 600, 4);
        assertTrue (mundo3.ok());
        mundo3.addNation("walled","cyan", 300, 600, 9);
        assertTrue (mundo3.ok());
    } 

    /**
     * Prueba que una nacion especial no pueda ser añadida.
     */    
    @Test
    public void noShouldAddNationEspeciales(){  
        mundo3.addNation("normal","green", 100, 100, 5);
        assertTrue (mundo3.ok());
        mundo3.addNation("aggressive","green", 300, 100, 10);
        assertFalse (mundo3.ok());
        mundo3.addNation("aggressive","blue", 100, 300, 8);
        assertTrue (mundo3.ok());
        mundo3.addNation("normal","blue", 300, 300, 6);
        assertFalse (mundo3.ok());
        mundo3.addNation("walled","orange", 100, 600, 4);
        assertTrue (mundo3.ok());
        mundo3.addNation("walled","orange", 300, 600, 9);
        assertFalse (mundo3.ok());
    } 

    /**
     * Prueba si una nacion especial puede ser borrada.
     */ 

    @Test
    public void shouldDelNationEspecial(){
        mundo3.addNation("normal","green", 100, 100, 5);
        mundo3.delNation("green");
        assertTrue (mundo3.ok());
        mundo3.addNation("aggressive","red", 300, 100, 10);
        mundo3.delNation("red");
        assertTrue (mundo3.ok());
        mundo3.addNation("walled","blue", 100, 300, 8);
        mundo3.delNation("blue");
        assertTrue (mundo3.ok());
        mundo3.addNation("normal","yellow", 300, 300, 6);
        mundo3.delNation("yellow");
        assertTrue (mundo3.ok());
        mundo3.addNation("aggressive","orange", 100, 600, 4);
        mundo3.delNation("orange");
        assertTrue (mundo3.ok());
        mundo3.addNation("walled","cyan", 300, 600, 9);
        mundo3.delNation("cyan");
        assertTrue (mundo3.ok());
    }

    /**
     * Prueba si una nacion especial no puede ser borrada.
     */ 
    @Test
    public void noShouldDelNationEspecial(){
        mundo3.addNation("normal","green", 100, 100, 5);
        mundo3.delNation("yellow");
        assertFalse (mundo3.ok());
        mundo3.addNation("aggressive","red", 300, 100, 10);
        mundo3.delNation("orange");
        assertFalse (mundo3.ok());
        mundo3.addNation("walled","blue", 100, 300, 8);
        mundo3.delNation("cyan");
        assertFalse (mundo3.ok());
        mundo3.addNation("normal","yellow", 300, 300, 6);
        mundo3.delNation("magenta");
        assertFalse (mundo3.ok());
        mundo3.addNation("aggressive","orange", 100, 600, 4);
        mundo3.delNation("white");
        assertFalse (mundo3.ok());
        mundo3.addNation("walled","cyan", 300, 600, 9);
        mundo3.delNation("black");
        assertFalse (mundo3.ok());
    }  

    /**
     * Prueba si se puede añadir una ruta especial entre dos naciones.
     */ 
    @Test
    public void shouldAddRouteEspecial(){
        mundo3.addNation("normal","green", 100, 100, 5);
        mundo3.addNation("aggressive","red", 300, 100, 10);
        mundo3.addRoute("normal","green", "red", 4);
        assertTrue (mundo3.ok());
        mundo3.addNation("aggressive","blue", 100, 300, 8);
        mundo3.addNation("normal","yellow", 300, 300, 6);
        mundo3.addRoute("weak","blue", "yellow", 4);
        assertTrue (mundo3.ok());
        mundo3.addNation("walled","orange", 100, 600, 4);
        mundo3.addNation("walled","cyan", 300, 600, 9);        
        mundo3.addRoute("dealer","orange", "cyan", 4);
        assertTrue (mundo3.ok());
    }  

    /**
     * Prueba si no se puede añadir una ruta especial entre dos naciones.
     */ 
    @Test
    public void noShouldAddRouteEspecial(){
        mundo3.addNation("normal","green", 100, 100, 5);
        mundo3.addNation("aggressive","red", 300, 100, 10);
        mundo3.addRoute("normal","blue", "red", 4);
        assertFalse (mundo3.ok());
        mundo3.addNation("aggressive","blue", 100, 300, 8);
        mundo3.addNation("normal","yellow", 300, 300, 6);
        mundo3.addRoute("weak","orange", "yellow", 4);
        assertFalse (mundo3.ok());
        mundo3.addNation("walled","orange", 100, 600, 4);
        mundo3.addNation("walled","cyan", 300, 600, 9);        
        mundo3.addRoute("dealer","white", "cyan", 4);
        assertFalse (mundo3.ok());
    }  

    /**
     * Prueba si se puede borrar una ruta especial entre dos naciones.
     */ 
    @Test
    public void shoulddelRouteEspecial(){
        mundo3.addNation("normal","green", 100, 100, 5);
        mundo3.addNation("aggressive","red", 300, 100, 10);
        mundo3.addRoute("normal","green", "magenta", 4);
        mundo3.delRoute("green", "magenta");
        assertFalse (mundo3.ok());
        mundo3.addNation("walled","blue", 100, 300, 8);
        mundo3.addNation("normal","yellow", 300, 300, 6);
        mundo3.addRoute("weak","cyan", "yellow", 6);        
        mundo3.delRoute("cyan", "yellow");
        assertFalse (mundo3.ok());        
        mundo3.addNation("aggressive","orange", 100, 600, 4);
        mundo3.addNation("normal","cyan", 300, 600, 9);
        mundo3.addRoute("dealer","white", "cyan", 2);
        mundo3.delRoute("white", "cyan");
        assertFalse (mundo3.ok());    
        mundo3.addNation("normal","white", 800, 600, 5);
        mundo3.addNation("walled","magenta", 400, 400, 5);           
        mundo3.addRoute("normal","black", "magenta", 5);
        mundo3.delRoute("black", "magenta");
        assertFalse (mundo3.ok());  
    }

    /**
     * Prueba si no se puede borrar una ruta especial entre dos naciones.
     */ 
    @Test
    public void noShoulddelRouteEspecial(){
        mundo3.addNation("normal","green", 100, 100, 5);
        mundo3.addNation("normal","red", 300, 100, 10);
        mundo3.addRoute("normal","green", "red", 4);
        mundo3.delRoute("blue", "green");
        assertFalse (mundo3.ok());
        mundo3.addNation("walled","blue", 100, 300, 8);
        mundo3.addNation("aggressive","yellow", 300, 300, 6);
        mundo3.addRoute("dealer","blue", "yellow", 6);        
        mundo3.delRoute("orange", "yellow");
        assertFalse (mundo3.ok());        
        mundo3.addNation("walled","orange", 100, 600, 4);
        mundo3.addNation("normal","cyan", 300, 600, 9);
        mundo3.addRoute("dealer","orange", "cyan", 2);
        mundo3.delRoute("white", "cyan");
        assertFalse (mundo3.ok());    
        mundo3.addNation("normal","white", 800, 600, 5);
        mundo3.addNation("normal","magenta", 400, 400, 5);           
        mundo3.addRoute("weak","white", "magenta", 5);
        mundo3.delRoute("black", "magenta");
        assertFalse (mundo3.ok());
    }

    /**
     * Prueba si se puede añadir una ejercito especial en una nacion.
     */ 
    @Test
    public void shouldPutArmyEspecial(){
        mundo3.addNation("normal","green", 100, 100, 5);
        mundo3.putArmy("normal", "green");
        assertTrue (mundo3.ok());
        mundo3.addNation("aggressive","red", 300, 100, 10);
        mundo3.putArmy("fearful", "red");
        assertTrue (mundo3.ok());
        mundo3.addNation("aggressive","blue", 100, 300, 8);
        mundo3.putArmy("friendly", "blue");
        assertTrue (mundo3.ok());
        mundo3.addNation("normal","yellow", 300, 300, 6);
        mundo3.putArmy("normal", "yellow");
        assertTrue (mundo3.ok());
        mundo3.addNation("walled","orange", 100, 600, 4);
        mundo3.putArmy("fearful", "orange");
        assertTrue (mundo3.ok());
        mundo3.addNation("walled","cyan", 300, 600, 9);
        mundo3.putArmy("friendly", "cyan");
        assertTrue (mundo3.ok());
    }

    /**
     * Prueba si se puede añadir una ejercito especial en una nacion.
     */ 
    @Test
    public void noShouldPutArmyEspecial(){
        mundo3.addNation("normal","green", 100, 100, 5);
        mundo3.putArmy("normal", "red");
        assertFalse (mundo3.ok());
        mundo3.addNation("aggressive","red", 300, 100, 10);
        mundo3.putArmy("fearful", "blue");
        assertFalse (mundo3.ok());
        mundo3.addNation("aggressive","blue", 100, 300, 8);
        mundo3.putArmy("friendly", "yellow");
        assertFalse (mundo3.ok());
        mundo3.addNation("normal","yellow", 300, 300, 6);
        mundo3.putArmy("normal", "orange");
        assertFalse (mundo3.ok());
        mundo3.addNation("walled","orange", 100, 600, 4);
        mundo3.putArmy("fearful", "cyan");
        assertFalse (mundo3.ok());
        mundo3.addNation("walled","cyan", 300, 600, 9);
        mundo3.putArmy("friendly", "white");
        assertFalse (mundo3.ok());
    }
    
    /**
     * El simulador no debería dejar que ejercitos salgan de naciones Walled.
     */
    @Test
    public void noDeberiaDejarSalirEjercitos() {
        mundo.addNation("walled", "blue", 25, 25, 3);
        mundo.addNation("red", 100, 30, 3);
        mundo.addRoute("blue", "red", 5);
        assertTrue(mundo.ok());
        mundo.putArmy("blue");
        assertTrue(mundo.ok());
        int payments = mundo.payments();
        mundo.moveArmyOneRoute("blue", "red");
        assertFalse(mundo.ok());
        assertTrue(payments == mundo.payments());
    }

    /**
     * El simulador debería actuar correctamente cuando un ejercito llega a una nación Agressive.
     */
    @Test
    public void deberiaDestruirEjercitos() {
        mundo.addNation("blue", 25, 25, 0);
        mundo.addNation("agressive", "red", 100, 30, 1); // Se conquista con uno
        mundo.addRoute("blue", "red", 5);
        mundo.putArmy("blue");
        int payments = mundo.payments();
        mundo.moveArmyOneRoute("blue", "red");
        assertTrue(mundo.ok());
        assertTrue(payments+5 == mundo.payments());
        assertFalse(mundo.conquer());
    }
}
