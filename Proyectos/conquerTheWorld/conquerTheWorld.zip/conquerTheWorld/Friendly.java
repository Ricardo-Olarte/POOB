
/**
 * Write a description of class Friendly here.
 * 
 * @author Acosta
 * @author Olarte
 * @version 2021-2
 */
public class Friendly extends Army
{
    private int other;
    private int steps;
   /**
     * Constructor for objects of class Friendly
     */
    public Friendly(int x, int y,int armies){
        super(x,y,armies);
        other = -1;
    }
    
    /**
     * Delete de army
     */
    @Override
    public void del(){
        if(other==0){
            makeInvisible();
            army.clear();
            armies = 0;
        }
    }
    
    /**
     * put a new army in the actual army
     * @param int x, its a horizontal position
     * @param int y, its a vertical position
     * @param int, its the number of the new Army
     */
    @Override
    public void setArmies(int x, int y, int newArmies){
        makeInvisible();
        steps ++;
        int a = x;
        int b = y;
        int m = 0;
        int n = 0;
        for(int i=0;i<newArmies;i++){
            Triangle triangle = new Triangle();
            triangle.moveHorizontal(a);
            triangle.moveVertical(b);
            a+=33;
            m+=33;
            if(m>99){
                m = 0;
                a = x;
                b += 33;
            }
            if(n>99){
                n = 0;
                a = x;
                b = y;
            }
            army.add(triangle);
        }
    }
}
