import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class WorldTestC2.
 *
 * @author  Acosta
 * @author Olarte
 * @version 2021-2
 */
public class WorldTestC2
{
    private World w1,game,mundo;
    private boolean bool1, bool2, ok1, ok2;
    
    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @BeforeEach
    public void setUp()
    {
        game = new World(720,1080);
        w1 = new World(150,180);
        mundo = new World(1000,1000);
        int n = 6, routes[][] = {{1,2,2},{1,3,5},{1,4,1},{2,5,5},{2,6,1}}, armies[][] = {{0,0},{1,0},{2,1},{2,1},{0,1},{0,1}};
        w1.makeInvisible();
        int [][] routes1 = {{1,2,5},{3,1,5}};
        int [][] armies1 = {{2, 1},{5, 0},{1, 3}};
        int [][] routes2 = {{1,2,2}, {1,3,5}, {1,4,1}, {2,5,5}, {2,6,1}};
        int [][] armies2 = {{0,0},{1,0},{2,1},{2,1},{0,1},{0,1}};
        int [][] routes3 = {{1,2,2},{2,3,2},{3,4,3},{1,4,2},{1,5,1},{3,6,1},{4,6,2},{5,6,1}};
        int [][] armies3 = {{1,0}, {2,0}, {3,1}, {4,0}, {10, 0}, {0, 9}};
        World world1 = new World(3, routes1, armies1);
        bool1 = world1.conquer();
        world1.tryToConquer("yellow");
        bool2 = world1.conquer();
        int payw1 = world1.payments();
        World world2 = new World(6, routes2, armies2);
        world2.tryToConquer("magenta");
        int payw2 = world2.payments();
        world2.tryToConquer("gray");
        int payw3 = world2.payments();
        World world3 = new World(6, routes3, armies3);
        world3.tryToConquer("gray");
        int payw4 = world3.payments();
        ok1 = world3.ok();
        ok2 = world2.ok();
    }
    
    @Test
    public void segunASdeberiaConquistar() {
        assertTrue(mundo.ok());
        //assertTrue(mundo.conqueredN().size() == 4);
        //mundo.moveArmyOneRoute(mundo.nacionesActuales().get(1), mundo.nacionesActuales().get(4));
        assertTrue(mundo.ok());
        //assertTrue(mundo.conqueredN().size() == 5);
        //mundo.moveArmyOneRoute(mundo.nacionesActuales().get(2), mundo.nacionesActuales().get(0));
        assertTrue(mundo.ok());
        //mundo.moveArmyOneRoute(mundo.nacionesActuales().get(0), mundo.nacionesActuales().get(1));
        assertTrue(mundo.ok());
        //mundo.moveArmyOneRoute(mundo.nacionesActuales().get(1), mundo.nacionesActuales().get(5));
        assertTrue(mundo.ok());
        assertTrue(mundo.conquer());
        //mundo.removeArmy(mundo.nacionesActuales().get(3));
        assertTrue(mundo.ok());
        assertTrue(mundo.conquer());
    }

    @Test
    public void segunASdeberiaIntentarConquistar() {
        assertTrue(mundo.ok());
        //mundo.addRoute(mundo.nacionesActuales().get(3), mundo.nacionesActuales().get(5), 10);
        assertTrue(mundo.ok());
        //mundo.addRoute(mundo.nacionesActuales().get(5), mundo.nacionesActuales().get(4), 10);
        assertTrue(mundo.ok());
        //mundo.addRoute(mundo.nacionesActuales().get(2), mundo.nacionesActuales().get(5), 10);
        assertTrue(mundo.ok());
        //mundo.addRoute(mundo.nacionesActuales().get(0), mundo.nacionesActuales().get(5), 10);
        assertTrue(mundo.ok());
        //mundo.addRoute(mundo.nacionesActuales().get(0), mundo.nacionesActuales().get(4), 10);
        assertTrue(mundo.ok());
        //mundo.tryToConquer(mundo.nacionesActuales().get(5));
        assertTrue(mundo.ok());
        //mundo.tryToConquer(mundo.nacionesActuales().get(4));
        assertTrue(mundo.ok());
        assertTrue(mundo.conquer());
        assertTrue(mundo.payments() == 9);
    }
    
    @Test
    public void deberiaAñadirNacion() {
        // assertTrue(w1.addNation("red",154,210,5));
        // assertTrue(w1.addNation("blue",100,200,5));
        // assertTrue(w1.addNation("gray",140,270,8));
        // assertTrue(w1.addNation("orange",130,180,3));
        // assertTrue(w1.addNation("black",133,214,6));
    }

    @Test
    public void deberiaAñadirRuta() {
        // assertTrue(w1.addRoute("green","white",210));
        // assertTrue(w1.addRoute("green","brown",200));
        // assertTrue(w1.addRoute("white","brown",250));
    }

    @Test
    public void deberiaPonerEjercito() {
        // assertTrue(w1.putArmy("green"));
        // assertTrue(w1.putArmy("brown"));
        // assertTrue(w1.putArmy("white"));
    }
    
    @Test
    public void shouldNotAOok(){
        game.addNation("red", 300, 300, 5);
        game.addNation("red", 300, 300, 5);
        assertFalse(game.ok());
    }
    
    @Test
    public void shouldAOok(){
        game.addNation("red", 250, 250, 4);
        game.addNation("yellow", 350, 350, 5);
        assertTrue(game.ok());
    }
    
    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @AfterEach
    public void tearDown()
    {
    }
}
