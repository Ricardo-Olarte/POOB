
/**
 * Write a description of class Fearful here.
 * 
 * @author Acosta
 * @author Olarte
 * @version 2021-2
 */
public class Fearful extends Army
{
    /**
     * Constructor for objects of class Fearful
     */
    public Fearful(int x, int y,int armies){
        super(x,y,armies);
    }
}
