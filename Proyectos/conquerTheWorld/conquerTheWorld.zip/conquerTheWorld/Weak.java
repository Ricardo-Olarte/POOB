
/**
 * Its a type route, broken when the army passed for this route
 * 
 * @author Acosta
 * @author Olarte
 * @version 2021-2
 */
public class Weak extends Route
{
    /**
     * Constructor for objects of class Weak
     */
    public Weak(Nation a, Nation b, int cost){
        super(a,b,cost);
    }
    
    /**
     * @return
     */
    public String getType(){
        return "weak";
    }
    
    @Override
    /**
     * @return if the nation a can attack nation b
     */
    public boolean attack(){
        int armyTemp = a.getArmies() - cost - b.getArmies();
        if(armyTemp >= 0){
            a.setArmies(a.getArmies() - cost);
            b.setArmies(-(a.getArmies() + cost));
            b.attacked(a,armyTemp);
            return true;
        }
        return false;
    }
}
