package dominio;

import java.util.*;
import java.awt.Color;

public class EsquimalExplorador extends Esquimal
{
    private boolean recorridoCompleto;
    public ArrayList<EnArtico> validarEsquimales;
    
    /**
     * Constructor for objects of class EsquimalExplorador
     */
    public EsquimalExplorador(Artico artico,String name,int posicionx, int posiciony){
        super(artico,name,posicionx,posiciony);
        palabras="";
        setColor(Color.RED);
        recorridoCompleto = false;
    }
    
    @Override
    public void actue(){
        while(getPosicionX() > 0){
            avance('O');
        }
        
        while(getPosicionY() < getArtico().MAXIMO){
            avance('S');
        }
    
        for(int i = 0; i < getArtico().MAXIMO; i++){
            avance('N');
            for(int j = 0; j < getArtico().MAXIMO; j++){
                avance('O');
            }
            setPosicionCeroX();
        }
    }
    
    @Override
    public void corte() {
        validarEsquimales = getArtico().getElementos();
        double minimo = Integer.MAX_VALUE;
        int index = 0;
        for (EnArtico e : validarEsquimales) {
            if(e instanceof Esquimal){
                if(this.getPosicionX() - e.getPosicionX() != 0 && this.getPosicionY() - e.getPosicionY() != 0){
                double distancia = Math.hypot(this.getPosicionX() - e.getPosicionX(), this.getPosicionY() - e.getPosicionY());
                    if (minimo > distancia) {
                        minimo = distancia;
                        index = validarEsquimales.indexOf(e);
                    }
                }
            }
        }   
        this.setPosicionX(validarEsquimales.get(index).getPosicionX() - 20);
        this.setPosicionY(validarEsquimales.get(index).getPosicionY());
    }
    
    @Override
    public void improvise(){
        palabras = String.valueOf(getPosicionX()) + " " + String.valueOf(getPosicionY());
    }
        
}


