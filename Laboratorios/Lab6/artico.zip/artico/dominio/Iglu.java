package dominio;
import java.awt.Color;

public class Iglu implements EnArtico{

    private int posicionx,posiciony;
    private Color color;
    private Artico artico;
    private String mensaje;
    
    public Iglu(Artico artico, int posicionx, int posiciony){
        mensaje = "";
        color = Color.BLACK;
        this.artico = artico;
        this.posicionx = posicionx;
        this.posiciony = posiciony;
    }
    
    public final String mensaje() {
        return mensaje;
    }
    
    /**Cambia el color del iglu*/
    public void setColor(Color color){
        this.color = color;
    }
    
    public void setMensaje(String mensaje){
        this.mensaje = mensaje;
    }
    
    public int getPosicionX(){
        return posicionx;
    }
    
    public int getPosicionY(){
        return posiciony;
    }
    
    public Color getColor(){
        return color;
    }
    
    @Override
    public String forma(){
        return FORMAS[1];
    }
    
    @Override
    public void corte(){
        setColor(Color.WHITE);
        mensaje = "CERRADO";
    }
    
    @Override
    public void improvise(){
        if(mensaje.equals("CERRADO")){
            corte();
        }else{
            accion();
        }
    }
    
    @Override
    public void accion(){
        setColor(Color.BLACK);
        setMensaje("");
    }
}
