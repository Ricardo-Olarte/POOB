package dominio;

public class ArticoExcepcion extends Exception{

    public final static String OPCION = "Opción en construcción";

    /**
     *
     * @param message, mensaje que sale por pantalla, al atrapar la excepcion
     */
    public ArticoExcepcion(String message){
        super(message);
    }
}
