package dominio;

import java.awt.Color;

public class EsquimalAngel extends Esquimal
{
    /**
     * Constructor for objects of class EsquimalSordo
     */
    public EsquimalAngel(Artico artico,String name,int posicionx, int posiciony){
        super(artico,name,posicionx,posiciony);
        palabras="Soy un ángel";
        setColor(Color.CYAN);
    }
    
    @Override
    public void actue(){
        setPosicion(150, 150);
        palabras="Accion";
    }
    
    @Override
    public void corte(){
        muevaBrazo('I','S'); 
        muevaPierna('I','P');
        muevaBrazo('D','S'); 
        muevaPierna('D','P');       
        palabras="Corte";
    }
    
    @Override
    public void improvise(){
        setColor(Color.ORANGE);
    }

    public int random() {
      int min = 0;
      int max = 500;
      int random_int = (int)Math.floor(Math.random()*(max-min+1)+min);
      return random_int;
    }
}

