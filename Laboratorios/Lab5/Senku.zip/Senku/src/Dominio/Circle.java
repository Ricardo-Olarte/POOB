package Dominio;

/**
 * @Autor Acosta
 * @Autor Olarte
 * @Version 2021-1
 */
public class Circle {
}
