package Dominio;

/**
 * @Autor Acosta
 * @Autor Olarte
 * @Version 2021-1
 */
public class Senku {

    private Tablero tablero;
    private Circle ficha;

    /**
     *
     */
    public void inicio(){}

    /**
     *
     */
    public void refresque(){}

    /**
     *
     */
    public void finalizar(){}
}
