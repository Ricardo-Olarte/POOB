package Dominio;

public class Tablero {
}
