package dominio;
import java.awt.Color;
import java.util.*;

public class Pozo implements EnArtico{
    private int posicionx,posiciony;
    private Color color;
    private Artico artico;
    private String mensaje;
    public ArrayList<EnArtico> elementos;
    
    public Pozo(Artico artico, int posicionx, int posiciony){
        mensaje = "";
        color = Color.CYAN;
        this.artico = artico;
        this.posicionx = posicionx;
        this.posiciony = posiciony;
    }
    
    public ArrayList<Esquimal> caida(){
        ArrayList<Esquimal> elementosaBorrar = new ArrayList<Esquimal>();
        elementos = artico.getElementos();
        for(EnArtico e : elementos){
            if(e instanceof Esquimal){
                if(e.getPosicionX() == posicionx && e.getPosicionY() == posiciony){
                    elementosaBorrar.add((Esquimal) e);
                }
            }
        }
        return elementosaBorrar;
    }
    
    public final String mensaje(){
        return mensaje;
    }
    
    public void setColor(Color color){
        this.color = color;
    }
    
    public int getPosicionX(){
        return posicionx;
    }
    
    public int getPosicionY(){
        return posiciony;
    }
    
    public Color getColor(){
        return color;
    }
    
    @Override
    public String forma(){
        return FORMAS[2];
    }
    
    @Override
    public void accion(){
        if(caida().size() != 0){
            int index = artico.getElementos().indexOf(caida().get(caida().size()-1));
            Esquimal ultimo = (Esquimal) (artico.getElementos().get(index));
            mensaje = "Me tragué a: " + ultimo.getName();
        }
    }
    
    @Override
    public void corte(){
        mensaje = "Cuidado!";
    }
}
