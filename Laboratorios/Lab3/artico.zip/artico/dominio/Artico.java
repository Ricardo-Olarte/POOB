package dominio;
import java.util.*;

public class Artico{
    public static final int MAXIMO = 500;
    private static Artico polo = null;

    public static Artico demeArtico() {
        if (polo==null){
            polo=new Artico();
        }
        return polo;
    }

    private static void nuevoArtico() {
        polo=new Artico();
    }   

    public static void cambieArtico(Artico d) {
        polo=d;
    }       

    private ArrayList<EnArtico> elementos;
    private int poloNorteX;
    private int poloNorteY;
    private boolean enPoloNorte;

    public Artico() {
        elementos= new ArrayList<EnArtico>();
        poloNorteX = (int)(Math.random() * MAXIMO);
        poloNorteY = (int)(Math.random() * MAXIMO);
        enPoloNorte=false;
    }

    public void algunosEnArtico(){
        Esquimal esquimal1 = new Esquimal(this, "aaju", 10, 10);
        Esquimal esquimal2 = new Esquimal(this, "alek", 200, 20);
        elementos.add(esquimal1);
        elementos.add(esquimal2);
        EsquimalSordo esquimalSordo1 = new EsquimalSordo(this, "aguu", 50, 50);
        EsquimalSordo esquimalSordo2 = new EsquimalSordo(this, "ivanna", 100, 100);
        elementos.add(esquimalSordo1);
        elementos.add(esquimalSordo2);
        Iglu superiorDerecha = new Iglu(this, MAXIMO, MAXIMO);
        Iglu superiorIzquierda = new Iglu(this, 0, MAXIMO);
        Iglu inferiorDerecha = new Iglu(this, MAXIMO, 0);
        Iglu inferiorIzquierda = new Iglu(this, 0, 0);
        elementos.add(superiorDerecha);
        elementos.add(superiorIzquierda);
        elementos.add(inferiorDerecha);
        elementos.add(inferiorIzquierda);
        EsquimalExplorador esquimalExplorador1 = new EsquimalExplorador(this, "nanuk", 500, 500);
        EsquimalExplorador esquimalExplorador2 = new EsquimalExplorador(this, "sialuk", 250, 250);
        elementos.add(esquimalExplorador1);
        elementos.add(esquimalExplorador2);
    }

    public EnArtico demeEnArtico(int n){
        EnArtico h=null;
        if (1<=n && n<=elementos.size()){
            h=elementos.get(n-1);
        }  
        return h; 
    }

    
    public void adicione(EnArtico e){
        elementos.add(e);
    }

    public int numeroEnArtico(){
        return elementos.size();
    }

    public boolean enPoloNorte(EnArtico e){
        boolean ok=(poloNorteX==e.getPosicionX() && poloNorteY==e.getPosicionY());
        enPoloNorte = enPoloNorte || ok;
        return enPoloNorte;
    }     
    
    
    public void accion(){
        for(EnArtico e:elementos){
            e.accion();
        } 
    }

    public void improvisen(){
        for(EnArtico e:elementos){
            e.improvise();
        }
    }

    public void corten(){
        for(EnArtico e:elementos){    
            e.corte();
        }
    } 
}  

