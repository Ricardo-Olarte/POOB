package dominio;

import java.awt.Color;

public class EsquimalExplorador extends Esquimal
{
    private boolean recorridoCompleto;
    
    /**
     * Constructor for objects of class EsquimalExplorador
     */
    public EsquimalExplorador(Artico artico,String name,int posicionx, int posiciony){
        super(artico,name,posicionx,posiciony);
        palabras="";
        setColor(Color.RED);
        recorridoCompleto = false;
    }

    @Override
    public void actue(){
        while(getPosicionX() > 0){
            avance('O');
        }
        
        while(getPosicionY() < getArtico().MAXIMO){
            avance('S');
        }
    }
}
