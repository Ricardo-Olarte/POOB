package dominio;

import java.awt.Color;

public class EsquimalSordo extends Esquimal
{
    /**
     * Constructor for objects of class EsquimalSordo
     */
    public EsquimalSordo(Artico artico,String name,int posicionx, int posiciony){
        super(artico,name,posicionx,posiciony);
        palabras="Que qué? ";
        setColor(Color.GREEN);
        
    }
    
    @Override
    public void actue(){
        muevaBrazo('I','S');
        muevaBrazo('D','S');
    }
    
    @Override
    public void corte(){
        for(int i=0;i<5;i++){
            avance('N');
        }
    }
    
    @Override
    public void improvise(){
        setColor(Color.YELLOW);
        corte();
    }
}
