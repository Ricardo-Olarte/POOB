package dominio;
import java.awt.Color;

public class Iglu implements EnArtico{

    private int posicionx,posiciony;
    private Color color;
    private String mensaje;
    
    public Iglu(int posicionx, int posiciony){
        super();
        mensaje = "";
        color = Color.BLACK;
    }
    
    public final String mensaje(String mensaje) {
        return super(mensaje);
    }
    
    /**Cambia el color del iglú*/
    public void setColor(Color color){
        this.color = color;
    }
    
    public int getPosicionX(){
        return posicionx;
    }
    
    public int getPosicionY(){
        return posiciony;
    }
    
    public Color getColor(){
        return color;
    }
    
    @Override
    public String forma(){
        return FORMAS[1];
    }
    
    @Override
    public void corte(){
    }
    
    @Override
    public void improvise(){
        if (r.nextBoolean()){
            accion();
        }else{
            corte();
        }
    }
    
    public void accion(){
        
    }
}
