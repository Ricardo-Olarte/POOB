

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class CalVectorialTest.
 *
 * @Acosta
 * @Olarte
 * @2021-2
 */
public class CalVectorialTest
{
    private CalVectorial calculadora;

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @BeforeEach
    public void setUp()
    {
        calculadora = new CalVectorial();
    }
    
    @Test
    public void deberiaDeclarar(){
        calculadora.defina("vector1");
        assertTrue(calculadora.consulteEnPolares("vector1").equals("INDEFINIDA"));
    }
    
    @Test
    public void noDeberiaDeclarar(){
        calculadora.defina("vector1");
        assertFalse(calculadora.consulteEnPolares("vector1").equals("P(100,100)"));
    }
    
    @Test
    public void deberiaAsignarUnValor(){
        calculadora.asigne("vector1",25,45);
        assertTrue(calculadora.consulteEnPolares("vector1").equals("P(25,45.0)"));
    }
    
    @Test void noDeberiaAsignarUnValor(){
        calculadora.asigne("vector1",25,45);
        assertFalse(calculadora.consulteEnPolares("vector2").equals("P(25,45.0)"));
    }
    
    @Test void deberiaConsultar(){
        calculadora.asigne("vector1",25,45);
        assertTrue(calculadora.consulteEnPolares("vector1").equals("P(25.0,45.0)"));
        assertTrue(calculadora.consulteEnCartesianas("vector1").equals("18,45.0"));
    }
    
    @Test void noDeberiaConsultar(){}
    
    @Test void deberiaSumar(){}
    
    @Test void noDeberiaSumar(){}
    
    @Test void deberiaRestar(){}
    
    @Test void noDeberiaRestar(){}
    
    @Test void deberiaOperacionUnariaUnitario(){}
    
    @Test void noDeberiaOperacionUnariaUnitario(){}
    
    @Test void deberiaOperacionUnariaHorizontal(){}
    
    @Test void noDeberiaOperacionUnariaHorizontal(){}
    
    @Test void deberiaOperacionUnariaVertical(){}
    
    @Test void noDeberiaOperacionUnariaVertical(){}
    
    @Test void deberiaOperacionBinariaProducto(){}
    
    @Test void noDeberiaOperacionBinariaProducto(){}
    
    @Test void deberiaOperacionBinariaProyeccion(){}
    
    @Test void noDeberiaOperacionBinariaProyeccion(){}
    
    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @AfterEach
    public void tearDown()
    {
    }
}
