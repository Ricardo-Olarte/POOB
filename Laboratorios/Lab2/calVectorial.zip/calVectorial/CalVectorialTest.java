

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class CalVectorialTest.
 *
 * @Acosta
 * @Olarte
 * @2021-2
 */
public class CalVectorialTest
{
    private CalVectorial calculadora;

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @BeforeEach
    public void setUp()
    {
        calculadora = new CalVectorial();
        calculadora.defina("vector1");
        calculadora.defina("vector2");
    }
    
    @Test
    public void deberiaDeclarar(){
        assertTrue(calculadora.consulteEnPolares("vector1").equals("INDEFINIDA"));
    }
    
    @Test
    public void noDeberiaDeclarar(){
        assertFalse(calculadora.consulteEnPolares("vector1").equals("P(100,100)"));
    }
    
    @Test
    public void deberiaAsignarUnValor(){
        calculadora.asigne("vector1",25,45);
        assertTrue(calculadora.consulteEnPolares("vector1").equals("P(25,45.0)"));
    }
    
    @Test void noDeberiaAsignarUnValor(){
        calculadora.asigne("vector1",25,45);
        assertFalse(calculadora.consulteEnPolares("vector2").equals("P(25,45.0)"));
    }
    
    @Test void deberiaConsultar(){
        calculadora.asigne("vector1",25,45);
        assertTrue(calculadora.consulteEnPolares("vector1").equals("P(25,45.0)"));
    }
    
    @Test void noDeberiaConsultar(){
        calculadora.asigne("vector1",25,45);
        assertFalse(calculadora.consulteEnPolares("vector2").equals("P(25,45.0)"));
    }
    
    @Test void deberiaSumar(){
        calculadora.asigne("vector1",0,0);
        calculadora.asigne("vector2",25,45);
        calculadora.asigne("vector3",25,45);
        calculadora.asigne("vector1","vector2",'+',"vector3");
        assertTrue(calculadora.consulteEnCartesianas("vector1").equals("(50.0,90.0)"));
    }
    
    @Test void noDeberiaSumar(){
        calculadora.asigne("vector1",0,0);
        calculadora.asigne("vector2",25,45);
        calculadora.asigne("vector3",25,45);
        calculadora.asigne("vector1","vector2",'-',"vector3");
        assertFalse(calculadora.consulteEnCartesianas("vector1").equals("(50.0,90.0)"));
    }
    
    @Test void deberiaRestar(){
        calculadora.asigne("vector1",0,0);
        calculadora.asigne("vector2",25,45);
        calculadora.asigne("vector3",25,45);
        calculadora.asigne("vector1","vector2",'-',"vector3");
        assertTrue(calculadora.consulteEnCartesianas("vector1").equals("(0.0,0.0)"));
    }
    
    @Test void noDeberiaRestar(){
        calculadora.asigne("vector1",0,0);
        calculadora.asigne("vector2",25,45);
        calculadora.asigne("vector3",25,45);
        calculadora.asigne("vector1","vector2",'-',"vector3");
        assertFalse(calculadora.consulteEnCartesianas("vector1").equals("(25.0,45.0)"));
    }
    
    @Test void deberiaOperacionUnariaUnitario(){
        calculadora.asigne("vector2",3,4);
        calculadora.asigne("vector1",'u',"vector2");
        assertTrue(calculadora.consulteEnCartesianas("vector1").equals("(0.6,0.8)"));
    }
    
    @Test void noDeberiaOperacionUnariaUnitario(){
        calculadora.asigne("vector2",3,4);
        calculadora.asigne("vector1",'u',"vector2");
        assertFalse(calculadora.consulteEnCartesianas("vector1").equals("(3,4)"));
    }
    
    @Test void deberiaOperacionUnariaHorizontal(){}
    
    @Test void noDeberiaOperacionUnariaHorizontal(){}
    
    @Test void deberiaOperacionUnariaVertical(){}
    
    @Test void noDeberiaOperacionUnariaVertical(){}
    
    @Test void deberiaOperacionBinariaProducto(){}
    
    @Test void noDeberiaOperacionBinariaProducto(){}
    
    @Test void deberiaOperacionBinariaProyeccion(){}
    
    @Test void noDeberiaOperacionBinariaProyeccion(){}
    
    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @AfterEach
    public void tearDown()
    {
    }
}
