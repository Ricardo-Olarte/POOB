import java.util.Objects;
/**
 * @Acosta ECI, 2017 v01 2021 v02
 * @Olarte ECI, 2017 v01 2021 v02
 *
 */
public class Vector{

    public static final float MAXERROR = 0.00000000000001f;
    
    private float r;
    private Angulo theta;
    private float x;
    private float y;
    
    /**
     * Constructor del vector, en coordenadas polares
     * @param r longitud del vector
     * @param t angulo del vector
     */
    public Vector (float r, Angulo t) {
        this.r = r;
        theta = t;
    }

    /**
     * Constructor del vector, en coordenadas cartesianas
     * @param x coordenada x del vector
     * @param y coordenada y del vector
     */
    public Vector (float x, float y) {
        this.x = x;
        this.y = y;
    }
    
    /**
     * Retorna la coordenada X del vector
     * @return coordenada X del vector
     */
    public float coordenadaX() {
        if(!Objects.isNull(x)){
            return x;
        }
        x = r * (float) Math.sin(theta.grados());
        return x;
    }

    /**
     * Retorna la coordenada Y del Vector
     * @return coordenada Y del vector
     */
    public float coordenadaY() {
        if(!Objects.isNull(y)){
            return y;
        }
        y = r * (float) Math.sin(theta.grados());
        return y;
    }

    /**
     * Retorna el angulo del vector
     * @return theta, angulo del vector
     */
    public Angulo angulo () {
        if(!Objects.isNull(theta)){
            return theta;    
        }
        theta = new Angulo(Math.atan(y/x),1);
        return theta;
    }

    /**
     * Retorna la longitud del vector
     * @return r, longitud del vector
     */
    public float longitud() {
        if(!Objects.isNull(r)){
            return r;
        }
        r = (float) Math.sqrt(Math.pow(x,2) + Math.pow(y,2));
        return r;
    }
    
    /**
     * Retorna la distancia entre este vector y otro vector
     * @return d, distancia entre dos vectores
     * @param otro, vector con el cual se hallará la distancia
     */
    public float distancia(Vector otro) {
        float x1, x2, y1, y2, d;
        x1 = coordenadaX();
        y1 = coordenadaY();
        x2 = otro.coordenadaX();
        y2 = otro.coordenadaX();
        d = (float) Math.sqrt(Math.pow(x2-x1,2) + Math.pow(y2-y1,2));
        return d;
    }
    
    /**
     * Compara este vector con otro. Serán iguales si la distancia entre ellos es menor que MAXERROR
     * @param v el vector a comparar con este
     * @return la condición si se cumple d < MAXERROR 
     */
    public boolean equals (Vector v) {
        float d;
        d = distancia(v);
        return d < MAXERROR;
    }

    /** 
     * Compara si este Vector es igual al parametro (debe ser tambien un vector)
     */
    @Override
    public boolean equals (Object o) {
            return this.equals ((Vector) o);
    }
    
    /**
     * Translada el vector, dados los desplazamientos en dx, dy
     *
     * @param dx desplazamiento en el eje x
     * @param dy desplazamiento en el eje Y
     */
    public Vector traslade (float dx, float dy) {
        Vector vector = new Vector(coordenadaX() + dx, coordenadaY() + dy);
        return vector;
    }
    
    /**
     * Calcula el producto escalar
     * @param escalar El factor de multiplicación de la distancia respecto al centro
     * @return 
     */
    public Vector productoEscalar(float escalar) {
        Vector vector = new Vector(longitud()*escalar, angulo());
        return vector;
    }

    /**
     * Rota el vector el angulo dado, con respecto al origen. 
     * Es decir que el angulo resultante, es la suma del angulo dado con el angulo inicial del vector, 
     * y la distancia es la misma.
     */
    public Vector rote(Angulo a) {
        Vector vector = new Vector(longitud(), a.sume(angulo()));
        return vector;
    }
    
    /**
     * Suma dos vectores 
     * @param v, es el vector con el que se va a sumar.
     * @return vector, es el vector resultado de la suma.
     */
    public  Vector  sume(Vector v){
        float x1, x2, y1, y2;
        x1 = coordenadaX();
        y1 = coordenadaY();
        x2 = v.coordenadaX();
        y2 = v.coordenadaX();
        Vector vector = new Vector(x1 + x2, y1 + y2);
        return vector;
    }
    
    /**
     * Suma dos vectores 
     * @param v, es el vector con el que se va a restar.
     * @return vector, es el vector resultado de la resta.
     */
    public Vector reste(Vector v){
        float x1, x2, y1, y2;
        x1 = coordenadaX();
        y1 = coordenadaY();
        x2 = v.coordenadaX();
        y2 = v.coordenadaX();
        Vector vector = new Vector(x1 - x2, y1 - y2);
        return vector;
    }
    
    /**
     * Multiplica dos vectores 
     * @param v, es el vector con el que se va a multiplicar.
     * @return vector, es el vector resultado de la resta.
     */
    public Vector multiplique(Vector v){
        float x1, x2, y1, y2;
        x1 = coordenadaX();
        y1 = coordenadaY();
        x2 = v.coordenadaX();
        y2 = v.coordenadaX();
        Vector vector = new Vector(x1 * x2, y1 * y2);
        return vector;
    }
    
    
    /** 
     * Retorna una cadena que describe a este vector (en coordenadas polares)
     * P(r,theta)
     */
    @Override
    public String toString () {
        r = longitud();
        theta = angulo();
        String s = String.valueOf(r);
        String s1 = String.valueOf(theta);
        return "P(" + s + "," + s1 + ")";
    }
}