

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class VectorTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class VectorTest
{
    private Vector vector1,vector2,vector3;

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @BeforeEach
    public void setUp()
    {
        vector1 = new Vector(1,new Angulo(0,1));
        vector2 = new Vector(5,5);
        vector3 = new Vector(1,new Angulo(180,1));
    }
    
    @Test
    public void deberiaDarCoordenadaX(){
        assertTrue(vector1.coordenadaX() == 0);
        assertTrue(vector2.coordenadaX() == 5);
        assertTrue(vector3.coordenadaX() < 0);
    }
    
    @Test
    public void noDeberiaDarCoordenadaX(){
        assertFalse(vector1.coordenadaX() != 1);
        assertFalse(vector2.coordenadaX() != 5);
        assertFalse(vector3.coordenadaX() != -1);
    }
    
    @Test
    public void deberiaDarCoordenadaY(){
        assertTrue(vector1.coordenadaY() == 0);
        assertTrue(vector2.coordenadaY() == 5);
        assertTrue(vector3.coordenadaY() == 0);
    }
    
    @Test
    public void noDeberiaDarCoordenadaY(){
        assertFalse(vector1.coordenadaY() != 0);
        assertFalse(vector2.coordenadaY() != 5);
        assertFalse(vector3.coordenadaY() != 0);
    }
    
    @Test
    public void deberiaDarAngulo(){
        assertTrue(vector1.angulo().equals(new Angulo(0,1)));
        assertTrue(vector2.angulo().equals(new Angulo(0.7853981633974483,0)));
        assertTrue(vector3.angulo().equals(new Angulo(180,1)));
    }
    
    @Test
    public void noDeberiaDarAngulo(){
        assertFalse(vector1.angulo().equals(new Angulo(-1,0)));
        assertFalse(vector2.angulo().equals(new Angulo(-45,1)));
        assertFalse(vector3.angulo().equals(new Angulo(0.59846,0)));
    }
    
    @Test
    public void deberiaDarLongitud(){
        assertTrue(vector1.longitud() == 1);
        assertTrue(vector2.longitud() < 8);
        assertTrue(vector3.longitud() == 1);
    }
    
    @Test
    public void noDeberiaDarLongitud(){
        assertFalse(vector1.longitud() != 1);
        assertFalse(vector2.longitud() >= 8);
        assertFalse(vector3.longitud() != 1);
    }
    
    @Test
    public void deberiaDarDistancia(){
        assertTrue(vector1.distancia(vector2) < 8);
        assertTrue(vector1.distancia(vector3) == 0);
        assertTrue(vector2.distancia(vector3) < 8);
    }
    
    @Test
    public void noDeberiaDarDistancia(){
        assertFalse(vector1.distancia(vector2) > 8);
        assertFalse(vector1.distancia(vector3) != 0);
        assertFalse(vector2.distancia(vector3) > 8);
    }
    
    @Test
    public void deberiaSerEqualsConOtroVector(){
        assertTrue(vector1.equals(vector1));
        assertTrue(vector2.equals(vector2));
        assertTrue(vector3.equals(vector3));
    }
    
    @Test
    public void noDeberiaSerEqualsConOtroVector(){
        assertFalse(vector1.equals(vector2));
        assertFalse(vector2.equals(vector3));
    }
    
    @Test
    public void deberiaSerEqualsConOtroObjeto(){
        assertTrue(vector1.equals(new Vector(1,new Angulo(0,1))));
        assertTrue(vector2.equals(new Vector(5,5)));
        assertTrue(vector3.equals(new Vector(1,new Angulo(180,1))));
    }
    
    @Test
    public void noDeberiaSerEqualsConOtroObjeto(){
        assertFalse(vector1.equals(vector2));
        assertFalse(vector2.equals(vector3));
    }
    
    @Test
    public void deberiaTrasladar(){}
    
    @Test
    public void noDeberiaTrasladar(){}
    
    @Test
    public void deberiaHacerProductoEscalar(){}
    
    @Test
    public void noDeberiaHacerProductoEscalar(){}
    
    @Test
    public void deberiaRotar(){}
    
    @Test
    public void noDeberiaRotar(){}
    
    @Test
    public void deberiaSumar(){}
    
    @Test
    public void noDeberiaSumar(){}
    
    @Test
    public void deberiaRestar(){}
    
    @Test
    public void noDeberiaRestar(){}
    
    @Test
    public void deberiaMultiplicar(){}
    
    @Test
    public void noDeberiaMultiplicar(){}
    
    @Test
    public void deberiaDarString(){}
    
    @Test
    public void noDeberiaDarString(){}
    
    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @AfterEach
    public void tearDown()
    {
    }
}
