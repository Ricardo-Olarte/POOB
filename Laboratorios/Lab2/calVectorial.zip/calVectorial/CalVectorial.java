import java.util.*;

/** Calculadora.java
 * Representa una calculadora de vectores 
 * @Acosta ESCUELA 2017-02 v01 2121-02 v02
 * @Olarte ESCUELA 2017-02 v01 2121-02 v02
 */
    
public class CalVectorial{
    
    private HashMap<String,Vector> operandos;
    
    public CalVectorial(){
        operandos = new HashMap<String,Vector>();
    }

    //Crea una nueva variable de memoria
    public void defina(String nombre){
        operandos.put(nombre, null);
    } 
     
    //Asigna una constante a una variable
    //a := P(longitud, grados)  La variable debe estar definida
    /**
     * Asigna el nuevo vector en coordenadas polares
     * @param String a, key del HashMap
     * @param float longitud, distancia del vector
     * @param float grados, inclinacion del vector y angulo, dada en coordenadas polares
     */
    public void asigne(String a, float longitud, float grados ){
        operandos.put(a, new Vector(longitud,new Angulo(grados,1)));
    }    
    
    //Asigna el resultado de una operacion unaria a una varible
    //Los caracteres de las operaciones posibles son: u (vector unitario) v (componente vertical), h (componente horizontal)
    //a := op b Las variables deben estar definidas
    /**
     * @param String a,
     * @param char op, es el caracter que define la operacion a realizar 'u', 'v', 'h'
     * @param String b,
     */
    public void asigne(String a, char op, String b){
        
    }
    
    //Asigna el resultado de una operacion binaria a una varible
    //Los caracteres de las operaciones posibles son: + (suma), - (resta), . (producto punto), e (proyeccion escalar), v (proyeccion vectorial)
    //a := b op c  Las variables deben estar definidas
    /**
     * @param String a,
     * @param String b,
     * @param char op,
     * @param String c,
     */
    public void asigne(String a, String b, char op, String c){
    }
  
    
    //Retorna el valor de la variable a en coordenadas polares. Si no esta definida retorna 'INDEFINIDA'
    /**
     * @return String,retorna el valor en String, si no esta definido debe ser 'INDEFINIDA'
     * @param String a, a, es la key de los operandos, indicando el vector
     */
    public String consulteEnPolares(String a){
        Vector vector = operandos.get(a);
        if(Objects.isNull(vector)){
            return "INDEFINIDA";
        }
        return vector.toString ();
    }
    
    //Retorna el valor de la variable a en coordenadas cartesianas. Si no esta definida retorna 'INDEFINIDA'
    /**
     * @return String retorna el valor en String del vector en coorrdenadas cartesianas
     * @param String a, 
     */
    public String consulteEnCartesianas(String a){
        Vector vector = operandos.get(a);
        if(Objects.isNull(vector)){
            return "INDEFINIDA";
        }
        String s = String.valueOf(vector.coordenadaX());
        String s1 = String.valueOf(vector.coordenadaY());
        return "(" + s + "," + s1 + ")";
    }
    
    //Si se logro hacer la ultima operacion
    public boolean ok(){
        return false;
    }
}
    



